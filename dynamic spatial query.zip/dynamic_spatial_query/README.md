# Dynamic Spatial Query -- QGIS 3.32 plugin

An "Extract by Location" that keeps itself up to date: pick a subject
layer and a selection layer, pick one or more spatial predicates, get
an output layer of subject features that satisfy any chosen predicate
against any selection feature. The output stays in sync as either
layer's features, attributes, geometry, or filter condition change.

This is a working skeleton, not a finished product -- see "Known
simplifications" near the bottom.

## What changed from the first version, and why

The first pass at this plugin ("Selection Intersector", from earlier
in this conversation) had the user draw an arbitrary polygon and pick
a layer *group*. The actual requirement turned out to be different,
matching QGIS's own "Извлечь по расположению" / "Extract by Location"
tool: two existing **layers** (not a drawn polygon, not a group), a
wider set of spatial predicates than just "intersects", and
reactivity to a filter condition changing (since "the layers can
themselves be the result of a query" -- a subset string) and to
attribute edits, not just geometry edits. That's a different enough
shape that this is a new package rather than a patch -- the
reactivity plumbing (`ReactiveWatcher`'s debounce mechanism, the
commit-signal / PostGIS-NOTIFY approach) carries over and is extended;
the polygon-drawing tool is gone, and the computation engine is
rewritten around "extract original features that match a predicate"
rather than "clip geometries against a drawn polygon".

## Files

| File | Purpose |
|---|---|
| `metadata.txt` | Plugin metadata QGIS reads to list it in the plugin manager |
| `__init__.py` | `classFactory()` entry point QGIS calls on load |
| `plugin.py` | Wires everything together: toolbar action, dock, engine, watcher |
| `query_panel.py` | Dock widget: subject/selection layer pickers, predicate checkboxes, controls |
| `spatial_query_engine.py` | The actual query logic + output-layer management |
| `reactive_watcher.py` | Connects to the right signals to detect "something changed" |
| `tests/` | Scripts that run the above against a real headless PyQGIS -- see "Verification" below |

## Architecture, in one pass

- **Layer pickers**: `QgsMapLayerComboBox` (the same widget QGIS's own
  dialogs use for this) for both the subject and selection layer.
  Unlike the checkable tree the polygon-drawing predecessor used, this
  widget keeps itself in sync with the project's layers automatically
  -- no manual repopulation code needed.
- **Predicates**: all 8 that `native:extractbylocation` offers
  (Intersects, Within, Contains, Overlaps, Touches, Equals, Crosses,
  Disjoint -- the brief named 5 of these; the other 3 came for free).
  Implemented directly as `QgsGeometry.intersects()` /`.within()` /
  etc. rather than delegating to the processing algorithm's integer-
  indexed `PREDICATE` parameter, specifically to avoid any risk of a
  wrong index-to-predicate mapping -- calling the method by name
  removes that risk entirely. Multiple checked predicates are combined
  with OR, matching the real tool's behaviour.
- **Computation**: subject features are extracted **unmodified** --
  original geometry, original attributes, no clipping (this is
  "extract", not "clip", unlike the polygon-drawing predecessor's
  output). A selection-layer spatial index plus a subject-layer
  bounding-box prefilter keep this fast for the 7 predicates where
  "the match must be spatially near something" holds; `Disjoint` is
  structurally different (a match is typically *far* from everything)
  and gets its own path -- see the "what actually turned up" note in
  `tests/README.md` for the bug this distinction fixed.
- **Filters ("the layer is the result of a query")**: a subset string
  (`QgsVectorLayer.setSubsetString()`, i.e. Layer Properties > Source >
  Query Builder) is applied at the provider level, so it's already
  respected by every `getFeatures()` call here with no extra code.
  The only thing that needed building was *reacting* to the filter
  itself changing -- `subsetStringChanged`, confirmed by direct testing
  to fire and to be immediately reflected in `getFeatures()` afterward.
- **Output**: a single memory layer matching the subject layer's exact
  geometry type (including Z/M variants) and full field schema, plus
  one extra field (`__orig_fid`, or `__orig_fid_1` etc. if that name
  already exists) tracing each result back to its source feature.
  Rebuilt fresh whenever the subject layer is swapped for one with a
  different schema/geometry type.
- **Self-comparison**: picking the same layer for both subject and
  selection is allowed (useful for topology checks -- "which parcels
  touch another parcel in this same layer") and a feature is never
  matched against itself.

## Verification

`tests/` installs a real headless PyQGIS (3.34, via
`apt-get install python3-qgis`) and runs the actual plugin modules --
48 assertions across 4 scripts, all currently passing, including:

- All 8 predicates individually, against a hand-built scene with
  verified relationships (not assumed -- predicate *direction* for
  the non-symmetric ones, like which argument "Within" takes as the
  contained side, was confirmed empirically before being wired in)
- Multi-predicate OR combination
- Original attributes + `__orig_fid` preserved correctly, including a
  deliberate field-name collision to check the renaming logic
- A layer compared against itself, confirming a feature never
  qualifies against its own geometry
- The output layer rebuilding correctly when the subject layer is
  swapped for a different geometry type
- Every reactivity trigger individually: committed geometry edits,
  committed **attribute-only** edits, **filter/subset-string**
  changes, and a **periodic refresh timer** independent of any edit
- The specific brief scenario -- a layer filtered to "only buildings"
  via subset string, confirming the query only sees the filtered rows
  and that changing the filter changes the result
- Real PostgreSQL + PostGIS: an INSERT from a separate database
  connection, against a **filtered** PostGIS layer, reaching the
  output correctly while the filter keeps excluding what it should

This process caught one real bug (the `Disjoint` bbox-prefilter issue
mentioned above) before it ever reached you -- see `tests/README.md`
for the specifics. See the same file for what this does *not* prove
(exact QGIS 3.32.2, Python 3.9 runtime, real Desktop GUI).

## Setting up PyCharm against QGIS's Python 3.9 (Windows)

QGIS on Windows bundles its own Python -- the compiled `qgis`, `PyQt5`,
`sip` and `osgeo` modules are built against that exact interpreter, so
PyCharm has to point at *that* Python, not a separately-installed one.

1. Find your QGIS install folder (e.g. `C:\Program Files\QGIS 3.32.2`
   or `C:\OSGeo4W`) and look inside its `bin` folder for
   `python-qgis.bat` or `python-qgis-ltr.bat`. Open it in a text
   editor -- it shows exactly which `PATH`, `PYTHONHOME` and
   `PYTHONPATH` values QGIS itself uses, which is more reliable than
   a hardcoded path since folder names shift between installer types
   and versions.
2. Write a small launcher batch file reusing those same lines, then
   starting PyCharm:

   ```bat
   @echo off
   SET QGIS_ROOT=C:\Program Files\QGIS 3.32.2
   call "%QGIS_ROOT%\bin\o4w_env.bat"
   call "%QGIS_ROOT%\bin\qt5_env.bat"
   call "%QGIS_ROOT%\bin\py3_env.bat"
   set PATH=%QGIS_ROOT%\apps\qgis-ltr\bin;%PATH%
   set PYTHONPATH=%QGIS_ROOT%\apps\qgis-ltr\python;%PYTHONPATH%
   start "" "C:\Program Files\JetBrains\PyCharm Community Edition\bin\pycharm64.exe"
   ```

   Adjust `apps\qgis-ltr` to whatever you actually found in step 1,
   and the PyCharm path to your install.
3. In PyCharm: File > Settings > Project > Python Interpreter > Add >
   System Interpreter, pointing at `python.exe` inside your QGIS
   install's Python folder (often `apps\Python39`, next to where
   `python-qgis*.bat` lives).
4. In the same interpreter settings, "Show paths for the selected
   interpreter" and add the QGIS `python` folder (typically
   `apps\qgis-ltr\python`) so PyCharm's indexer sees `import qgis`.
5. Always launch PyCharm via your batch file when working on this
   plugin, so the environment variables are set before PyCharm's own
   Python process starts.

Optional: `pip install qgis-stubs` in that interpreter for much better
autocomplete/type-checking on the PyQGIS API.

Install the **Plugin Reloader** plugin (from the QGIS plugin
repository) too, so you can reload after each code change with one
click instead of restarting QGIS.

## Installing the plugin for development

QGIS loads plugins from your active profile's `python/plugins` folder
(QGIS: Settings > User Profiles > Open Active Profile Folder, then
`python/plugins`). Copy this `dynamic_spatial_query` folder there, or
symlink it so edits in PyCharm show up immediately:

```bat
mklink /D "C:\Users\<you>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\dynamic_spatial_query" "C:\path\to\your\pycharm\project\dynamic_spatial_query"
```

(elevated/Administrator command prompt -- `mklink` needs it). Then in
QGIS: Plugins > Manage and Install Plugins > Installed, enable
"Dynamic Spatial Query".

## How live-updating works

`reactive_watcher.py` watches both the subject and selection layers
(deduplicated if they're the same layer) for:

1. **Committed edits**: feature add/remove/geometry change, same as
   before, plus **attribute-only changes** now too (`committedAttributeValuesChanges`)
   -- new in this version, since a layer here can be "the result of a
   query" and the brief explicitly calls out attribute edits as a
   trigger.
2. **Filter changes**: `subsetStringChanged`, so editing a layer's
   Query Builder filter -- either layer -- triggers a refresh without
   needing any add/edit/delete at all.
3. **Layer removed from the project**: `QgsProject.layersRemoved`.
4. **Cross-session PostGIS edits**: `setListening(True)` +
   the provider's `notify` signal, reusing a real QGIS core feature
   (the same one behind the "Refresh layer on notification" checkbox
   in a PostGIS layer's Rendering properties). Requires a one-time SQL
   trigger per source table:

   ```sql
   CREATE OR REPLACE FUNCTION public.notify_qgis() RETURNS trigger AS $$
   BEGIN
     NOTIFY qgis;
     RETURN NULL;
   END;
   $$ LANGUAGE plpgsql;

   CREATE TRIGGER my_table_notify_qgis
   AFTER INSERT OR UPDATE OR DELETE ON my_schema.my_table
   FOR EACH STATEMENT EXECUTE FUNCTION public.notify_qgis();
   ```

   PostgreSQL only sends `NOTIFY` on commit, so this reflects committed
   transactions, same as point 1. Without this trigger, external edits
   are only picked up via "Recalculate now" or the periodic timer
   below, if enabled.

All of the above funnel into one debounced `sourceDataChanged` signal
(400ms). On top of that, `set_periodic_refresh(enabled, seconds)`
supplements it with a plain, unconditional timer -- matching the
"buffer zones" precedent mentioned in the brief ("действия выполняются
с какой-то периодичностью") -- off by default, since the signal-driven
approach above is both more efficient and more precise (it reacts
exactly when something changed, not on a fixed schedule), but it's a
one-line toggle in the panel if you want the safety net for a
provider/situation the signals above don't cover.

The brief also mentions refreshing "when you move the map" as another
example trigger from that same precedent. Deliberately not built in
here: it's really a different feature (scoping the computation to the
current view extent, both as the refresh trigger and as a performance
optimization) rather than a drop-in additional signal, and the brief
frames it as one example implementation among several rather than a
hard requirement. If you want it, it's a one-line addition:
`iface.mapCanvas().extentsChanged.connect(watcher._schedule)`.

## Known simplifications / where to extend

- **No viewport scoping**: every recalculation considers the whole of
  both layers, not just what's visible. Fine at the sizes tested here;
  for very large layers, the map-pan trigger mentioned above pairs
  naturally with also limiting `_do_recalculate()`'s subject-layer
  request to the current canvas extent.
- **Background execution**: `recalculate()` runs synchronously on the
  main thread. The bounding-box prefilter (and the database's own
  spatial index, for a PostGIS layer) has kept this fast enough in
  testing that it hasn't needed a `QgsTask` yet. If a large enough
  layer changes that, wrap `_do_recalculate()` in
  `QgsTask.fromFunction(...)` + `QgsApplication.taskManager().addTask(...)`
  -- remembering to keep a reference to the task object, since it can
  get garbage-collected mid-run otherwise -- and avoid calling into
  `processing.run(...)` from within it if you also adopt the
  `native:extractbylocation` alternative mentioned below, since parts
  of the Processing framework aren't reliably thread-safe for
  background execution.
- **`native:extractbylocation` as an alternative**: this engine calls
  `QgsGeometry` predicate methods directly rather than QGIS's own
  `native:extractbylocation` processing algorithm, specifically to
  avoid relying on that algorithm's integer-indexed predicate list
  (a wrong index there would silently select the wrong predicate).
  If you'd rather delegate to it -- e.g. to inherit its exact
  edge-case handling -- its parameters are `INPUT`, `PREDICATE` (a
  list of integers), `INTERSECT`, `OUTPUT`; you'd need to pin down
  and test the exact index-to-predicate ordering for your QGIS version
  before trusting it, the same way this engine's direct-method-call
  approach was tested here.
- **Multi-user output**: like the predecessor, the output is a local
  `memory:` layer. Swap the construction in `_get_or_create_layer()`
  for a PostGIS-backed one if you want the result itself published.

## Troubleshooting

- `ImportError: No module named 'qgis'` in PyCharm/when running a
  script standalone: PyCharm's interpreter isn't the one bundled with
  QGIS, or the QGIS `python` folder isn't in its interpreter paths --
  revisit the PyCharm setup section above.
- Plugin doesn't appear in Plugins > Manage and Install Plugins: check
  the QGIS Python Console (View > Panels > Python Console) for a
  traceback -- a syntax error or bad import in any of these files
  will stop it from loading, and the console shows exactly where.
- Nothing happens when source data changes: confirm "Auto-update on
  changes" is checked, and for PostGIS layers, confirm the `NOTIFY`
  trigger exists on the table you edited (edits via *this* QGIS
  session's own editing tools don't need it -- only external edits do).
- "Disjoint" (alone or combined with other predicates) returning far
  more or fewer features than expected: it's evaluated against the
  *whole* selection layer ("not matching anything in it"), not
  per-selection-feature like the other 7 predicates -- see the note
  at the end of "Architecture" above.
