# Dynamic Spatial Query -- QGIS 3.32 plugin (Russian UI)

An "Extract by Location" that keeps itself up to date: define a
query (subject layer, selection layer, spatial predicates), click
"Создать" (Create), and get an output layer that stays live --
automatically re-extracting whenever either input layer's features,
attributes, geometry, or filter condition change -- until you
explicitly remove it. The UI is in Russian; this document is in
English.

This is a working skeleton, not a finished product -- see "Known
simplifications" near the bottom.

## What changed this round

Three real product requests, not just polish:

1. **Nothing is created just by picking layers or enabling the
   plugin.** Previously, auto-selecting layers in the panel (or even
   just having the plugin enabled in a project that already had
   layers) could silently create an output layer and group. Now
   picking layers only edits a draft; an explicit click of the
   panel's primary button ("Создать") is what actually creates a
   query -- a real output layer, added to the project, and armed to
   auto-update.
2. **A query can be removed two equivalent ways**: the panel's
   "Удалить" (Remove) button, or simply deleting its output layer
   from QGIS's own Layers panel -- both tear the query down the same
   way (stop its watcher, drop it from the registry). Deleting a
   query's subject or selection layer instead (not its output) also
   tears it down, since it can no longer function, but leaves its
   last-computed output layer in place rather than also deleting it.
3. **A management table** at the top of the panel lists every
   currently-live query (output name, subject, selection, status);
   clicking a row loads that query below for viewing or editing.
   Previously the only way to "find" an existing query was to already
   know which layer was its subject and pick it in the dropdown.

Plus: the whole UI (labels, buttons, status messages, the plugin's
own name in the plugin manager) is now in Russian. Internal predicate
keys and custom-property names stay in English regardless -- only the
presentation layer changed, so this doesn't affect compatibility with
projects/queries created by earlier versions.

## Files

| File | Purpose |
|---|---|
| `metadata.txt` | Plugin metadata QGIS reads to list it in the plugin manager (Russian name/description) |
| `__init__.py` | `classFactory()` entry point QGIS calls on load |
| `plugin.py` | Wires everything together: the query registry, create/remove, reactive cleanup |
| `query_panel.py` | Dock widget: query table, layer pickers, predicate checkboxes, controls -- Russian labels |
| `spatial_query_engine.py` | The actual query logic + GeoPackage-backed output-layer management |
| `reactive_watcher.py` | Connects to the right signals to detect "something changed", per query |
| `tests/` | Scripts that run the above against a real headless PyQGIS |

## Architecture, in one pass

- **Draft vs. created**: the panel's controls (both layer pickers,
  predicates, output name) always represent a *draft*. Nothing is
  registered or computed until the primary button is clicked. If the
  currently-picked subject layer already has a query, that button
  reads "Пересчитать сейчас" (Recalculate now) instead of "Создать"
  and the Remove button is enabled; for a brand-new subject it's the
  reverse. `plugin.py`'s `_on_subject_changed` is what decides which
  state you're in and updates the panel accordingly.
- **Registry**: `plugin.py` keeps one independent engine+watcher pair
  per *created* subject layer (`self._queries`), not one shared pair
  reconfigured on every panel change -- so switching which query the
  panel shows never stops another one from continuing to update in
  the background. Every registered query is restored from the
  project's tagged output layers on load, so a query created in a
  previous session resumes updating the moment the project reopens,
  with zero panel interaction.
- **Predicates**: all 8 that `native:extractbylocation` offers
  (Intersects, Within, Contains, Overlaps, Touches, Equals, Crosses,
  Disjoint), implemented as direct `QgsGeometry` method calls rather
  than delegating to that processing algorithm's integer-indexed
  `PREDICATE` parameter, specifically to avoid any risk of a wrong
  index-to-predicate mapping. Multiple checked predicates combine
  with OR. Internal keys stay English; `query_panel.py`'s
  `PREDICATE_LABELS_RU` maps them to Russian for display only.
- **Computation**: subject features are extracted unmodified --
  original geometry, original attributes, no clipping. A selection-
  layer spatial index plus a subject-layer bounding-box prefilter
  keep this fast for the 7 predicates where "the match must be
  spatially near something" holds; `Disjoint` is structurally
  different (a match is typically *far* from everything) and gets its
  own path.
- **Filters ("the layer is the result of a query")**: a subset string
  is respected automatically by every `getFeatures()` call here, for
  free. The only thing that needed building was *reacting* to the
  filter itself changing (`subsetStringChanged`).
- **Persistence**: output layers are GeoPackage-backed (one `.gpkg`
  file per project, one table per subject layer), not QGIS "memory"
  layers -- memory layers never write their feature data into the
  project file, only their structure. Writes go through a real layer
  edit session (`startEditing()`/`addFeatures()`/`deleteFeatures()`/
  `commitChanges()`), not straight to the data provider, which is
  also what makes QGIS's "Show Feature Count" legend display refresh
  correctly (it only listens for the commit signals that path emits).
- **Reattachment**: each output layer is tagged with a
  `QgsMapLayer` custom property (subject/selection layer ids,
  predicates, output name) at creation time. Before creating a new
  layer, the engine checks for a matching tagged one first -- this is
  what lets a reopened project rediscover and reattach to its own
  previously-created outputs instead of duplicating them, and what
  lets `plugin.py` reconstruct a query's full definition (not just
  its existence) on load.
- **Background execution**: `recalculate()` runs its matching step on
  a `QgsTask`, keeping only the output-layer write on the main
  thread. A `recalculate()` call that arrives while one is already
  running doesn't start a second, overlapping task; it's remembered
  and re-run once the in-flight one finishes.

## Verification

`tests/` installs a real headless PyQGIS (3.34, via
`apt-get install python3-qgis`) and runs the actual plugin modules.
Beyond the predicate/attribute/persistence correctness already
covered by earlier rounds, this round's tests specifically cover:

- Enabling the plugin (or picking layers) with existing project
  layers creates nothing until the button is explicitly clicked
- The button's label and Remove's enabled state track draft-vs-
  created correctly as you switch between subjects
- Removing via the panel button vs. deleting the output layer
  directly both tear the query down equivalently
- Deleting a query's subject layer tears it down but leaves its
  output layer alone
- The management table's row count and content track reality, and
  clicking a row loads that query
- A query created through the real button flow still persists and
  restores correctly across an actual project save/reload

One real crash surfaced and got fixed while writing these: cleanup
was originally wired to `QgsProject.layersRemoved`, which fires
*after* a layer's underlying C++ object is already destroyed --
calling `.id()` on it, or disconnecting a watcher's signal
connections from it, produced an uncatchable segfault, not a Python
exception. Switched to `layersWillBeRemoved`, confirmed directly to
fire while the layer is still fully valid, and the crash is gone.

## Setting up PyCharm against QGIS's Python 3.9 (Windows)

QGIS on Windows bundles its own Python -- PyCharm has to point at
that exact interpreter, not a separately-installed one.

1. Find your QGIS install folder and look inside its `bin` folder for
   `python-qgis.bat` or `python-qgis-ltr.bat`. Open it in a text
   editor -- it shows exactly which `PATH`/`PYTHONHOME`/`PYTHONPATH`
   values QGIS itself uses.
2. Write a launcher batch file reusing those same lines, then
   starting PyCharm:

   ```bat
   @echo off
   SET QGIS_ROOT=C:\Program Files\QGIS 3.32.2
   call "%QGIS_ROOT%\bin\o4w_env.bat"
   call "%QGIS_ROOT%\bin\qt5_env.bat"
   call "%QGIS_ROOT%\bin\py3_env.bat"
   set PATH=%QGIS_ROOT%\apps\qgis-ltr\bin;%PATH%
   set PYTHONPATH=%QGIS_ROOT%\apps\qgis-ltr\python;%PYTHONPATH%
   start "" "C:\Program Files\JetBrains\PyCharm Community Edition\bin\pycharm64.exe"
   ```

3. In PyCharm: File > Settings > Project > Python Interpreter > Add >
   System Interpreter, pointing at `python.exe` inside your QGIS
   install's Python folder (often `apps\Python39`).
4. Add the QGIS `python` folder to the interpreter's paths so
   PyCharm's indexer sees `import qgis`.
5. Always launch PyCharm via your batch file so the environment
   variables are set first.

Install **Plugin Reloader** for a fast edit/reload loop instead of
restarting QGIS each time.

## Installing the plugin for development

Copy or symlink this `dynamic_spatial_query` folder into your QGIS
profile's `python/plugins` folder (Settings > User Profiles > Open
Active Profile Folder > `python/plugins`), enable it under
Plugins > Manage and Install Plugins > Installed.

## How live-updating works

`reactive_watcher.py` watches both layers of a created query
(deduplicated if they're the same layer) for: committed edits
(feature add/remove/geometry/attribute changes), filter/subset-string
changes, and cross-session PostGIS edits via `setListening(True)` +
the provider's `notify` signal (requires a one-time SQL trigger per
source table -- see below). All funnel into one debounced
`sourceDataChanged` signal (400ms). `set_periodic_refresh(enabled,
seconds)` supplements this with a plain unconditional timer, off by
default.

PostGIS NOTIFY trigger, one-time per source table:

```sql
CREATE OR REPLACE FUNCTION public.notify_qgis() RETURNS trigger AS $$
BEGIN
  NOTIFY qgis;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER my_table_notify_qgis
AFTER INSERT OR UPDATE OR DELETE ON my_schema.my_table
FOR EACH STATEMENT EXECUTE FUNCTION public.notify_qgis();
```

Separately, `plugin.py` listens to `QgsProject.layersWillBeRemoved`
at a higher level to detect one of a query's own layers (subject,
selection, or output) being deleted from the project, and tears that
specific query down -- see "Architecture" above.

## Known simplifications / where to extend

- **One live query per subject layer**: two different queries
  sharing the same subject layer but different selection layers
  isn't supported -- picking a subject that already has a query loads
  that existing query rather than letting you define a second one
  against it.
- **Auto-update/periodic-refresh toggles aren't persisted**: only the
  query definition itself (subject, selection, predicates, output
  name) survives a restart; each query's own toggle state resets to
  its default.
- **No viewport scoping**: every recalculation considers the whole of
  both layers, not just what's visible on screen.
- **`native:extractbylocation` as an alternative**: see the
  Architecture section above for why this engine calls `QgsGeometry`
  methods directly instead.
- **Multi-user output**: the output GeoPackage is a local file. Swap
  the construction in `_get_or_create_layer()` for a PostGIS-backed
  one if you want the result itself published to other users.
- **Translation approach**: UI strings are hardcoded in Russian
  directly (in `query_panel.py` and `plugin.py`), not built on QGIS's
  `.ts`/`.qm` translation-file system -- simpler for a single target
  language, but means adding a second language later would mean
  building that infrastructure rather than just adding a translation
  file.

## Troubleshooting

- `ImportError: No module named 'qgis'`: PyCharm's interpreter isn't
  the one bundled with QGIS -- revisit the PyCharm setup section.
- Plugin doesn't appear in the plugin manager: check the QGIS Python
  Console (View > Panels > Python Console) for a traceback.
- A query doesn't update: confirm "Автообновление при изменениях" is
  checked for that specific query (it's per-query, not global), and
  for PostGIS layers, confirm the `NOTIFY` trigger exists on the
  table you edited.
- "Disjoint" returning unexpected results: it's evaluated against the
  *whole* selection layer ("not matching anything in it"), not
  per-selection-feature like the other 7 predicates.
