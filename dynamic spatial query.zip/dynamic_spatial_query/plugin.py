"""
Main plugin class. QGIS instantiates this once (via classFactory in
__init__.py) and calls initGui() on load, unload() on unload.

Keeps one independent, always-live query PER DISTINCT SUBJECT LAYER
(self._queries), not just one for whichever query the panel currently
shows. Switching the panel's subject dropdown switches which query
you're viewing/editing; it does not stop whichever query was
previously shown from continuing to update in the background --
that's what "only the last-selected layer updates" (the reported
problem this fixes) actually was: one shared engine+watcher pair
getting reconfigured every time the panel's selection changed,
abandoning whatever it was previously watching.

Every registered query also survives a project reload: initGui()
scans the project for the plugin's own tagged output layers and
rebuilds a query for each one found (spatial_query_engine's
read_query_definition), then arms its watcher -- so a layer created
in a previous session resumes updating as soon as the project opens,
without the user reselecting it in the panel first.

Known limitation: this still assumes one live query per distinct
subject layer (matching how output-layer reattachment already
worked) -- two different queries sharing the same subject layer but
different selection layers isn't supported. Each query's own
auto-update/periodic-refresh toggles also aren't persisted across a
restart yet (they reset to "on"/"off" defaults) -- only the query
definition itself (subject, selection, predicates, output name) is.
"""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QAction, QStyle
from qgis.core import QgsProject

from .query_panel import QueryPanel
from .reactive_watcher import ReactiveWatcher
from .spatial_query_engine import SpatialQueryEngine, read_query_definition


class _LiveQuery:
    """One subject layer's worth of engine + watcher, plus its own
    independent auto-update/periodic-refresh settings -- kept alive in
    the plugin's registry regardless of what the panel currently
    shows."""

    def __init__(self, iface):
        self.engine = SpatialQueryEngine(iface)
        self.watcher = ReactiveWatcher()
        self.auto_update = True
        self.periodic_enabled = False
        self.periodic_seconds = 30


class DynamicSpatialQueryPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.panel = None
        self._queries = {}       # subject_layer_id -> _LiveQuery
        self._current_key = None  # which query the panel is presently showing

    def initGui(self):
        icon = self.iface.mainWindow().style().standardIcon(QStyle.SP_DialogApplyButton)
        self.action = QAction(icon, "Dynamic Spatial Query", self.iface.mainWindow())
        self.action.setCheckable(True)
        self.action.triggered.connect(self._toggle_panel)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Dynamic Spatial Query", self.action)

        self.panel = QueryPanel(self.iface)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.panel)
        self.panel.hide()
        self.panel.visibilityChanged.connect(self.action.setChecked)

        self.panel.subjectLayerChanged.connect(self._on_subject_changed)
        self.panel.selectionLayerChanged.connect(self._on_selection_changed)
        self.panel.predicatesChanged.connect(self._on_predicates_changed)
        self.panel.outputNameChanged.connect(self._on_output_name_changed)
        self.panel.autoUpdateToggled.connect(self._on_auto_update_toggled)
        self.panel.periodicRefreshChanged.connect(self._on_periodic_refresh_changed)
        self.panel.recalcRequested.connect(self._trigger_current_recalculation)

        self._restore_existing_queries()

        # Pick up whatever QgsMapLayerComboBox already auto-selected
        # (e.g. if layers were already in the project when the panel
        # was built) instead of waiting for the user to touch a combo.
        initial_subject = self.panel.subject_layer()
        if initial_subject is not None:
            self._on_subject_changed(initial_subject)

    def unload(self):
        self.iface.removePluginMenu("&Dynamic Spatial Query", self.action)
        self.iface.removeToolBarIcon(self.action)
        for query in self._queries.values():
            query.watcher.stop()
            query.engine.cancel()
        if self.panel is not None:
            # deleteLater() is asynchronous -- the panel (and its combo
            # boxes) can otherwise keep firing signals into this
            # instance for a while after unload() returns (e.g. if the
            # project gets cleared right afterward, a combo box's
            # currentLayer changing as a result would still reach
            # _on_subject_changed with a layer already mid-deletion).
            # Disconnect explicitly first so unload() actually means
            # "deaf to everything" immediately, not eventually.
            self.panel.subjectLayerChanged.disconnect(self._on_subject_changed)
            self.panel.selectionLayerChanged.disconnect(self._on_selection_changed)
            self.panel.predicatesChanged.disconnect(self._on_predicates_changed)
            self.panel.outputNameChanged.disconnect(self._on_output_name_changed)
            self.panel.autoUpdateToggled.disconnect(self._on_auto_update_toggled)
            self.panel.periodicRefreshChanged.disconnect(self._on_periodic_refresh_changed)
            self.panel.recalcRequested.disconnect(self._trigger_current_recalculation)
            self.iface.removeDockWidget(self.panel)
            self.panel.deleteLater()
            self.panel = None

    # -- restoring queries that already existed in the project -------------

    def _restore_existing_queries(self):
        project = QgsProject.instance()
        for layer in list(project.mapLayers().values()):
            definition = read_query_definition(layer, project)
            if definition is None:
                continue
            query = self._get_or_create_query(definition["subject_layer"])
            query.engine.set_selection_layer(definition["selection_layer"])
            query.engine.set_predicates(definition["predicates"])
            query.engine.set_output_name(definition["output_name"])
            query.engine.attach_existing_output_layer(layer)
            self._arm_watcher(query)  # resume updating; no need to recalculate --
            # the output layer's data is already correct as of last save.

    # -- UI callbacks --------------------------------------------------

    def _toggle_panel(self, checked):
        self.panel.setVisible(checked)

    def _on_subject_changed(self, layer):
        if layer is None:
            self._current_key = None
            return

        key = layer.id()
        is_new = key not in self._queries
        if is_new:
            # Seed a brand-new query from whatever the panel is
            # currently showing, so defining several similar queries
            # in a row (same selection layer/predicates, different
            # subject) doesn't mean re-picking everything each time.
            seed_selection = self.panel.selection_layer()
            seed_predicates = self.panel.selected_predicates()
            seed_output_name = self.panel.output_name()

        query = self._get_or_create_query(layer)

        if is_new:
            if seed_selection is not None:
                query.engine.set_selection_layer(seed_selection)
            query.engine.set_predicates(seed_predicates)
            query.engine.set_output_name(seed_output_name)

        self._current_key = key
        self.panel.load_query_state(
            query.engine.selection_layer,
            query.engine.predicates,
            query.engine.output_name,
            query.auto_update,
            query.periodic_enabled,
            query.periodic_seconds,
        )
        self._arm_watcher(query)
        self._trigger_current_recalculation()

    def _on_selection_changed(self, layer):
        query = self._current_query()
        if query is None or layer is None:
            return
        query.engine.set_selection_layer(layer)
        self._arm_watcher(query)
        self._trigger_current_recalculation()

    def _on_predicates_changed(self, predicates):
        query = self._current_query()
        if query is None:
            return
        query.engine.set_predicates(predicates)
        self._trigger_current_recalculation()

    def _on_output_name_changed(self, name):
        query = self._current_query()
        if query is None:
            return
        query.engine.set_output_name(name)

    def _on_auto_update_toggled(self, enabled):
        query = self._current_query()
        if query is None:
            return
        query.auto_update = enabled
        self._arm_watcher(query)

    def _on_periodic_refresh_changed(self, enabled, seconds):
        query = self._current_query()
        if query is None:
            return
        query.periodic_enabled = enabled
        query.periodic_seconds = seconds
        query.watcher.set_periodic_refresh(enabled, seconds)

    def _trigger_current_recalculation(self):
        query = self._current_query()
        if query is None:
            return
        self.panel.set_status("Calculating...")
        query.engine.recalculate(on_done=self._on_recalculated)

    def _on_recalculated(self, feature_count, error):
        if error:
            self.panel.set_status(error)
        else:
            self.panel.set_status(f"Done -- {feature_count} matching feature(s).")

    # -- registry plumbing ----------------------------------------------

    def _current_query(self):
        if self._current_key is None:
            return None
        return self._queries.get(self._current_key)

    def _get_or_create_query(self, subject_layer):
        key = subject_layer.id()
        query = self._queries.get(key)
        if query is None:
            query = _LiveQuery(self.iface)
            query.engine.set_subject_layer(subject_layer)
            query.watcher.sourceDataChanged.connect(
                lambda key=key: self._trigger_recalculation_for(key)
            )
            self._queries[key] = query
            self.panel.set_query_count(len(self._queries))
        return query

    def _trigger_recalculation_for(self, key):
        """Called by a background query's own watcher -- key may or
        may not be the one currently shown in the panel."""
        query = self._queries.get(key)
        if query is None:
            return
        if key == self._current_key:
            self.panel.set_status("Calculating...")
            query.engine.recalculate(on_done=self._on_recalculated)
        else:
            query.engine.recalculate(on_done=None)

    def _arm_watcher(self, query):
        if query.auto_update:
            query.watcher.watch([query.engine.subject_layer, query.engine.selection_layer])
        else:
            query.watcher.stop_watching_layers()
