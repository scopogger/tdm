"""
Main plugin class. QGIS instantiates this once (via classFactory in
__init__.py) and calls initGui() on load, unload() on unload.
"""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QAction, QStyle

from .query_panel import QueryPanel
from .reactive_watcher import ReactiveWatcher
from .spatial_query_engine import SpatialQueryEngine


class DynamicSpatialQueryPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.panel = None
        self.engine = None
        self.watcher = None

    def initGui(self):
        icon = self.iface.mainWindow().style().standardIcon(QStyle.SP_DialogApplyButton)
        self.action = QAction(icon, "Dynamic Spatial Query", self.iface.mainWindow())
        self.action.setCheckable(True)
        self.action.triggered.connect(self._toggle_panel)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Dynamic Spatial Query", self.action)

        self.panel = QueryPanel(self.iface)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.panel)
        self.panel.hide()
        self.panel.visibilityChanged.connect(self.action.setChecked)

        self.engine = SpatialQueryEngine(self.iface)
        self.watcher = ReactiveWatcher()
        self.watcher.sourceDataChanged.connect(self._trigger_recalculation)

        self.panel.subjectLayerChanged.connect(self._on_subject_changed)
        self.panel.selectionLayerChanged.connect(self._on_selection_changed)
        self.panel.predicatesChanged.connect(self._on_predicates_changed)
        self.panel.outputNameChanged.connect(self.engine.set_output_name)
        self.panel.autoUpdateToggled.connect(self._on_auto_update_toggled)
        self.panel.periodicRefreshChanged.connect(self.watcher.set_periodic_refresh)
        self.panel.recalcRequested.connect(self._trigger_recalculation)

        # Pick up whatever QgsMapLayerComboBox already auto-selected
        # (e.g. if layers were already in the project when the panel
        # was built) instead of waiting for the user to touch a combo.
        self.engine.set_subject_layer(self.panel.subject_layer())
        self.engine.set_selection_layer(self.panel.selection_layer())
        self.engine.set_predicates(self.panel.selected_predicates())

    def unload(self):
        self.iface.removePluginMenu("&Dynamic Spatial Query", self.action)
        self.iface.removeToolBarIcon(self.action)
        if self.watcher is not None:
            self.watcher.stop()
        if self.panel is not None:
            self.iface.removeDockWidget(self.panel)
            self.panel.deleteLater()

    # -- UI callbacks ------------------------------------------------------

    def _toggle_panel(self, checked):
        self.panel.setVisible(checked)

    def _on_subject_changed(self, layer):
        self.engine.set_subject_layer(layer)
        self._resync_watcher_and_recalc()

    def _on_selection_changed(self, layer):
        self.engine.set_selection_layer(layer)
        self._resync_watcher_and_recalc()

    def _on_predicates_changed(self, predicates):
        self.engine.set_predicates(predicates)
        self._trigger_recalculation()

    def _on_auto_update_toggled(self, enabled):
        self._resync_watcher_and_recalc()

    def _resync_watcher_and_recalc(self):
        if self.panel.auto_update_enabled():
            self.watcher.watch([self.panel.subject_layer(), self.panel.selection_layer()])
        else:
            self.watcher.stop_watching_layers()
        self._trigger_recalculation()

    def _trigger_recalculation(self):
        self.panel.set_status("Calculating...")
        self.engine.recalculate(on_done=self._on_recalculated)

    def _on_recalculated(self, feature_count, error):
        if error:
            self.panel.set_status(error)
        else:
            self.panel.set_status(f"Done -- {feature_count} matching feature(s).")
