"""
Dock widget: pick the subject layer and the selection layer (each via
QgsMapLayerComboBox, which keeps itself in sync with the project's
layers automatically -- no manual repopulation needed, unlike the
custom tree widget the polygon-drawing predecessor of this plugin
used), pick predicates, control auto-update, see status.

This panel is a *view into whichever query's subject layer is
currently selected*, not "the one query" -- the plugin now keeps a
separate, independently-live query running per distinct subject
layer (see plugin.py's registry), so switching the subject dropdown
switches which query you're looking at/editing, not which query
exists. load_query_state() is how the plugin repopulates the other
controls (selection layer, predicates, output name, auto-update,
periodic refresh) to match whichever query that subject layer
belongs to, without each control re-announcing its own change signal
while being set programmatically.
"""

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.core import QgsMapLayerProxyModel
from qgis.gui import QgsMapLayerComboBox
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QDockWidget,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from .spatial_query_engine import PREDICATES


class QueryPanel(QDockWidget):
    subjectLayerChanged = pyqtSignal(object)  # QgsVectorLayer or None
    selectionLayerChanged = pyqtSignal(object)
    predicatesChanged = pyqtSignal(list)
    outputNameChanged = pyqtSignal(str)
    autoUpdateToggled = pyqtSignal(bool)
    periodicRefreshChanged = pyqtSignal(bool, int)  # enabled, interval seconds
    recalcRequested = pyqtSignal()

    def __init__(self, iface, parent=None):
        super().__init__("Dynamic Spatial Query", parent)
        self.iface = iface
        self.setObjectName("DynamicSpatialQueryPanel")

        container = QWidget(self)
        layout = QVBoxLayout(container)

        layout.addWidget(QLabel("Subject layer (features to extract):"))
        self.subject_combo = QgsMapLayerComboBox()
        self.subject_combo.setFilters(QgsMapLayerProxyModel.VectorLayer)
        self.subject_combo.layerChanged.connect(self.subjectLayerChanged.emit)
        layout.addWidget(self.subject_combo)

        layout.addWidget(QLabel("Selection layer (tested against):"))
        self.selection_combo = QgsMapLayerComboBox()
        self.selection_combo.setFilters(QgsMapLayerProxyModel.VectorLayer)
        self.selection_combo.layerChanged.connect(self.selectionLayerChanged.emit)
        layout.addWidget(self.selection_combo)

        pred_box = QGroupBox("Keep subject features that... (any checked = match)")
        pred_layout = QGridLayout()
        self.predicate_checks = {}
        for i, name in enumerate(PREDICATES):
            cb = QCheckBox(name)
            cb.setChecked(name == "Intersects")
            cb.toggled.connect(self._on_predicate_toggled)
            self.predicate_checks[name] = cb
            pred_layout.addWidget(cb, i // 2, i % 2)
        pred_box.setLayout(pred_layout)
        layout.addWidget(pred_box)

        out_row = QHBoxLayout()
        out_row.addWidget(QLabel("Output name:"))
        self.output_name_edit = QLineEdit("query_result")
        self.output_name_edit.editingFinished.connect(
            lambda: self.outputNameChanged.emit(self.output_name_edit.text())
        )
        out_row.addWidget(self.output_name_edit)
        layout.addLayout(out_row)

        self.auto_update_check = QCheckBox("Auto-update on changes")
        self.auto_update_check.setChecked(True)
        self.auto_update_check.toggled.connect(self.autoUpdateToggled.emit)
        layout.addWidget(self.auto_update_check)

        periodic_row = QHBoxLayout()
        self.periodic_check = QCheckBox("Also refresh every")
        self.periodic_check.toggled.connect(self._on_periodic_changed)
        periodic_row.addWidget(self.periodic_check)
        self.periodic_spin = QSpinBox()
        self.periodic_spin.setRange(5, 3600)
        self.periodic_spin.setValue(30)
        self.periodic_spin.setSuffix(" s")
        self.periodic_spin.valueChanged.connect(self._on_periodic_changed)
        periodic_row.addWidget(self.periodic_spin)
        periodic_row.addStretch()
        layout.addLayout(periodic_row)

        recalc_btn = QPushButton("Recalculate now")
        recalc_btn.clicked.connect(self.recalcRequested.emit)
        layout.addWidget(recalc_btn)

        self.status_label = QLabel("Ready")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        self.query_count_label = QLabel("")
        self.query_count_label.setWordWrap(True)
        layout.addWidget(self.query_count_label)

        layout.addStretch()
        container.setLayout(layout)
        self.setWidget(container)

    # -- internal handlers --------------------------------------------

    def _on_predicate_toggled(self, _checked):
        self.predicatesChanged.emit(self.selected_predicates())

    def _on_periodic_changed(self, *_args):
        self.periodicRefreshChanged.emit(self.periodic_check.isChecked(), self.periodic_spin.value())

    # -- public accessors used by the plugin controller ------------------

    def subject_layer(self):
        return self.subject_combo.currentLayer()

    def selection_layer(self):
        return self.selection_combo.currentLayer()

    def selected_predicates(self):
        return [name for name, cb in self.predicate_checks.items() if cb.isChecked()]

    def output_name(self):
        return self.output_name_edit.text()

    def auto_update_enabled(self):
        return self.auto_update_check.isChecked()

    def set_status(self, text):
        self.status_label.setText(text)

    def set_query_count(self, count):
        if count <= 1:
            self.query_count_label.setText("")
        else:
            self.query_count_label.setText(f"{count} queries running independently in this project.")

    def load_query_state(self, selection_layer, predicates, output_name,
                          auto_update_enabled, periodic_enabled, periodic_seconds):
        """
        Repopulates every control except the subject dropdown (the
        caller already knows the subject layer -- that's what
        triggered this) to reflect an EXISTING query, without each
        widget re-announcing its own change signal as it's set --
        otherwise this would look, from the plugin's side, like the
        user re-editing every field by hand, which would be harmless
        but wasteful (a burst of redundant recalculation triggers for
        a query that hasn't actually changed).
        """
        self.selection_combo.blockSignals(True)
        self.selection_combo.setLayer(selection_layer)
        self.selection_combo.blockSignals(False)

        for name, cb in self.predicate_checks.items():
            cb.blockSignals(True)
            cb.setChecked(name in predicates)
            cb.blockSignals(False)

        self.output_name_edit.blockSignals(True)
        self.output_name_edit.setText(output_name)
        self.output_name_edit.blockSignals(False)

        self.auto_update_check.blockSignals(True)
        self.auto_update_check.setChecked(auto_update_enabled)
        self.auto_update_check.blockSignals(False)

        self.periodic_check.blockSignals(True)
        self.periodic_check.setChecked(periodic_enabled)
        self.periodic_check.blockSignals(False)

        self.periodic_spin.blockSignals(True)
        self.periodic_spin.setValue(periodic_seconds)
        self.periodic_spin.blockSignals(False)
