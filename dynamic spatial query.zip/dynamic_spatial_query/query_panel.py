"""
Dock widget: pick the subject layer and the selection layer (each via
QgsMapLayerComboBox, which keeps itself in sync with the project's
layers automatically -- no manual repopulation needed, unlike the
custom tree widget the polygon-drawing predecessor of this plugin
used), pick predicates, control auto-update, see status.
"""

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.core import QgsMapLayerProxyModel
from qgis.gui import QgsMapLayerComboBox
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QDockWidget,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from .spatial_query_engine import PREDICATES


class QueryPanel(QDockWidget):
    subjectLayerChanged = pyqtSignal(object)  # QgsVectorLayer or None
    selectionLayerChanged = pyqtSignal(object)
    predicatesChanged = pyqtSignal(list)
    outputNameChanged = pyqtSignal(str)
    autoUpdateToggled = pyqtSignal(bool)
    periodicRefreshChanged = pyqtSignal(bool, int)  # enabled, interval seconds
    recalcRequested = pyqtSignal()

    def __init__(self, iface, parent=None):
        super().__init__("Dynamic Spatial Query", parent)
        self.iface = iface
        self.setObjectName("DynamicSpatialQueryPanel")

        container = QWidget(self)
        layout = QVBoxLayout(container)

        layout.addWidget(QLabel("Subject layer (features to extract):"))
        self.subject_combo = QgsMapLayerComboBox()
        self.subject_combo.setFilters(QgsMapLayerProxyModel.VectorLayer)
        self.subject_combo.layerChanged.connect(self.subjectLayerChanged.emit)
        layout.addWidget(self.subject_combo)

        layout.addWidget(QLabel("Selection layer (tested against):"))
        self.selection_combo = QgsMapLayerComboBox()
        self.selection_combo.setFilters(QgsMapLayerProxyModel.VectorLayer)
        self.selection_combo.layerChanged.connect(self.selectionLayerChanged.emit)
        layout.addWidget(self.selection_combo)

        pred_box = QGroupBox("Keep subject features that... (any checked = match)")
        pred_layout = QGridLayout()
        self.predicate_checks = {}
        for i, name in enumerate(PREDICATES):
            cb = QCheckBox(name)
            cb.setChecked(name == "Intersects")
            cb.toggled.connect(self._on_predicate_toggled)
            self.predicate_checks[name] = cb
            pred_layout.addWidget(cb, i // 2, i % 2)
        pred_box.setLayout(pred_layout)
        layout.addWidget(pred_box)

        out_row = QHBoxLayout()
        out_row.addWidget(QLabel("Output name:"))
        self.output_name_edit = QLineEdit("query_result")
        self.output_name_edit.editingFinished.connect(
            lambda: self.outputNameChanged.emit(self.output_name_edit.text())
        )
        out_row.addWidget(self.output_name_edit)
        layout.addLayout(out_row)

        self.auto_update_check = QCheckBox("Auto-update on changes")
        self.auto_update_check.setChecked(True)
        self.auto_update_check.toggled.connect(self.autoUpdateToggled.emit)
        layout.addWidget(self.auto_update_check)

        periodic_row = QHBoxLayout()
        self.periodic_check = QCheckBox("Also refresh every")
        self.periodic_check.toggled.connect(self._on_periodic_changed)
        periodic_row.addWidget(self.periodic_check)
        self.periodic_spin = QSpinBox()
        self.periodic_spin.setRange(5, 3600)
        self.periodic_spin.setValue(30)
        self.periodic_spin.setSuffix(" s")
        self.periodic_spin.valueChanged.connect(self._on_periodic_changed)
        periodic_row.addWidget(self.periodic_spin)
        periodic_row.addStretch()
        layout.addLayout(periodic_row)

        recalc_btn = QPushButton("Recalculate now")
        recalc_btn.clicked.connect(self.recalcRequested.emit)
        layout.addWidget(recalc_btn)

        self.status_label = QLabel("Ready")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        layout.addStretch()
        container.setLayout(layout)
        self.setWidget(container)

    # -- internal handlers --------------------------------------------

    def _on_predicate_toggled(self, _checked):
        self.predicatesChanged.emit(self.selected_predicates())

    def _on_periodic_changed(self, *_args):
        self.periodicRefreshChanged.emit(self.periodic_check.isChecked(), self.periodic_spin.value())

    # -- public accessors used by the plugin controller ------------------

    def subject_layer(self):
        return self.subject_combo.currentLayer()

    def selection_layer(self):
        return self.selection_combo.currentLayer()

    def selected_predicates(self):
        return [name for name, cb in self.predicate_checks.items() if cb.isChecked()]

    def auto_update_enabled(self):
        return self.auto_update_check.isChecked()

    def set_status(self, text):
        self.status_label.setText(text)
