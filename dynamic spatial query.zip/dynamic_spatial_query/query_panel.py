"""
Dock widget: a table of every query that's actually been created
(clicking a row loads it below for viewing/editing), then the
subject/selection layer pickers, predicates, and controls for
whichever query is currently loaded -- either an existing one (row
clicked, or its subject layer picked in the combo) or a brand new
draft that doesn't exist yet.

Nothing is created just by picking layers here -- see plugin.py's
primaryActionRequested handling. Picking layers/predicates/a name
only edits the draft shown in these controls; the plugin decides
whether that means "update an existing query" (if one is currently
loaded) or leaves it as a draft until primaryActionRequested fires
("Создать" / Create).

Internal predicate keys stay in English (matching
spatial_query_engine.PREDICATES) regardless of display language --
PREDICATE_LABELS_RU below is presentation-only, so stored/read
custom properties and the engine's own logic never see Russian text.
"""

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.core import QgsMapLayerProxyModel
from qgis.gui import QgsMapLayerComboBox
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QDockWidget,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .spatial_query_engine import PREDICATES

PREDICATE_LABELS_RU = {
    "Intersects": "Пересекает",
    "Within": "Строго внутри",
    "Contains": "Содержит",
    "Overlaps": "Перекрывает",
    "Touches": "Касается",
    "Equals": "Совпадает",
    "Crosses": "Пересекает (линией)",
    "Disjoint": "Не пересекает",
}

TABLE_COLUMNS = ["Слой-результат", "Целевой слой", "Слой выборки", "Статус"]


class QueryPanel(QDockWidget):
    subjectLayerChanged = pyqtSignal(object)   # QgsVectorLayer or None
    selectionLayerChanged = pyqtSignal(object)
    predicatesChanged = pyqtSignal(list)
    outputNameChanged = pyqtSignal(str)
    autoUpdateToggled = pyqtSignal(bool)
    periodicRefreshChanged = pyqtSignal(bool, int)  # enabled, interval seconds
    primaryActionRequested = pyqtSignal()           # "Создать" or "Пересчитать сейчас"
    removeRequested = pyqtSignal()
    queryRowSelected = pyqtSignal(str)              # registry key of the clicked row

    def __init__(self, iface, parent=None):
        super().__init__("Динамический пространственный запрос", parent)
        self.iface = iface
        self.setObjectName("DynamicSpatialQueryPanel")

        container = QWidget(self)
        layout = QVBoxLayout(container)

        self.table_label = QLabel("Активные запросы (0):")
        layout.addWidget(self.table_label)
        self.query_table = QTableWidget(0, len(TABLE_COLUMNS))
        self.query_table.setHorizontalHeaderLabels(TABLE_COLUMNS)
        self.query_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.query_table.verticalHeader().setVisible(False)
        self.query_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.query_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.query_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.query_table.setMaximumHeight(160)
        self.query_table.itemSelectionChanged.connect(self._on_table_selection_changed)
        layout.addWidget(self.query_table)

        layout.addWidget(QLabel("Целевой слой (объекты для извлечения):"))
        self.subject_combo = QgsMapLayerComboBox()
        self.subject_combo.setFilters(QgsMapLayerProxyModel.VectorLayer)
        self.subject_combo.layerChanged.connect(self.subjectLayerChanged.emit)
        layout.addWidget(self.subject_combo)

        layout.addWidget(QLabel("Слой выборки (проверка по нему):"))
        self.selection_combo = QgsMapLayerComboBox()
        self.selection_combo.setFilters(QgsMapLayerProxyModel.VectorLayer)
        self.selection_combo.layerChanged.connect(self.selectionLayerChanged.emit)
        layout.addWidget(self.selection_combo)

        pred_box = QGroupBox("Оставить объекты целевого слоя, которые... (совпадение по любому отмеченному)")
        pred_layout = QGridLayout()
        self.predicate_checks = {}
        for i, name in enumerate(PREDICATES):
            cb = QCheckBox(PREDICATE_LABELS_RU.get(name, name))
            cb.setChecked(name == "Intersects")
            cb.toggled.connect(self._on_predicate_toggled)
            self.predicate_checks[name] = cb
            pred_layout.addWidget(cb, i // 2, i % 2)
        pred_box.setLayout(pred_layout)
        layout.addWidget(pred_box)

        out_row = QHBoxLayout()
        out_row.addWidget(QLabel("Имя результата:"))
        self.output_name_edit = QLineEdit("query_result")
        self.output_name_edit.editingFinished.connect(
            lambda: self.outputNameChanged.emit(self.output_name_edit.text())
        )
        out_row.addWidget(self.output_name_edit)
        layout.addLayout(out_row)

        self.auto_update_check = QCheckBox("Автообновление при изменениях")
        self.auto_update_check.setChecked(True)
        self.auto_update_check.toggled.connect(self.autoUpdateToggled.emit)
        layout.addWidget(self.auto_update_check)

        periodic_row = QHBoxLayout()
        self.periodic_check = QCheckBox("Также обновлять каждые")
        self.periodic_check.toggled.connect(self._on_periodic_changed)
        periodic_row.addWidget(self.periodic_check)
        self.periodic_spin = QSpinBox()
        self.periodic_spin.setRange(5, 3600)
        self.periodic_spin.setValue(30)
        self.periodic_spin.setSuffix(" с")
        self.periodic_spin.valueChanged.connect(self._on_periodic_changed)
        periodic_row.addWidget(self.periodic_spin)
        periodic_row.addStretch()
        layout.addLayout(periodic_row)

        action_row = QHBoxLayout()
        self.primary_action_btn = QPushButton("Создать")
        self.primary_action_btn.clicked.connect(self.primaryActionRequested.emit)
        action_row.addWidget(self.primary_action_btn)
        self.remove_btn = QPushButton("Удалить")
        self.remove_btn.setEnabled(False)
        self.remove_btn.clicked.connect(self.removeRequested.emit)
        action_row.addWidget(self.remove_btn)
        layout.addLayout(action_row)

        self.status_label = QLabel("Готово")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        layout.addStretch()
        container.setLayout(layout)
        self.setWidget(container)

        self._row_keys = []  # table row index -> registry key, kept in sync with refresh_query_table()

    # -- internal handlers --------------------------------------------

    def _on_predicate_toggled(self, _checked):
        self.predicatesChanged.emit(self.selected_predicates())

    def _on_periodic_changed(self, *_args):
        self.periodicRefreshChanged.emit(self.periodic_check.isChecked(), self.periodic_spin.value())

    def _on_table_selection_changed(self):
        rows = self.query_table.selectionModel().selectedRows()
        if not rows:
            return
        row = rows[0].row()
        if 0 <= row < len(self._row_keys):
            self.queryRowSelected.emit(self._row_keys[row])

    # -- public accessors used by the plugin controller ------------------

    def subject_layer(self):
        return self.subject_combo.currentLayer()

    def selection_layer(self):
        return self.selection_combo.currentLayer()

    def selected_predicates(self):
        return [name for name, cb in self.predicate_checks.items() if cb.isChecked()]

    def output_name(self):
        return self.output_name_edit.text()

    def auto_update_enabled(self):
        return self.auto_update_check.isChecked()

    def set_status(self, text):
        self.status_label.setText(text)

    def set_primary_action_label(self, text):
        self.primary_action_btn.setText(text)

    def set_remove_enabled(self, enabled):
        self.remove_btn.setEnabled(enabled)

    def refresh_query_table(self, rows):
        """
        rows: list of (key, output_name, subject_name, selection_name,
        status_text) tuples, one per currently-registered query.
        """
        self.table_label.setText(f"Активные запросы ({len(rows)}):")
        self._row_keys = [r[0] for r in rows]
        self.query_table.setRowCount(len(rows))
        for i, (_key, output_name, subject_name, selection_name, status_text) in enumerate(rows):
            for col, value in enumerate([output_name, subject_name, selection_name, status_text]):
                item = QTableWidgetItem(value)
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.query_table.setItem(i, col, item)

    def select_table_row_for_key(self, key):
        """Highlights the row for `key` without re-emitting
        queryRowSelected (the caller already knows what it wants)."""
        self.query_table.blockSignals(True)
        try:
            if key in self._row_keys:
                self.query_table.selectRow(self._row_keys.index(key))
            else:
                self.query_table.clearSelection()
        finally:
            self.query_table.blockSignals(False)

    def load_query_state(self, selection_layer, predicates, output_name,
                          auto_update_enabled, periodic_enabled, periodic_seconds):
        """
        Repopulates every control except the subject dropdown (the
        caller already knows the subject layer) to reflect an
        EXISTING query, without each widget re-announcing its own
        change signal as it's set.
        """
        self.selection_combo.blockSignals(True)
        self.selection_combo.setLayer(selection_layer)
        self.selection_combo.blockSignals(False)

        for name, cb in self.predicate_checks.items():
            cb.blockSignals(True)
            cb.setChecked(name in predicates)
            cb.blockSignals(False)

        self.output_name_edit.blockSignals(True)
        self.output_name_edit.setText(output_name)
        self.output_name_edit.blockSignals(False)

        self.auto_update_check.blockSignals(True)
        self.auto_update_check.setChecked(auto_update_enabled)
        self.auto_update_check.blockSignals(False)

        self.periodic_check.blockSignals(True)
        self.periodic_check.setChecked(periodic_enabled)
        self.periodic_check.blockSignals(False)

        self.periodic_spin.blockSignals(True)
        self.periodic_spin.setValue(periodic_seconds)
        self.periodic_spin.blockSignals(False)

    def clear_draft(self):
        """Resets everything except the subject combo back to
        defaults -- used after a query is removed, or when the
        currently-picked subject layer has no query yet and there's
        nothing sensible left over to show."""
        self.selection_combo.blockSignals(True)
        self.selection_combo.setLayer(None)
        self.selection_combo.blockSignals(False)

        for name, cb in self.predicate_checks.items():
            cb.blockSignals(True)
            cb.setChecked(name == "Intersects")
            cb.blockSignals(False)

        self.output_name_edit.blockSignals(True)
        self.output_name_edit.setText("query_result")
        self.output_name_edit.blockSignals(False)

        self.auto_update_check.blockSignals(True)
        self.auto_update_check.setChecked(True)
        self.auto_update_check.blockSignals(False)

        self.periodic_check.blockSignals(True)
        self.periodic_check.setChecked(False)
        self.periodic_check.blockSignals(False)
