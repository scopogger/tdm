"""
The reported problem: creating several module output layers, only
the one currently selected in the panel kept auto-updating. Root
cause was a single shared engine+watcher pair getting reconfigured
every time the panel's subject layer changed, abandoning whatever it
was previously watching. Fixed via a registry -- one independent
engine+watcher per distinct subject layer, in plugin.py.
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from _test_helpers import wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


def settle(plugin, key, timeout_s=5.0):
    return wait_for(
        lambda: key in plugin._queries and plugin._queries[key].engine._task is None,
        timeout_s,
    )


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
zone.dataProvider().addFeatures([zf])

buildings = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "buildings", "memory")
bf = QgsFeature(buildings.fields())
bf.setGeometry(QgsGeometry.fromWkt("POINT(10 10)"))
bf.setAttribute("name", "b0")
buildings.dataProvider().addFeatures([bf])

roads = QgsVectorLayer("LineString?crs=EPSG:3857&field=name:string", "roads", "memory")
rf = QgsFeature(roads.fields())
rf.setGeometry(QgsGeometry.fromWkt("LINESTRING(5 5, 15 15)"))
rf.setAttribute("name", "r0")
roads.dataProvider().addFeatures([rf])

project.addMapLayers([zone, buildings, roads], False)
for lyr in (zone, buildings, roads):
    project.layerTreeRoot().addLayer(lyr)

print("=" * 70)
print("1. Configure query A (buildings), then query B (roads), via the panel")
print("=" * 70)

plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()

plugin.panel.subject_combo.setLayer(buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)
key_a = buildings.id()
check("query A registered", settle(plugin, key_a), "timed out")
# Distinct output name, both because a real user creating two
# different queries would naturally give them different names, and
# because leaving both at the default "query_result" makes any
# by-name lookup after reload ambiguous -- confirmed the hard way,
# this flip-flopped pass/fail across repeated runs before being
# tracked down to exactly that.
plugin.panel.output_name_edit.setText("buildings_in_zone")
plugin.panel.output_name_edit.editingFinished.emit()
check("query A found 1 building", plugin._queries[key_a].engine._output_layer.featureCount() == 1,
      plugin._queries[key_a].engine._output_layer.featureCount())

plugin.panel.subject_combo.setLayer(roads)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)
key_b = roads.id()
check("query B registered", settle(plugin, key_b), "timed out")
plugin.panel.output_name_edit.setText("roads_in_zone")
plugin.panel.output_name_edit.editingFinished.emit()
check("query B found 1 road", plugin._queries[key_b].engine._output_layer.featureCount() == 1,
      plugin._queries[key_b].engine._output_layer.featureCount())

check("both queries are tracked simultaneously", len(plugin._queries) == 2, len(plugin._queries))
check("panel reports 2 queries running", "2 queries" in plugin.panel.query_count_label.text(),
      plugin.panel.query_count_label.text())

print()
print("=" * 70)
print("2. THE ACTUAL BUG: editing A's source layer while B is the one shown in the panel")
print("=" * 70)

check("panel is currently showing query B (roads)", plugin._current_key == key_b)

buildings.startEditing()
nb = QgsFeature(buildings.fields())
nb.setGeometry(QgsGeometry.fromWkt("POINT(20 20)"))
nb.setAttribute("name", "b1")
buildings.addFeature(nb)
buildings.commitChanges()

ok = wait_for(
    lambda: plugin._queries[key_a].engine._output_layer.featureCount() == 2,
    5.0,
)
check("query A's output updated to 2 buildings WITHOUT being selected in the panel "
      "(this is the exact behavior that was reported broken)", ok,
      plugin._queries[key_a].engine._output_layer.featureCount())
check("query B's output is untouched by A's edit", plugin._queries[key_b].engine._output_layer.featureCount() == 1,
      plugin._queries[key_b].engine._output_layer.featureCount())

print()
print("=" * 70)
print("3. Switching the panel back to A repopulates its own settings, not B's leftovers")
print("=" * 70)

plugin.panel.subject_combo.setLayer(buildings)
QCoreApplication.processEvents()
check("panel's selection combo shows A's own selection layer (zone), not something stale",
      plugin.panel.selection_layer() is zone)
check("panel's predicates show A's own predicates", plugin.panel.selected_predicates() == ["Intersects"])

print()
print("=" * 70)
print("4. Editing B's source layer while A is now shown updates B too")
print("=" * 70)

roads.startEditing()
nr = QgsFeature(roads.fields())
nr.setGeometry(QgsGeometry.fromWkt("LINESTRING(50 50, 60 60)"))
nr.setAttribute("name", "r1")
roads.addFeature(nr)
roads.commitChanges()

ok = wait_for(lambda: plugin._queries[key_b].engine._output_layer.featureCount() == 2, 5.0)
check("query B's output updated to 2 roads while A was the one shown in the panel", ok,
      plugin._queries[key_b].engine._output_layer.featureCount())

print()
print("=" * 70)
print("5. Both queries survive a real project reload and resume updating")
print("=" * 70)

key_a_out_name = plugin._queries[key_a].engine._output_layer.name()
key_b_out_name = plugin._queries[key_b].engine._output_layer.name()

save_path = "/tmp/dsq_multiquery_test_project.qgs"
project.write(save_path)

plugin.unload()
project.clear()
project.read(save_path)

reloaded_buildings = next(lyr for lyr in project.mapLayers().values() if lyr.name() == "buildings")
reloaded_roads = next(lyr for lyr in project.mapLayers().values() if lyr.name() == "roads")
reloaded_out_a = next(lyr for lyr in project.mapLayers().values() if lyr.name() == key_a_out_name)
reloaded_out_b = next(lyr for lyr in project.mapLayers().values() if lyr.name() == key_b_out_name)
check("query A's output survived reload with its 2 buildings", reloaded_out_a.featureCount() == 2,
      reloaded_out_a.featureCount())
check("query B's output survived reload with its 2 roads", reloaded_out_b.featureCount() == 2,
      reloaded_out_b.featureCount())

# Memory-layer source data (buildings/roads/zone) does NOT survive --
# re-seed exactly as before saving, then confirm a FRESH plugin
# instance (new QGIS session, in spirit) re-arms BOTH queries without
# either one being "selected" in the panel first.
reloaded_zone = next(lyr for lyr in project.mapLayers().values() if lyr.name() == "zone")
nzf = QgsFeature(reloaded_zone.fields())
nzf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
reloaded_zone.dataProvider().addFeatures([nzf])
for f in [bf, nb]:
    nf = QgsFeature(reloaded_buildings.fields())
    nf.setGeometry(f.geometry())
    nf.setAttribute("name", f["name"])
    reloaded_buildings.dataProvider().addFeatures([nf])
for f in [rf, nr]:
    nf = QgsFeature(reloaded_roads.fields())
    nf.setGeometry(f.geometry())
    nf.setAttribute("name", f["name"])
    reloaded_roads.dataProvider().addFeatures([nf])

plugin2 = DynamicSpatialQueryPlugin(iface)
plugin2.initGui()  # this alone must restore + re-arm both queries, no panel interaction
QCoreApplication.processEvents()

check("both queries were restored on load without any panel interaction",
      len(plugin2._queries) == 2, len(plugin2._queries))

key_a2 = reloaded_buildings.id()
key_b2 = reloaded_roads.id()
check("restored query A reattached to the same (reloaded) output layer",
      plugin2._queries[key_a2].engine._output_layer.id() == reloaded_out_a.id())

# Edit buildings again -- reloaded_buildings is a plain memory layer,
# so a THIRD building added now, with plugin2's watcher armed from
# initGui() alone (no combo box ever touched) must still propagate.
reloaded_buildings.startEditing()
nb2 = QgsFeature(reloaded_buildings.fields())
nb2.setGeometry(QgsGeometry.fromWkt("POINT(30 30)"))
nb2.setAttribute("name", "b2")
reloaded_buildings.addFeature(nb2)
reloaded_buildings.commitChanges()

ok = wait_for(lambda: plugin2._queries[key_a2].engine._output_layer.featureCount() == 3, 5.0)
check("post-reload, query A updates on its own even though nothing was ever selected in the panel",
      ok, plugin2._queries[key_a2].engine._output_layer.featureCount())

plugin2.unload()

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
