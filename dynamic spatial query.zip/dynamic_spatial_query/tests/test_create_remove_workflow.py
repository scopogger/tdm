"""
This turn's actual changes, tested directly:

1. Nothing gets created just by enabling the plugin or picking layers
   in the panel -- only an explicit click of the primary button
   ("Создать"/Create) registers a query and creates its output layer.
2. The primary button's label and the Remove button's enabled state
   track whether the currently-shown subject layer already has a
   registered query or is still an unsaved draft.
3. Removing a query works two equivalent ways: the panel's "Удалить"
   button, or deleting its output layer directly from the project
   (simulating the user doing it via QGIS's own Layers panel) -- both
   must stop that query's watcher and drop it from the registry.
4. Deleting a query's SUBJECT or SELECTION layer (not its output)
   also tears the query down (it can't function without them), but
   leaves its last-computed output layer in place rather than also
   deleting it.
5. The management table reflects reality: one row per registered
   query, and clicking a row loads that query for editing.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin, LABEL_CREATE, LABEL_RECALCULATE  # noqa: E402
from _test_helpers import wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


def settle(plugin, key, timeout_s=5.0):
    return wait_for(
        lambda: key in plugin._queries and plugin._queries[key].engine._task is None,
        timeout_s,
    )


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
zone.dataProvider().addFeatures([zf])

buildings = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "buildings", "memory")
bf = QgsFeature(buildings.fields())
bf.setGeometry(QgsGeometry.fromWkt("POINT(10 10)"))
bf.setAttribute("name", "b0")
buildings.dataProvider().addFeatures([bf])

roads = QgsVectorLayer("LineString?crs=EPSG:3857&field=name:string", "roads", "memory")
rf = QgsFeature(roads.fields())
rf.setGeometry(QgsGeometry.fromWkt("LINESTRING(5 5, 15 15)"))
rf.setAttribute("name", "r0")
roads.dataProvider().addFeatures([rf])

project.addMapLayers([zone, buildings, roads], False)
for lyr in (zone, buildings, roads):
    project.layerTreeRoot().addLayer(lyr)

print("=" * 70)
print("1. Enabling the plugin with layers already present creates NOTHING")
print("=" * 70)

layer_count_before = len(project.mapLayers())
plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()
QCoreApplication.processEvents()

check("no queries registered just from initGui()", len(plugin._queries) == 0)
check("no new layers were added to the project", len(project.mapLayers()) == layer_count_before,
      len(project.mapLayers()))
check("no output group was created", project.layerTreeRoot().findGroup("Результаты динамических запросов") is None)
check("primary button reads 'Создать' by default", plugin.panel.primary_action_btn.text() == LABEL_CREATE)
check("remove button is disabled by default", not plugin.panel.remove_btn.isEnabled())

print()
print("=" * 70)
print("2. Picking layers in the panel is still just a draft -- no creation yet")
print("=" * 70)

plugin.panel.subject_combo.setLayer(buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)
QCoreApplication.processEvents()

check("still no query registered after picking both layers", len(plugin._queries) == 0)
check("still no new layers in the project", len(project.mapLayers()) == layer_count_before)
check("button still reads 'Создать'", plugin.panel.primary_action_btn.text() == LABEL_CREATE)

print()
print("=" * 70)
print("3. Clicking 'Создать' (Create) actually creates the query")
print("=" * 70)

plugin.panel.primaryActionRequested.emit()
key_a = buildings.id()
ok = settle(plugin, key_a)
check("query A now registered after Create", ok)
check("output layer was created", plugin._queries[key_a].engine._output_layer is not None)
check("output group now exists", project.layerTreeRoot().findGroup("Результаты динамических запросов") is not None)
check("button switched to 'Пересчитать сейчас'", plugin.panel.primary_action_btn.text() == LABEL_RECALCULATE)
check("remove button is now enabled", plugin.panel.remove_btn.isEnabled())
check("management table shows 1 row", plugin.panel.query_table.rowCount() == 1,
      plugin.panel.query_table.rowCount())
check("table row shows the Russian 'Активен' status",
      plugin.panel.query_table.item(0, 3).text() == "Активен", plugin.panel.query_table.item(0, 3).text())

print()
print("=" * 70)
print("4. Switching to a brand new subject shows a fresh draft, not auto-created")
print("=" * 70)

plugin.panel.subject_combo.setLayer(roads)
QCoreApplication.processEvents()
check("no second query created just by switching the subject combo", len(plugin._queries) == 1)
check("button reads 'Создать' again for the new (uncreated) subject",
      plugin.panel.primary_action_btn.text() == LABEL_CREATE)
check("remove button disabled again for the draft", not plugin.panel.remove_btn.isEnabled())

plugin.panel.selection_combo.setLayer(zone)
plugin.panel.primaryActionRequested.emit()
key_b = roads.id()
ok = settle(plugin, key_b)
check("query B created on explicit request", ok)
check("both queries coexist", len(plugin._queries) == 2, len(plugin._queries))
check("management table now shows 2 rows", plugin.panel.query_table.rowCount() == 2)

print()
print("=" * 70)
print("5. Clicking a table row loads that query back into the editor")
print("=" * 70)

row_for_a = plugin.panel._row_keys.index(key_a)
plugin.panel.query_table.selectRow(row_for_a)
QCoreApplication.processEvents()
check("selecting query A's row switches the panel back to it", plugin._current_key == key_a)
check("panel shows A's own selection layer", plugin.panel.selection_layer() is zone)
check("button reads 'Пересчитать сейчас' for the now-loaded existing query",
      plugin.panel.primary_action_btn.text() == LABEL_RECALCULATE)

print()
print("=" * 70)
print("6. Removing via the panel button tears the query down properly")
print("=" * 70)

output_a_id = plugin._queries[key_a].engine._output_layer.id()
plugin.panel.removeRequested.emit()
QCoreApplication.processEvents()

check("query A removed from the registry", key_a not in plugin._queries)
check("query A's output layer removed from the project", project.mapLayer(output_a_id) is None)
check("query B is untouched", key_b in plugin._queries)
check("management table now shows only 1 row", plugin.panel.query_table.rowCount() == 1)
check("button reset to 'Создать' after removal", plugin.panel.primary_action_btn.text() == LABEL_CREATE)

print()
print("=" * 70)
print("7. Deleting a query's output layer directly (simulating QGIS's own Layers panel)")
print("=" * 70)

output_b = plugin._queries[key_b].engine._output_layer
output_b_id = output_b.id()
project.removeMapLayer(output_b_id)  # NOT through the plugin's Remove button
QCoreApplication.processEvents()

check("query B's registry entry was cleaned up reactively", key_b not in plugin._queries)
check("management table is now empty", plugin.panel.query_table.rowCount() == 0)

print()
print("=" * 70)
print("8. Deleting a query's SUBJECT layer tears the query down, output layer left alone")
print("=" * 70)

parcels = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "parcels", "memory")
pf = QgsFeature(parcels.fields())
pf.setGeometry(QgsGeometry.fromWkt("POINT(50 50)"))
pf.setAttribute("name", "p0")
parcels.dataProvider().addFeatures([pf])
project.addMapLayers([parcels], False)
project.layerTreeRoot().addLayer(parcels)

plugin.panel.subject_combo.setLayer(parcels)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)
plugin.panel.primaryActionRequested.emit()
key_c = parcels.id()
ok = settle(plugin, key_c)
check("query C created", ok)
output_c_id = plugin._queries[key_c].engine._output_layer.id()

project.removeMapLayer(parcels.id())  # remove the SUBJECT, not the output
QCoreApplication.processEvents()

check("query C torn down when its subject layer was deleted", key_c not in plugin._queries)
check("query C's output layer was NOT force-deleted (still in the project)",
      project.mapLayer(output_c_id) is not None)

plugin.unload()

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
