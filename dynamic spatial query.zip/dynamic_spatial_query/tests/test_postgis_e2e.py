"""
Real Postgres + PostGIS, adapted from the sibling plugin's proven
test to the new subject/selection architecture. Confirms: an INSERT
from a totally separate database connection reaches ReactiveWatcher
via provider.notify and produces a corrected SpatialQueryEngine
result -- now for a PostGIS layer that ALSO has a subset string
filter applied, since that's the scenario actually asked for.
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsDataSourceUri,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)
import psycopg2  # noqa: E402

from dynamic_spatial_query.spatial_query_engine import SpatialQueryEngine  # noqa: E402
from dynamic_spatial_query.reactive_watcher import ReactiveWatcher  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


def wait_for(predicate, timeout_s):
    deadline = time.time() + timeout_s
    while time.time() < deadline and not predicate():
        QCoreApplication.processEvents()
        time.sleep(0.02)
    return predicate()


# Self-contained setup + reset (same pattern as the sibling plugin's
# tests): a 'planning_objects' table with a type column, so we can
# both filter it (subset string) AND edit it externally.
_reset_conn = psycopg2.connect(
    host="localhost", port=5432, dbname="qgis_test", user="postgres", password="postgres"
)
_reset_conn.autocommit = True
_reset_cur = _reset_conn.cursor()
_reset_cur.execute("""
    CREATE TABLE IF NOT EXISTS public.planning_objects (
        id serial PRIMARY KEY,
        objtype text,
        geom geometry(Point, 3857)
    )
""")
_reset_cur.execute("""
    CREATE OR REPLACE FUNCTION public.notify_qgis() RETURNS trigger AS $$
    BEGIN
      NOTIFY qgis;
      RETURN NULL;
    END;
    $$ LANGUAGE plpgsql
""")
_reset_cur.execute("DROP TRIGGER IF EXISTS planning_objects_notify_qgis ON public.planning_objects")
_reset_cur.execute("""
    CREATE TRIGGER planning_objects_notify_qgis
    AFTER INSERT OR UPDATE OR DELETE ON public.planning_objects
    FOR EACH STATEMENT EXECUTE FUNCTION public.notify_qgis()
""")
_reset_cur.execute("TRUNCATE public.planning_objects RESTART IDENTITY")
_reset_cur.execute(
    "INSERT INTO public.planning_objects (objtype, geom) VALUES (%s, ST_SetSRID(ST_MakePoint(5,5), 3857))",
    ("building",),
)
_reset_cur.close()
_reset_conn.close()

iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

uri = QgsDataSourceUri()
uri.setConnection("localhost", "5432", "qgis_test", "postgres", "postgres")
uri.setDataSource("public", "planning_objects", "geom", "", "id")
pg_layer = QgsVectorLayer(uri.uri(False), "planning_objects", "postgres")
check("PostGIS layer loads and is valid", pg_layer.isValid())
pg_layer.setSubsetString("objtype = 'building'")
project.addMapLayers([pg_layer], False)

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,10 0,10 10,0 10,0 0))"))
zone.dataProvider().addFeatures([zf])
project.addMapLayers([zone], False)

engine = SpatialQueryEngine(iface)
engine.set_subject_layer(pg_layer)
engine.set_selection_layer(zone)
engine.set_predicates(["Intersects"])

result = {}
engine.recalculate(on_done=lambda c, e: result.update(count=c, error=e))
check("initial recalculate against the filtered PostGIS layer succeeds",
      result.get("error") is None, str(result.get("error")))
check("initial recalculate finds exactly 1 building in range", result.get("count") == 1,
      result.get("count"))

watcher = ReactiveWatcher()
watcher.watch([pg_layer, zone])
changed = {"n": 0}
watcher.sourceDataChanged.connect(lambda: changed.__setitem__("n", changed["n"] + 1))

# A separate process/session inserts ANOTHER building inside the zone,
# with nothing routed through this QGIS session.
conn = psycopg2.connect(host="localhost", port=5432, dbname="qgis_test", user="postgres", password="postgres")
conn.autocommit = True
cur = conn.cursor()
cur.execute(
    "INSERT INTO public.planning_objects (objtype, geom) VALUES (%s, ST_SetSRID(ST_MakePoint(6,6), 3857))",
    ("building",),
)
# also insert a road at the same time -- must NOT show up, the subset
# string should keep excluding it even after this edit
cur.execute(
    "INSERT INTO public.planning_objects (objtype, geom) VALUES (%s, ST_SetSRID(ST_MakePoint(7,7), 3857))",
    ("road",),
)
cur.close()
conn.close()
print("external INSERT of 1 building + 1 road, committed from a separate connection")

ok = wait_for(lambda: changed["n"] > 0, 6.0)
check("watcher's sourceDataChanged fired from the external insert alone", ok)

result2 = {}
engine.recalculate(on_done=lambda c, e: result2.update(count=c, error=e))
check("recalculate after the external edit finds 2 buildings (not 3 -- the road stays filtered out)",
      result2.get("count") == 2, result2.get("count"))

watcher.stop()

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED -- external PostgreSQL edits reach a *filtered* subject layer correctly")
