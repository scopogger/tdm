"""
Covers what test_engine.py doesn't: the reactive watcher's signals
(including the two new ones -- attribute changes and subset-string/
filter changes -- that the polygon-drawing predecessor didn't need),
the periodic-refresh timer, and the full plugin wired up through
QueryPanel's actual widgets.
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.reactive_watcher import ReactiveWatcher  # noqa: E402
from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


def wait_for(predicate, timeout_s):
    deadline = time.time() + timeout_s
    while time.time() < deadline and not predicate():
        QCoreApplication.processEvents()
        time.sleep(0.02)
    return predicate()


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

subject = QgsVectorLayer("Point?crs=EPSG:3857&field=type:string", "subject", "memory")
sf1 = QgsFeature(subject.fields())
sf1.setGeometry(QgsGeometry.fromWkt("POINT(5 5)"))
sf1.setAttribute("type", "building")
subject.dataProvider().addFeatures([sf1])

selection = QgsVectorLayer("Polygon?crs=EPSG:3857", "selection", "memory")
selfeat = QgsFeature(selection.fields())
selfeat.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,10 0,10 10,0 10,0 0))"))
selection.dataProvider().addFeatures([selfeat])
project.addMapLayers([subject, selection], False)

print("=" * 70)
print("1. WATCHER: committed feature add fires (regression check vs sibling plugin)")
print("=" * 70)

watcher = ReactiveWatcher()
watcher.watch([subject, selection])
check("not scheduled before any edit", not watcher._timer.isActive())

subject.startEditing()
new_feat = QgsFeature(subject.fields())
new_feat.setGeometry(QgsGeometry.fromWkt("POINT(6 6)"))
new_feat.setAttribute("type", "road")
subject.addFeature(new_feat)  # through the edit buffer, not dataProvider() directly
subject.commitChanges()
check("committing a new feature schedules the debounce timer", watcher._timer.isActive())

fired = {"n": 0}
watcher.sourceDataChanged.connect(lambda: fired.__setitem__("n", fired["n"] + 1))
ok = wait_for(lambda: fired["n"] > 0, ReactiveWatcher.DEBOUNCE_MS / 1000.0 + 1.0)
check("sourceDataChanged fires after the debounce window", ok)

print()
print("=" * 70)
print("2. WATCHER: attribute-only change fires (new requirement, not in predecessor)")
print("=" * 70)

fired["n"] = 0
target_fid = next(f.id() for f in subject.getFeatures() if f["type"] == "building")
subject.startEditing()
subject.changeAttributeValue(target_fid, subject.fields().indexOf("type"), "landmark")
subject.commitChanges()
ok = wait_for(lambda: fired["n"] > 0, ReactiveWatcher.DEBOUNCE_MS / 1000.0 + 1.0)
check("attribute-only edit (no geometry change) still triggers sourceDataChanged", ok)

print()
print("=" * 70)
print("3. WATCHER: subsetString (filter) change fires (new requirement)")
print("=" * 70)

fired["n"] = 0
ok_set = selection.setSubsetString("1=1")  # trivial but real filter change
check("setSubsetString applied", ok_set)
ok = wait_for(lambda: fired["n"] > 0, ReactiveWatcher.DEBOUNCE_MS / 1000.0 + 1.0)
check("changing a layer's filter condition triggers sourceDataChanged", ok)

watcher.stop()

print()
print("=" * 70)
print("4. WATCHER: periodic refresh timer fires independently of any edit")
print("=" * 70)

watcher2 = ReactiveWatcher()
fired2 = {"n": 0}
watcher2.sourceDataChanged.connect(lambda: fired2.__setitem__("n", fired2["n"] + 1))
watcher2.set_periodic_refresh(True, 1)  # minimum practical interval for a fast test... 1s
ok = wait_for(lambda: fired2["n"] > 0, 3.0)
check("periodic timer fires sourceDataChanged with no edits at all", ok)
watcher2.set_periodic_refresh(False, 1)
n_after_disable = fired2["n"]
time.sleep(1.5)
QCoreApplication.processEvents()
check("disabling periodic refresh actually stops it",
      fired2["n"] == n_after_disable, f"{fired2['n']} vs {n_after_disable}")
watcher2.stop()

print()
print("=" * 70)
print("5. FULL PLUGIN: initGui -> pick layers via the real combo widgets -> recalc -> unload")
print("=" * 70)

plugin = DynamicSpatialQueryPlugin(iface)
try:
    plugin.initGui()
    check("initGui() completes without error", True)
except Exception as exc:  # noqa: BLE001
    check("initGui() completes without error", False, repr(exc))
    raise

plugin.panel.subject_combo.setLayer(subject)
plugin.panel.selection_combo.setLayer(selection)
ok = wait_for(lambda: plugin._current_query() is not None and plugin._current_query().engine._task is None
              and "Calculating" not in plugin.panel.status_label.text(), 5.0)
check("plugin settles (background task finishes) within the timeout", ok)
current = plugin._current_query()
check("a query got registered for the picked subject layer", current is not None)
check("engine picked up the subject layer via the real combo signal",
      current.engine.subject_layer is subject)
check("engine picked up the selection layer via the real combo signal",
      current.engine.selection_layer is selection)
check("status reflects a completed calculation",
      "matching feature" in plugin.panel.status_label.text(),
      plugin.panel.status_label.text())

# both subject points (5,5) and (6,6) are inside the 0,0-10,10 selection
# square, and the subset string set earlier ("1=1") doesn't exclude it
check("both subject points matched (both are inside the selection square)",
      current.engine._output_layer.featureCount() == 2,
      current.engine._output_layer.featureCount() if current.engine._output_layer else None)

try:
    plugin.unload()
    check("unload() completes without error", True)
except Exception as exc:  # noqa: BLE001
    check("unload() completes without error", False, repr(exc))

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
