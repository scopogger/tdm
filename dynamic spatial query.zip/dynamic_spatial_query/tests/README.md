# Tests

Same approach as the polygon-drawing predecessor of this plugin
(`selection_intersector/tests/`): plain scripts run against a real
headless PyQGIS (3.34) with `QT_QPA_PLATFORM=offscreen`, no display
needed, `iface` mocked via QGIS's own `qgis.testing.mocked.get_iface()`
since that's the one thing that genuinely doesn't exist outside a
running QGIS Desktop.

| File | What it covers | Needs Postgres? |
|---|---|---|
| `test_engine.py` | All 8 predicates individually against a hand-built scene with known relationships, multi-predicate OR, original-attribute preservation, `__orig_fid` tracing, field-name-collision handling, subject==selection self-comparison, output layer rebuilding when the subject layer is swapped for a different geometry type | No |
| `test_watcher_and_plugin.py` | The two new reactivity triggers (attribute-only edits, subset-string/filter changes), the periodic-refresh timer, and the full plugin wired through the real `QgsMapLayerComboBox` widgets | No |
| `test_filter_scenario.py` | The exact scenario described in the brief: one layer holding mixed feature types, filtered down via `setSubsetString()` to "only buildings", confirming the query only ever sees the filtered rows and that changing the filter changes the result -- plus `Crosses`, which needs a line-vs-polygon scene the other tests don't happen to set up | No |
| `test_postgis_e2e.py` | Real Postgres + PostGIS: an INSERT from a **separate** database connection, against a **filtered** PostGIS subject layer, reaching `ReactiveWatcher` and producing a corrected result that still respects the filter | Yes |
| `test_async_and_reattach.py` | Two things borrowed from a colleague's plugin and adapted: (1) `recalculate()` now runs on a background `QgsTask` -- tests that overlapping calls don't race over the output layer and that only the last-requested callback ever fires; (2) `cancel()`'s safe-discard behaviour; (3) `_find_existing_output_layer()` reattaching to a previous output layer through a **real** `QgsProject.write()`/`read()` round trip, not just an in-memory check | No |

Setup for the Postgres-backed test is identical to the sibling
plugin's -- see `selection_intersector/tests/README.md` for the
`apt-get`/`createdb`/`CREATE EXTENSION postgis` commands. This test
also creates its own table/trigger on first run and resets its
contents at the start of every run, so it's safe to re-run repeatedly.

Run everything:

```bash
export QT_QPA_PLATFORM=offscreen
cd dynamic_spatial_query/tests
for f in test_engine.py test_watcher_and_plugin.py \
         test_filter_scenario.py test_postgis_e2e.py; do
    python3 "$f" || echo "FAILED: $f"
done
```

## What actually turned up while writing these

Worth knowing regardless of whether you keep these exact test files:
writing them for real (not just reasoning about the code) caught a
genuine bug that a documentation-only pass wouldn't have: the
bounding-box prefilter used to keep the other 7 predicates fast is
actively wrong for `Disjoint`, which structurally means "not matching
*any* selection feature" rather than "matching *some* selection
feature" like the rest -- the prefilter was silently discarding
exactly the subject features `Disjoint` should find. Fixed in
`spatial_query_engine.py`; `test_engine.py`'s "Disjoint matches only
F" check is what caught it, and stays in the suite as a regression
check.

## What this does not prove

Same caveats as the sibling plugin: QGIS 3.34 rather than your exact
3.32.2, Python 3.12 runtime rather than your target 3.9 (the plugin
source has no 3.10+-only syntax, checked separately), and a mocked
`iface` rather than a real Desktop window -- so toolbar/dock
appearance is still unverified.
