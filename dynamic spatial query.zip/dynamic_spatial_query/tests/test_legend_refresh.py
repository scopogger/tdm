"""
The Layers Panel's "Show Feature Count" display only refreshes off
committedFeaturesAdded/committedFeaturesRemoved -- confirmed directly
against real PyQGIS (see spatial_query_engine.py's _write_output
docstring), not just inferred from QGIS's bug tracker, though a
maintainer comment there says the same thing. This confirms the
engine's actual recalculate() path fires those signals correctly now
that it writes through a layer edit session instead of straight to
the data provider.
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.spatial_query_engine import SpatialQueryEngine  # noqa: E402
from _test_helpers import run_and_wait  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
zone.dataProvider().addFeatures([zf])

points = QgsVectorLayer("Point?crs=EPSG:3857&field=label:string", "points", "memory")
for i in range(5):
    f = QgsFeature(points.fields())
    f.setGeometry(QgsGeometry.fromWkt(f"POINT({i} {i})"))
    f.setAttribute("label", f"p{i}")
    points.dataProvider().addFeatures([f])

project.addMapLayers([zone, points], False)
project.layerTreeRoot().addLayer(zone)
project.layerTreeRoot().addLayer(points)

engine = SpatialQueryEngine(iface)
engine.set_subject_layer(points)
engine.set_selection_layer(zone)
engine.set_predicates(["Intersects"])

print("=" * 70)
print("1. First recalculation: creates the output layer and writes to it")
print("=" * 70)

count1, err1 = run_and_wait(engine)
check("first recalculation succeeds", err1 is None and count1 == 5, (count1, err1))

output_layer = engine._output_layer
added_events = []
removed_events = []
output_layer.committedFeaturesAdded.connect(lambda lid, feats: added_events.append(len(feats)))
output_layer.committedFeaturesRemoved.connect(lambda lid, fids: removed_events.append(len(fids)))

print()
print("=" * 70)
print("2. A second recalculation, now that listeners are attached, must fire commits")
print("=" * 70)

# Shrink the subject set's relevance by narrowing the zone, forcing a
# real change in the output (some features drop out) -- exercises
# both the delete and the add side of the same edit session.
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,3 0,3 3,0 3,0 0))"))
zone.dataProvider().changeGeometryValues({zf.id(): QgsGeometry.fromWkt("POLYGON((0 0,3 0,3 3,0 3,0 0))")})

count2, err2 = run_and_wait(engine)
check("second recalculation succeeds", err2 is None, err2)
check("committedFeaturesRemoved fired at least once (old features cleared)",
      len(removed_events) >= 1, removed_events)
check("committedFeaturesAdded fired at least once (new features written)",
      len(added_events) >= 1, added_events)

print()
print("=" * 70)
print("3. A no-op-looking recalculation (delete-all then add-all) still commits")
print("=" * 70)
# Even when the result set is identical in content, the engine always
# clears and rewrites -- confirms this still goes through commits
# every time, not just on a genuine change, since the legend display
# should refresh on every recalculation regardless.
added_before = len(added_events)
removed_before = len(removed_events)
count3, err3 = run_and_wait(engine)
check("third recalculation succeeds", err3 is None, err3)
check("commits fired again on a same-result recalculation",
      len(added_events) > added_before and len(removed_events) > removed_before,
      (len(added_events), len(removed_events)))

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
