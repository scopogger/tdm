"""
Three things specific to this turn's changes, none covered by the
other test files:

1. Overlapping recalculate() calls -- fired faster than the
   background task can finish -- must not race over the output layer,
   and only the *last* requested callback should ever fire, with
   results reflecting the final state, not an intermediate one.
2. cancel() must let an in-flight task's result be safely discarded
   (covers plugin unload while a background computation is running).
3. _find_existing_output_layer() must actually reattach to a
   previously-created output layer after a real project save/reload
   round trip -- not just "the Python object is still around", a
   genuine QgsProject.write()/read() cycle, the same as closing and
   reopening QGIS.
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.spatial_query_engine import SpatialQueryEngine, PROPERTY_NAMESPACE  # noqa: E402
from _test_helpers import wait_for, run_and_wait  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
zone.dataProvider().addFeatures([zf])

subject = QgsVectorLayer("Point?crs=EPSG:3857&field=label:string", "subject", "memory")
for i in range(20):
    f = QgsFeature(subject.fields())
    f.setGeometry(QgsGeometry.fromWkt(f"POINT({i} {i})"))
    f.setAttribute("label", f"p{i}")
    subject.dataProvider().addFeatures([f])
project.addMapLayers([zone, subject], False)
project.layerTreeRoot().addLayer(zone)
project.layerTreeRoot().addLayer(subject)

print("=" * 70)
print("1. OVERLAPPING recalculate() CALLS: only the last one should ever complete")
print("=" * 70)

engine = SpatialQueryEngine(iface)
engine.set_subject_layer(subject)
engine.set_selection_layer(zone)
engine.set_predicates(["Intersects"])

calls = []  # (label, count, error) for whichever callbacks actually fire
engine.recalculate(on_done=lambda c, e: calls.append(("cb1", c, e)))
check("first call started a background task", engine._task is not None)
task_after_first_call = engine._task

engine.set_predicates(["Within"])
engine.recalculate(on_done=lambda c, e: calls.append(("cb2", c, e)))
check("second call (before the first finished) did NOT start a second task",
      engine._task is task_after_first_call)
check("second call was queued as pending instead", engine._recalc_pending)

engine.set_predicates(["Touches"])
engine.recalculate(on_done=lambda c, e: calls.append(("cb3", c, e)))
check("third call replaced the pending callback rather than queuing a third task",
      engine._task is task_after_first_call and engine._recalc_pending)

ok = wait_for(lambda: engine._task is None and not engine._recalc_pending, 6.0)
check("engine settles back to idle", ok)

check("cb1 never fired (its result was superseded before it even finished)",
      not any(c[0] == "cb1" for c in calls), calls)
check("cb2 never fired (superseded by cb3 before cb1's task even completed)",
      not any(c[0] == "cb2" for c in calls), calls)
check("cb3 fired exactly once, with a real (non-error) result",
      [c for c in calls if c[0] == "cb3" and c[2] is None] != [] and
      len([c for c in calls if c[0] == "cb3"]) == 1,
      calls)
# Touches, the FINAL predicate in effect: of the 20 diagonal points
# (0,0)..(19,19), only (0,0) sits exactly on the zone's boundary (its
# corner vertex) -- verified directly with QgsGeometry before writing
# this assertion, not assumed -- so exactly 1 should match, not the
# 20 that would match Intersects/Within.
check("the surviving result reflects Touches (the last predicate set), not Intersects/Within",
      calls[-1] == ("cb3", 1, None), calls)

print()
print("=" * 70)
print("2. cancel() discards an in-flight result safely")
print("=" * 70)

engine2 = SpatialQueryEngine(iface)
engine2.set_subject_layer(subject)
engine2.set_selection_layer(zone)
engine2.set_predicates(["Intersects"])

cancel_calls = []
engine2.recalculate(on_done=lambda c, e: cancel_calls.append((c, e)))
check("task started", engine2._task is not None)
engine2.cancel()
check("cancel() clears the pending-rerun state", not engine2._recalc_pending)

ok = wait_for(lambda: engine2._task is None, 6.0)
check("engine settles after cancel", ok)
check("on_done was never called for the cancelled run", cancel_calls == [], cancel_calls)
check("no output layer was created by the cancelled run", engine2._output_layer is None)

# and a fresh recalculate() afterward must work normally
count, error = run_and_wait(engine2)
check("engine is usable again after cancel()", error is None and count == 20, (count, error))

print()
print("=" * 70)
print("3. REATTACHMENT across a real project save/reload round trip")
print("=" * 70)

engine3 = SpatialQueryEngine(iface)
engine3.set_subject_layer(subject)
engine3.set_selection_layer(zone)
engine3.set_predicates(["Intersects"])
count3, error3 = run_and_wait(engine3)
check("initial run against the 20-point subject layer succeeds (all 20 points are inside the zone)",
      error3 is None and count3 == 20, (count3, error3))

original_output_id = engine3._output_layer.id()
original_subject_id = subject.id()
original_selection_id = zone.id()
layer_count_before = len(project.mapLayers())

save_path = "/tmp/dynamic_spatial_query_test_project.qgs"
ok = project.write(save_path)
check("project saved to disk", ok)

project.clear()
check("project.clear() actually removed everything", len(project.mapLayers()) == 0)

ok = project.read(save_path)
check("project reloaded from disk", ok)
check("reload restored the same number of layers", len(project.mapLayers()) == layer_count_before,
      len(project.mapLayers()))

reloaded_subject = project.mapLayer(original_subject_id)
reloaded_selection = project.mapLayer(original_selection_id)
reloaded_output = project.mapLayer(original_output_id)
check("subject layer reloaded with the same layer id", reloaded_subject is not None)
check("selection layer reloaded with the same layer id", reloaded_selection is not None)
check("output layer reloaded with the same layer id", reloaded_output is not None)
check("reloaded output layer kept its is_output custom property",
      reloaded_output.customProperty(f"{PROPERTY_NAMESPACE}/is_output", False) is True)
check("reloaded output layer's feature data DOES survive now (GeoPackage-backed, not memory)",
      reloaded_output.featureCount() == 20, reloaded_output.featureCount())

# Simulate "QGIS restarted, plugin loaded fresh": a brand new engine
# instance, pointed at the reloaded layer objects (different Python
# objects than the pre-save ones, same underlying layer ids).
engine4 = SpatialQueryEngine(iface)
engine4.set_subject_layer(reloaded_subject)
engine4.set_selection_layer(reloaded_selection)
engine4.set_predicates(["Intersects"])

found = engine4._find_existing_output_layer(project)
check("fresh engine instance finds the pre-existing output layer by custom property",
      found is not None and found.id() == original_output_id,
      found.id() if found else None)

# re-seed both reloaded memory layers -- neither's feature data
# survived the round trip (memory layers never persist their own
# rows in the project file, only their structure/properties). Missing
# the selection layer here on a first pass produced count4==0, which
# was the engine behaving correctly (no selection features means
# nothing can match) against an incompletely-reconstructed test scene,
# not a bug in the plugin -- confirmed by debugging it directly before
# concluding that and fixing the test rather than the engine.
for i in range(20):
    f = QgsFeature(reloaded_subject.fields())
    f.setGeometry(QgsGeometry.fromWkt(f"POINT({i} {i})"))
    f.setAttribute("label", f"p{i}")
    reloaded_subject.dataProvider().addFeatures([f])
reloaded_zf = QgsFeature(reloaded_selection.fields())
reloaded_zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
reloaded_selection.dataProvider().addFeatures([reloaded_zf])

count4, error4 = run_and_wait(engine4)
check("recalculating through the reattached engine succeeds", error4 is None, error4)
check("recalculating through the reattached engine reuses the SAME output layer (no duplicate)",
      engine4._output_layer.id() == original_output_id)
check("project's layer count did not grow (no duplicate output layer or group)",
      len(project.mapLayers()) == layer_count_before, len(project.mapLayers()))
check("the reattached output layer now has fresh, correct results",
      engine4._output_layer.featureCount() == count4 and count4 == 20, count4)

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
