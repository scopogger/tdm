"""
Shared helpers for the test suite. recalculate() runs on a background
QgsTask now, so tests need to pump the Qt event loop until the result
actually arrives instead of reading it back immediately.
"""
import time

from qgis.PyQt.QtCore import QCoreApplication


def wait_for(predicate, timeout_s=5.0):
    deadline = time.time() + timeout_s
    while time.time() < deadline and not predicate():
        QCoreApplication.processEvents()
        time.sleep(0.02)
    return predicate()


def run_and_wait(engine, timeout_s=5.0):
    """Calls engine.recalculate() and blocks (via event-pumping, not a
    real thread block) until the background task's on_finished has
    run. Returns (count, error); error is a string on failure/timeout,
    None on success."""
    result = {}
    engine.recalculate(on_done=lambda c, e: result.update(count=c, error=e))
    ok = wait_for(lambda: "count" in result, timeout_s)
    if not ok:
        return 0, "timed out waiting for recalculate() to finish"
    return result["count"], result["error"]
