"""
Headless integration test for Dynamic Spatial Query, run against real
PyQGIS (3.34). See ../../selection_intersector/tests/README.md (the
sibling plugin this pattern was first built for) for how to reproduce
this environment; the short version is `apt-get install python3-qgis
python3-mock` + QT_QPA_PLATFORM=offscreen, no display needed.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import QVariant  # noqa: E402

from dynamic_spatial_query.spatial_query_engine import SpatialQueryEngine, PREDICATES  # noqa: E402
from dynamic_spatial_query.query_panel import QueryPanel  # noqa: E402
from dynamic_spatial_query.reactive_watcher import ReactiveWatcher  # noqa: E402
from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

print("=" * 70)
print("1. IMPORTS")
print("=" * 70)
check("all modules imported cleanly", True)  # would have raised above otherwise

print()
print("=" * 70)
print("2. SCENE SETUP: one reference zone, six parcels with known relationships")
print("=" * 70)

zones = QgsVectorLayer("Polygon?crs=EPSG:3857&field=zone_name:string", "zones", "memory")
z1 = QgsFeature(zones.fields())
z1.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
z1.setAttribute("zone_name", "Z1")
zones.dataProvider().addFeatures([z1])

parcels = QgsVectorLayer(
    "Polygon?crs=EPSG:3857&field=parcel_name:string&field=notes:string", "parcels", "memory"
)


def add_parcel(name, wkt, notes=""):
    f = QgsFeature(parcels.fields())
    f.setGeometry(QgsGeometry.fromWkt(wkt))
    f.setAttribute("parcel_name", name)
    f.setAttribute("notes", notes)
    parcels.dataProvider().addFeatures([f])


add_parcel("A_within", "POLYGON((30 30,40 30,40 40,30 40,30 30))", "fully inside Z1")
add_parcel("B_contains", "POLYGON((-10 -10,110 -10,110 110,-10 110,-10 -10))", "fully contains Z1")
add_parcel("C_overlaps", "POLYGON((50 50,150 50,150 150,50 150,50 50))", "partial overlap with Z1")
add_parcel("D_touches", "POLYGON((100 20,110 20,110 30,100 30,100 20))", "shares Z1's right edge")
add_parcel("E_equals", "POLYGON((0 0,100 0,100 100,0 100,0 0))", "identical to Z1")
add_parcel("F_disjoint", "POLYGON((500 500,510 500,510 510,500 510,500 500))", "nowhere near Z1")

for lyr in (zones, parcels):
    lyr.updateExtents()
project.addMapLayers([zones, parcels], False)
project.layerTreeRoot().addLayer(zones)
project.layerTreeRoot().addLayer(parcels)

print()
print("=" * 70)
print("3. QUERY PANEL: combo auto-sync + predicate checkboxes")
print("=" * 70)

panel = QueryPanel(iface)
check("panel builds without error", panel is not None)
check("subject combo auto-picked a layer from the project",
      panel.subject_layer() is not None, str(panel.subject_layer()))
check("default selected predicate is Intersects",
      panel.selected_predicates() == ["Intersects"], str(panel.selected_predicates()))

panel.subject_combo.setLayer(parcels)
panel.selection_combo.setLayer(zones)
check("subject combo reflects explicit setLayer(parcels)", panel.subject_layer().name() == "parcels")
check("selection combo reflects explicit setLayer(zones)", panel.selection_layer().name() == "zones")

panel.predicate_checks["Within"].setChecked(True)
check("checking Within adds it without dropping the default Intersects",
      set(panel.selected_predicates()) == {"Intersects", "Within"},
      str(panel.selected_predicates()))
panel.predicate_checks["Within"].setChecked(False)
panel.predicate_checks["Intersects"].setChecked(False)

print()
print("=" * 70)
print("4. ENGINE: per-predicate correctness against the known scene")
print("=" * 70)

engine = SpatialQueryEngine(iface)
engine.set_subject_layer(parcels)
engine.set_selection_layer(zones)

result = {}
def run(predicates):
    engine.set_predicates(predicates)
    engine.recalculate(on_done=lambda c, e: result.update(count=c, error=e))
    out = engine._output_layer
    names = sorted(f["parcel_name"] for f in out.getFeatures()) if out else []
    return names


names = run(["Intersects"])
check("Intersects matches A,B,C,D,E (everything but F)",
      names == ["A_within", "B_contains", "C_overlaps", "D_touches", "E_equals"], str(names))

names = run(["Disjoint"])
check("Disjoint matches only F", names == ["F_disjoint"], str(names))

names = run(["Overlaps"])
check("Overlaps matches only C (within/contains/equals/touches are explicitly excluded by OGC def)",
      names == ["C_overlaps"], str(names))

names = run(["Touches"])
check("Touches matches only D", names == ["D_touches"], str(names))

names = run(["Within"])
within_names = names
print(f"    (diagnostic) Within matched: {within_names}")
check("Within includes A (strictly inside)", "A_within" in within_names)
check("Within does not include C/D/F", not ({"C_overlaps", "D_touches", "F_disjoint"} & set(within_names)))

names = run(["Contains"])
contains_names = names
print(f"    (diagnostic) Contains matched: {contains_names}")
check("Contains includes B (strictly around)", "B_contains" in contains_names)
check("Contains does not include C/D/F", not ({"C_overlaps", "D_touches", "F_disjoint"} & set(contains_names)))

names = run(["Equals"])
check("Equals matches only E", names == ["E_equals"], str(names))

names = run(["Within", "Overlaps"])
check("OR of Within+Overlaps = (Within results) union (C)",
      set(names) == set(within_names) | {"C_overlaps"}, str(names))

print()
print("=" * 70)
print("5. ATTRIBUTE PRESERVATION + orig_fid tracing + field-collision safety")
print("=" * 70)

run(["Intersects"])
out = engine._output_layer
a_feat = next(f for f in out.getFeatures() if f["parcel_name"] == "A_within")
check("original 'notes' attribute preserved on output", a_feat["notes"] == "fully inside Z1",
      a_feat["notes"])
orig_a = next(f for f in parcels.getFeatures() if f["parcel_name"] == "A_within")
check("__orig_fid correctly traces back to the real source feature id",
      a_feat["__orig_fid"] == orig_a.id(), f"{a_feat['__orig_fid']} vs {orig_a.id()}")

# Now force a field-name collision and confirm the engine doesn't clobber it.
colliding = QgsVectorLayer(
    "Point?crs=EPSG:3857&field=name:string&field=__orig_fid:string", "colliding", "memory"
)
cf = QgsFeature(colliding.fields())
cf.setGeometry(QgsGeometry.fromWkt("POINT(50 50)"))
cf.setAttribute("name", "pt1")
cf.setAttribute("__orig_fid", "not-a-real-fid")
colliding.dataProvider().addFeatures([cf])
project.addMapLayers([colliding], False)
# addFeatures() does not reliably update cf's own .id() in place --
# re-fetch to get the real assigned id (bit me here the same way a
# similar mistake did in the sibling plugin's test suite last time).
cf_real_id = next(f.id() for f in colliding.getFeatures())

engine2 = SpatialQueryEngine(iface)
engine2.set_subject_layer(colliding)
engine2.set_selection_layer(zones)
engine2.set_predicates(["Intersects"])
r2 = {}
engine2.recalculate(on_done=lambda c, e: r2.update(count=c, error=e))
out2 = engine2._output_layer
field_names = [f.name() for f in out2.fields()]
check("colliding field name resolved to __orig_fid_1, original field untouched",
      "__orig_fid" in field_names and "__orig_fid_1" in field_names, str(field_names))
cf_out = next(out2.getFeatures())
check("the layer's own __orig_fid value survived unchanged",
      cf_out["__orig_fid"] == "not-a-real-fid", cf_out["__orig_fid"])
check("the plugin's tracing id landed in the renamed field instead",
      cf_out["__orig_fid_1"] == cf_real_id, f"{cf_out['__orig_fid_1']} vs {cf_real_id}")

print()
print("=" * 70)
print("6. SELF-COMPARISON: subject == selection layer must not match a feature to itself")
print("=" * 70)

topo = QgsVectorLayer("Polygon?crs=EPSG:3857&field=name:string", "topo", "memory")
def add_topo(name, wkt):
    f = QgsFeature(topo.fields())
    f.setGeometry(QgsGeometry.fromWkt(wkt))
    f.setAttribute("name", name)
    topo.dataProvider().addFeatures([f])

add_topo("solo", "POLYGON((300 300,310 300,310 310,300 310,300 300))")  # touches nothing else
add_topo("pair_a", "POLYGON((0 0,10 0,10 10,0 10,0 0))")
add_topo("pair_b", "POLYGON((10 0,20 0,20 10,10 10,10 0))")  # touches pair_a's right edge
project.addMapLayers([topo], False)

engine3 = SpatialQueryEngine(iface)
engine3.set_subject_layer(topo)
engine3.set_selection_layer(topo)
engine3.set_predicates(["Touches"])
r3 = {}
engine3.recalculate(on_done=lambda c, e: r3.update(count=c, error=e))
out3 = engine3._output_layer
names3 = sorted(f["name"] for f in out3.getFeatures())
check("self-comparison excludes 'solo' (touches nothing but itself) and includes the real pair",
      names3 == ["pair_a", "pair_b"], str(names3))

print()
print("=" * 70)
print("7. SUBJECT LAYER SWAP: output layer must rebuild with the new geometry type")
print("=" * 70)

points = QgsVectorLayer("Point?crs=EPSG:3857&field=label:string", "points", "memory")
pf = QgsFeature(points.fields())
pf.setGeometry(QgsGeometry.fromWkt("POINT(50 50)"))
pf.setAttribute("label", "p1")
points.dataProvider().addFeatures([pf])
project.addMapLayers([points], False)

engine.set_subject_layer(points)  # was 'parcels' (Polygon); now Point
engine.set_selection_layer(zones)
engine.set_predicates(["Intersects"])
r4 = {}
engine.recalculate(on_done=lambda c, e: r4.update(count=c, error=e))
check("output layer rebuilt as Point after subject layer swap",
      engine._output_layer.geometryType() == QgsWkbTypes.PointGeometry,
      str(engine._output_layer.geometryType()))
check("output has the 1 matching point", engine._output_layer.featureCount() == 1,
      engine._output_layer.featureCount())

print()
if FAILURES:
    print(f"SECTION 1-7 RESULT: {len(FAILURES)} FAILURE(S so far):", FAILURES)
else:
    print("SECTION 1-7 RESULT: ALL CHECKS PASSED SO FAR")
