"""
The specific scenario from the conversation: "the user may have a
layer with SQL filter that only includes 'buildings'". Builds one
layer with mixed feature types, filters it down via setSubsetString,
runs the query, then changes the filter and confirms the result
changes accordingly -- both through the engine directly and through
the reactive watcher noticing the filter change on its own.

Also verifies the Crosses predicate (line through a polygon), which
the other tests don't happen to exercise since they're built around
polygon/point scenes.
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.spatial_query_engine import SpatialQueryEngine  # noqa: E402
from dynamic_spatial_query.reactive_watcher import ReactiveWatcher  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


def wait_for(predicate, timeout_s):
    deadline = time.time() + timeout_s
    while time.time() < deadline and not predicate():
        QCoreApplication.processEvents()
        time.sleep(0.02)
    return predicate()


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

print("=" * 70)
print("1. SUBJECT LAYER 'IS THE RESULT OF A QUERY': mixed types, filtered by subset string")
print("=" * 70)

# One layer holding several kinds of thing, exactly like a real
# "planning_objects" table someone would filter down with a subset
# string / query builder rather than maintaining separate layers.
mixed = QgsVectorLayer("Point?crs=EPSG:3857&field=objtype:string", "planning_objects", "memory")


def add_obj(objtype, x, y):
    f = QgsFeature(mixed.fields())
    f.setGeometry(QgsGeometry.fromWkt(f"POINT({x} {y})"))
    f.setAttribute("objtype", objtype)
    mixed.dataProvider().addFeatures([f])


add_obj("building", 5, 5)
add_obj("building", 6, 6)
add_obj("road", 5, 5)  # same location as a building, different type
add_obj("tree", 20, 20)  # outside the zone entirely

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,10 0,10 10,0 10,0 0))"))
zone.dataProvider().addFeatures([zf])

project.addMapLayers([mixed, zone], False)

ok = mixed.setSubsetString("objtype = 'building'")
check("subset string 'only buildings' applied", ok)
check("layer.featureCount() already reflects the filter", mixed.featureCount() == 2,
      mixed.featureCount())

engine = SpatialQueryEngine(iface)
engine.set_subject_layer(mixed)
engine.set_selection_layer(zone)
engine.set_predicates(["Intersects"])
result = {}
engine.recalculate(on_done=lambda c, e: result.update(count=c, error=e))
wait_for(lambda: "count" in result, 5.0)
check("query against the filtered layer only ever sees the 2 buildings",
      result.get("count") == 2, result.get("count"))

print()
print("=" * 70)
print("2. CHANGING THE FILTER changes the result, without touching the query itself")
print("=" * 70)

ok = mixed.setSubsetString("objtype = 'road'")
check("subset string changed to 'only roads'", ok)
result.clear()
engine.recalculate(on_done=lambda c, e: result.update(count=c, error=e))
wait_for(lambda: "count" in result, 5.0)
check("same engine, same predicates, now sees only the 1 road",
      result.get("count") == 1, result.get("count"))
out_names = [f["objtype"] for f in engine._output_layer.getFeatures()]
check("the matched feature really is the road, not a stale building",
      out_names == ["road"], out_names)

print()
print("=" * 70)
print("3. THE WATCHER NOTICES THE FILTER CHANGE ON ITS OWN (no manual recalc call)")
print("=" * 70)

mixed.setSubsetString("objtype = 'building'")  # back to buildings, watcher not attached yet
watcher = ReactiveWatcher()
watcher.watch([mixed, zone])
fired = {"n": 0}
watcher.sourceDataChanged.connect(lambda: fired.__setitem__("n", fired["n"] + 1))

ok = mixed.setSubsetString("objtype != 'building'")  # everything except buildings now
ok2 = wait_for(lambda: fired["n"] > 0, ReactiveWatcher.DEBOUNCE_MS / 1000.0 + 1.0)
check("filter change alone (no add/edit/delete) triggers the watcher", ok2)
watcher.stop()

print()
print("=" * 70)
print("4. CROSSES predicate: a line running through the zone's boundary")
print("=" * 70)

lines = QgsVectorLayer("LineString?crs=EPSG:3857&field=name:string", "lines", "memory")
lf = QgsFeature(lines.fields())
lf.setGeometry(QgsGeometry.fromWkt("LINESTRING(-5 5, 15 5)"))  # enters and exits the zone
lf.setAttribute("name", "crossing_line")
lines.dataProvider().addFeatures([lf])
lf2 = QgsFeature(lines.fields())
lf2.setGeometry(QgsGeometry.fromWkt("LINESTRING(2 2, 8 8)"))  # fully inside, doesn't cross the boundary
lf2.setAttribute("name", "inside_line")
lines.dataProvider().addFeatures([lf2])
project.addMapLayers([lines], False)

engine2 = SpatialQueryEngine(iface)
engine2.set_subject_layer(lines)
engine2.set_selection_layer(zone)
engine2.set_predicates(["Crosses"])
r2 = {}
engine2.recalculate(on_done=lambda c, e: r2.update(count=c, error=e))
wait_for(lambda: "count" in r2, 5.0)
crossing_names = sorted(f["name"] for f in engine2._output_layer.getFeatures())
check("Crosses matches the line that goes from outside to inside to outside",
      crossing_names == ["crossing_line"], crossing_names)

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
