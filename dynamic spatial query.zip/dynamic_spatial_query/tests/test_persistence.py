"""
Two things reported as broken in real use, tested directly:

1. "Layers don't have objects after reopening the app" -- confirms
   real feature data (not just structure) survives an actual
   QgsProject.write()/read() round trip, via a completely fresh
   QgsVectorLayer object, and that two different subject layers'
   outputs land in separate tables inside one shared GeoPackage file
   without clobbering each other.
2. "Chain-selecting from the module layers doesn't work" -- confirms
   an output layer from one query can be used as the subject (or
   selection) layer of a second, independent query, both before and
   after a save/reload -- i.e. the actual data-and-schema mechanics
   of chaining work. What this does NOT cover: two queries staying
   simultaneously live at once (only one QueryPanel/engine/watcher
   exists right now) -- that's the bigger, separate registry redesign
   discussed earlier, not something this fix touches.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.spatial_query_engine import SpatialQueryEngine  # noqa: E402
from _test_helpers import run_and_wait  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

print("=" * 70)
print("1. PERSISTENCE: two different subject layers, two output tables, one file")
print("=" * 70)

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
zone.dataProvider().addFeatures([zf])

buildings = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "buildings", "memory")
for i, (x, y) in enumerate([(10, 10), (20, 20), (500, 500)]):
    f = QgsFeature(buildings.fields())
    f.setGeometry(QgsGeometry.fromWkt(f"POINT({x} {y})"))
    f.setAttribute("name", f"b{i}")
    buildings.dataProvider().addFeatures([f])

roads = QgsVectorLayer("LineString?crs=EPSG:3857&field=name:string", "roads", "memory")
for i, wkt in enumerate(["LINESTRING(5 5, 15 15)", "LINESTRING(600 600, 610 610)"]):
    f = QgsFeature(roads.fields())
    f.setGeometry(QgsGeometry.fromWkt(wkt))
    f.setAttribute("name", f"r{i}")
    roads.dataProvider().addFeatures([f])

project.addMapLayers([zone, buildings, roads], False)
for lyr in (zone, buildings, roads):
    project.layerTreeRoot().addLayer(lyr)

engine_b = SpatialQueryEngine(iface)
engine_b.set_subject_layer(buildings)
engine_b.set_selection_layer(zone)
engine_b.set_predicates(["Intersects"])
engine_b.set_output_name("buildings_in_zone")
count_b, err_b = run_and_wait(engine_b)
check("buildings query succeeds", err_b is None and count_b == 2, (count_b, err_b))

engine_r = SpatialQueryEngine(iface)
engine_r.set_subject_layer(roads)
engine_r.set_selection_layer(zone)
engine_r.set_predicates(["Intersects"])
engine_r.set_output_name("roads_in_zone")
count_r, err_r = run_and_wait(engine_r)
check("roads query succeeds", err_r is None and count_r == 1, (count_r, err_r))

buildings_gpkg = engine_b._output_layer.source().split("|")[0]
roads_gpkg = engine_r._output_layer.source().split("|")[0]
check("both outputs share the same .gpkg file", buildings_gpkg == roads_gpkg,
      (buildings_gpkg, roads_gpkg))
check("but as two distinct tables within it",
      engine_b._output_layer.source() != engine_r._output_layer.source())

# Capture plain strings now -- project.clear() deletes the underlying
# C++ objects out from under any Python reference still pointing at
# them, engine_b._output_layer included, so those references become
# unusable immediately after (confirmed the hard way: this tripped a
# RuntimeError on the first pass of writing this test).
buildings_out_name = engine_b._output_layer.name()
roads_out_name = engine_r._output_layer.name()

save_path = "/tmp/dsq_persistence_test_project.qgs"
project.write(save_path)
project.clear()
project.read(save_path)

reloaded_buildings_out = None
reloaded_roads_out = None
for lyr in project.mapLayers().values():
    if lyr.name() == buildings_out_name:
        reloaded_buildings_out = lyr
    elif lyr.name() == roads_out_name:
        reloaded_roads_out = lyr

check("buildings output reappeared after reopening the project", reloaded_buildings_out is not None)
check("roads output reappeared after reopening the project", reloaded_roads_out is not None)
if reloaded_buildings_out is not None:
    check("buildings output STILL HAS its 2 objects after reopening (this was the reported bug)",
          reloaded_buildings_out.featureCount() == 2, reloaded_buildings_out.featureCount())
    names = sorted(f["name"] for f in reloaded_buildings_out.getFeatures())
    check("and they're the correct, right objects, not placeholders",
          names == ["b0", "b1"], names)
if reloaded_roads_out is not None:
    check("roads output STILL HAS its 1 object after reopening, unaffected by the buildings table",
          reloaded_roads_out.featureCount() == 1, reloaded_roads_out.featureCount())

print()
print("=" * 70)
print("2. CHAINING: using one query's output as the next query's subject layer")
print("=" * 70)

# Reload lost the original memory-layer 'zone' and 'buildings' data
# (they were always memory layers -- only THIS plugin's own outputs
# are GeoPackage-backed) -- rebuild the input scene fresh to test
# chaining cleanly, same idea as the persistence check above already
# proved the reload mechanics work.
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

zone_a = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone_a", "memory")
zaf = QgsFeature(zone_a.fields())
zaf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,50 0,50 50,0 50,0 0))"))
zone_a.dataProvider().addFeatures([zaf])

zone_b = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone_b", "memory")
zbf = QgsFeature(zone_b.fields())
zbf.setGeometry(QgsGeometry.fromWkt("POLYGON((10 10,30 10,30 30,10 30,10 10))"))
zone_b.dataProvider().addFeatures([zbf])

points = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "points", "memory")
for name, (x, y) in {
    "in_both": (20, 20),      # inside zone_a AND zone_b
    "in_a_only": (40, 5),     # inside zone_a, outside zone_b
    "in_neither": (900, 900),
}.items():
    f = QgsFeature(points.fields())
    f.setGeometry(QgsGeometry.fromWkt(f"POINT({x} {y})"))
    f.setAttribute("name", name)
    points.dataProvider().addFeatures([f])

project.addMapLayers([zone_a, zone_b, points], False)
for lyr in (zone_a, zone_b, points):
    project.layerTreeRoot().addLayer(lyr)

# Query 1: which points are in zone_a?
query1 = SpatialQueryEngine(iface)
query1.set_subject_layer(points)
query1.set_selection_layer(zone_a)
query1.set_predicates(["Intersects"])
query1.set_output_name("points_in_zone_a")
c1, e1 = run_and_wait(query1)
check("query 1 (points in zone_a) succeeds", e1 is None and c1 == 2, (c1, e1))
names1 = sorted(f["name"] for f in query1._output_layer.getFeatures())
check("query 1 finds in_both and in_a_only", names1 == ["in_a_only", "in_both"], names1)

# Query 2, CHAINED: of query 1's own output layer, which are also in zone_b?
query2 = SpatialQueryEngine(iface)
query2.set_subject_layer(query1._output_layer)  # <-- chaining off a module output layer
query2.set_selection_layer(zone_b)
query2.set_predicates(["Intersects"])
query2.set_output_name("zone_a_points_also_in_zone_b")
c2, e2 = run_and_wait(query2)
check("query 2, chained off query 1's output layer, succeeds with no error", e2 is None, e2)
check("query 2 correctly narrows to just in_both", c2 == 1, c2)
if query2._output_layer is not None:
    names2 = [f["name"] for f in query2._output_layer.getFeatures()]
    check("the one surviving feature is in_both, not in_a_only", names2 == ["in_both"], names2)

print()
print("=" * 70)
print("3. THE COMBINED CASE: does a chained query still resolve after a reload?")
print("=" * 70)

query1_out_name = query1._output_layer.name()
query2_out_name = query2._output_layer.name()

save_path2 = "/tmp/dsq_chain_test_project.qgs"
project.write(save_path2)
project.clear()
project.read(save_path2)

reloaded_query1_out = None
reloaded_query2_out = None
for lyr in project.mapLayers().values():
    if lyr.name() == query1_out_name:
        reloaded_query1_out = lyr
    elif lyr.name() == query2_out_name:
        reloaded_query2_out = lyr

check("query 1's output survived the reload with its data intact",
      reloaded_query1_out is not None and reloaded_query1_out.featureCount() == 2,
      reloaded_query1_out.featureCount() if reloaded_query1_out else None)
check("query 2's (chained) output ALSO survived the reload with its data intact",
      reloaded_query2_out is not None and reloaded_query2_out.featureCount() == 1,
      reloaded_query2_out.featureCount() if reloaded_query2_out else None)

# Fresh engine, fresh QGIS session in spirit -- rebuild the chained
# query pointed at the RELOADED (not original) layer objects, and
# confirm recalculating it still resolves correctly against real,
# persisted upstream data. zone_b itself is a plain memory layer (a
# test fixture, not one of the plugin's own outputs), so ITS data
# didn't survive the reload either -- re-seed it, the same mistake
# bit this test once already in an earlier round with a different
# layer, so checking for it explicitly this time.
reloaded_zone_b = next(lyr for lyr in project.mapLayers().values() if lyr.name() == "zone_b")
check("(sanity check before trusting the next result) reloaded_zone_b really is empty pre-reseed",
      reloaded_zone_b.featureCount() == 0, reloaded_zone_b.featureCount())
zbf2 = QgsFeature(reloaded_zone_b.fields())
zbf2.setGeometry(QgsGeometry.fromWkt("POLYGON((10 10,30 10,30 30,10 30,10 10))"))
reloaded_zone_b.dataProvider().addFeatures([zbf2])

query2_fresh = SpatialQueryEngine(iface)
query2_fresh.set_subject_layer(reloaded_query1_out)
query2_fresh.set_selection_layer(reloaded_zone_b)
query2_fresh.set_predicates(["Intersects"])
c2b, e2b = run_and_wait(query2_fresh)
check("re-running the chained query after reload, from scratch, still gets the right answer",
      e2b is None and c2b == 1, (c2b, e2b))
check("and reattaches to the SAME already-reloaded output layer rather than duplicating it",
      query2_fresh._output_layer.id() == reloaded_query2_out.id())

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
