"""
Core computation for the Dynamic Spatial Query plugin.

Mirrors QGIS's own "Extract by Location" tool: given a subject layer
and a selection layer, keep every subject feature that satisfies at
least one of the chosen spatial predicates against at least one
feature in the selection layer (OR across predicates, OR across
selection features -- same semantics as native:extractbylocation).

Both layers' own filters (QgsVectorLayer.setSubsetString() -- "the
layer is itself the result of a query", e.g. a subset string of
type = 'building') are respected automatically and for free: QGIS
applies a subset string at the provider level, so every getFeatures()
call here already only sees the filtered rows. There's nothing extra
to do for that part -- the only extra work needed elsewhere is
*reacting* when the filter itself changes (see reactive_watcher.py).

Unlike a clip/intersection tool, output features keep their ORIGINAL
geometry and ALL of their original attributes, unmodified -- this is
"extract", not "clip". An extra field (see ORIG_FID_FIELD) is added
so results can be traced back to the source feature.

Predicate directions were verified directly against real PyQGIS
before writing this (not assumed from memory) -- see
tests/test_engine.py's predicate-direction checks. subject_geometry
is always the first argument, selection_geometry the second; this
matters for the non-symmetric predicates (Within, Contains).
"""

from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureRequest,
    QgsField,
    QgsGeometry,
    QgsProject,
    QgsRectangle,
    QgsSpatialIndex,
    QgsVectorLayer,
    QgsWkbTypes,
)

PREDICATES = {
    "Intersects": lambda a, b: a.intersects(b),
    "Within": lambda a, b: a.within(b),      # subject lies within the selection feature
    "Contains": lambda a, b: a.contains(b),  # subject contains the selection feature
    "Overlaps": lambda a, b: a.overlaps(b),
    "Touches": lambda a, b: a.touches(b),
    "Equals": lambda a, b: a.equals(b),
    "Crosses": lambda a, b: a.crosses(b),
    "Disjoint": lambda a, b: a.disjoint(b),
}

# The 5 named in the original technical brief (intersect, overlap,
# strictly-within, equal, touch) plus the 3 remaining predicates
# native:extractbylocation also offers, for parity with "an existing
# instrument".
DEFAULT_PREDICATES = ["Intersects"]

ORIG_FID_FIELD = "__orig_fid"


class SpatialQueryEngine:
    def __init__(self, iface):
        self.iface = iface
        self.subject_layer = None
        self.selection_layer = None
        self.predicates = list(DEFAULT_PREDICATES)
        self.output_name = "query_result"
        self.output_group_name = "Dynamic query results"
        self._output_layer = None
        self._orig_fid_field_name = ORIG_FID_FIELD

    def set_subject_layer(self, layer):
        if layer is not self.subject_layer:
            # Geometry type / schema may differ from whatever the output
            # layer currently is -- simplest correct thing is to rebuild
            # it fresh next time rather than try to migrate it.
            self._output_layer = None
        self.subject_layer = layer

    def set_selection_layer(self, layer):
        self.selection_layer = layer

    def set_predicates(self, predicate_names):
        chosen = [p for p in predicate_names if p in PREDICATES]
        self.predicates = chosen or list(DEFAULT_PREDICATES)

    def set_output_name(self, name):
        self.output_name = name or "query_result"
        if self._output_layer is not None:
            self._output_layer.setName(self.output_name)

    def recalculate(self, on_done=None):
        if self.subject_layer is None or self.selection_layer is None:
            if on_done:
                on_done(0, "Pick both a subject layer and a selection layer.")
            return
        if not self.predicates:
            if on_done:
                on_done(0, "Select at least one spatial predicate.")
            return
        try:
            total = self._do_recalculate()
        except Exception as exc:  # surfaced to the status label, not raised
            if on_done:
                on_done(0, str(exc))
            return
        if on_done:
            on_done(total, None)

    # -- internals ----------------------------------------------------

    def _do_recalculate(self):
        project = QgsProject.instance()
        subject_crs = self.subject_layer.crs()
        selection_crs = self.selection_layer.crs()

        transform = None
        if selection_crs != subject_crs:
            transform = QgsCoordinateTransform(selection_crs, subject_crs, project)

        same_layer = self.selection_layer.id() == self.subject_layer.id()

        # Index the (reprojected) selection features once per run --
        # cheap relative to re-testing every subject feature against
        # every selection feature with no index at all.
        index = QgsSpatialIndex()
        selection_geoms = {}
        combined_bbox = QgsRectangle()
        combined_bbox.setMinimal()
        for feat in self.selection_layer.getFeatures():
            geom = feat.geometry()
            if geom is None or geom.isEmpty():
                continue
            if transform is not None:
                geom = QgsGeometry(geom)
                geom.transform(transform)
            selection_geoms[feat.id()] = geom
            combined_bbox.combineExtentWith(geom.boundingBox())
            idx_feat = QgsFeature(feat.id())
            idx_feat.setGeometry(geom)
            index.addFeature(idx_feat)

        if not selection_geoms:
            self._write_output([])
            return 0

        # Disjoint is fundamentally different from the other 7: it means
        # "not matching ANY selection feature", so (a) a match is
        # typically OUTSIDE the selection layer's combined bounding box
        # -- the opposite of what the prefilter below assumes -- and
        # (b) it has to be checked against the WHOLE selection layer,
        # not stop at the first candidate the way an any-of-N test does.
        # So: skip the bbox prefilter entirely whenever Disjoint is one
        # of the chosen predicates (falls back to a full subject-layer
        # scan), and evaluate it as its own pass below.
        existential_predicates = [p for p in self.predicates if p != "Disjoint"]
        want_disjoint = "Disjoint" in self.predicates

        if want_disjoint:
            request = QgsFeatureRequest()
        else:
            request = QgsFeatureRequest().setFilterRect(combined_bbox)

        matches = []
        for subject_feat in self.subject_layer.getFeatures(request):
            subject_geom = subject_feat.geometry()
            if subject_geom is None or subject_geom.isEmpty():
                continue
            candidate_ids = [
                fid for fid in index.intersects(subject_geom.boundingBox())
                if not (same_layer and fid == subject_feat.id())  # never match itself
            ]

            is_match = False
            if existential_predicates:
                for sel_fid in candidate_ids:
                    sel_geom = selection_geoms[sel_fid]
                    if any(PREDICATES[p](subject_geom, sel_geom) for p in existential_predicates):
                        is_match = True
                        break
            if not is_match and want_disjoint:
                # True whenever nothing nearby fails the disjoint test --
                # vacuously true if candidate_ids is empty, i.e. nothing
                # shares even a bounding box with this subject feature.
                is_match = all(subject_geom.disjoint(selection_geoms[fid]) for fid in candidate_ids)

            if is_match:
                matches.append(subject_feat)

        self._write_output(matches)
        return len(matches)

    def _write_output(self, matches):
        project = QgsProject.instance()
        layer = self._get_or_create_layer(project)
        self._clear_layer(layer)

        provider = layer.dataProvider()
        features = []
        for feat in matches:
            f = QgsFeature(layer.fields())
            f.setGeometry(QgsGeometry(feat.geometry()))
            for field in self.subject_layer.fields():
                f.setAttribute(field.name(), feat.attribute(field.name()))
            f.setAttribute(self._orig_fid_field_name, feat.id())
            features.append(f)
        if features:
            provider.addFeatures(features)
        layer.updateExtents()
        layer.triggerRepaint()

    def _get_or_create_layer(self, project):
        if self._output_layer is not None:
            return self._output_layer

        wkb_display = QgsWkbTypes.displayString(self.subject_layer.wkbType())
        crs = self.subject_layer.crs()
        layer = QgsVectorLayer(f"{wkb_display}?crs={crs.authid()}", self.output_name, "memory")

        self._orig_fid_field_name = self._pick_orig_fid_field_name()
        provider = layer.dataProvider()
        provider.addAttributes(list(self.subject_layer.fields()))
        provider.addAttributes([QgsField(self._orig_fid_field_name, QVariant.LongLong)])
        layer.updateFields()

        root = project.layerTreeRoot()
        group = root.findGroup(self.output_group_name)
        if group is None:
            group = root.insertGroup(0, self.output_group_name)
        project.addMapLayer(layer, False)
        group.addLayer(layer)

        self._output_layer = layer
        return layer

    def _pick_orig_fid_field_name(self):
        existing = {f.name() for f in self.subject_layer.fields()}
        name = ORIG_FID_FIELD
        n = 1
        while name in existing:
            name = f"{ORIG_FID_FIELD}_{n}"
            n += 1
        return name

    @staticmethod
    def _clear_layer(layer):
        provider = layer.dataProvider()
        existing_ids = [f.id() for f in layer.getFeatures()]
        if existing_ids:
            provider.deleteFeatures(existing_ids)
