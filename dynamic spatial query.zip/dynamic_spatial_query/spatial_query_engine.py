"""
Core computation for the Dynamic Spatial Query plugin.

Mirrors QGIS's own "Extract by Location" tool: given a subject layer
and a selection layer, keep every subject feature that satisfies at
least one of the chosen spatial predicates against at least one
feature in the selection layer (OR across predicates, OR across
selection features -- same semantics as native:extractbylocation).

Both layers' own filters (QgsVectorLayer.setSubsetString() -- "the
layer is itself the result of a query", e.g. a subset string of
type = 'building') are respected automatically and for free: QGIS
applies a subset string at the provider level, so every getFeatures()
call here already only sees the filtered rows. There's nothing extra
to do for that part -- the only extra work needed elsewhere is
*reacting* when the filter itself changes (see reactive_watcher.py).

Unlike a clip/intersection tool, output features keep their ORIGINAL
geometry and ALL of their original attributes, unmodified -- this is
"extract", not "clip". An extra field (see ORIG_FID_FIELD) is added
so results can be traced back to the source feature.

Predicate directions were verified directly against real PyQGIS
before writing this (not assumed from memory) -- see
tests/test_engine.py's predicate-direction checks. subject_geometry
is always the first argument, selection_geometry the second; this
matters for the non-symmetric predicates (Within, Contains).

Output layers are GeoPackage-backed (one .gpkg file per project, one
table per distinct subject layer), not QGIS "memory" layers. Memory
layers never write their feature data into the project file -- only
their structure and custom properties survive a save/reload, which
is exactly the "the layers are empty after reopening QGIS" problem
this replaces. See _output_gpkg_path()/_output_table_name() and
tests/test_persistence.py, which confirms actual data (not just
structure) survives a real close-and-reopen, via a fresh QgsVectorLayer
object pointing at the same file rather than trusting an in-memory
Python reference.

Two things borrowed (and adapted) from a colleague's buffer-layer
plugin after reviewing it -- see tests/test_engine.py for both:

- Computation runs on a background QgsTask rather than the main
  thread, following their LoaderTask wrapper's pattern. Only the
  read-only matching (this module's _compute_matches) happens off the
  main thread; writing the output layer -- which touches QgsProject
  and the layer tree, both main-thread-only -- happens in the
  on_finished callback instead. A recalculate() call that arrives
  while one is already running doesn't start a second, overlapping
  task (which could race over the output layer); it's remembered and
  re-run once the in-flight one finishes, discarding that one's
  now-stale result instead of ever showing it.
- _find_existing_output_layer() detects an output layer left over
  from a previous session (self._output_layer is just an in-memory
  Python reference, lost on plugin reload or QGIS restart, even
  though the layer itself is still sitting in the project). Their
  is_buffer_layer() does this by matching a fixed set of field names;
  that doesn't fit here since this plugin's output schema mirrors
  whatever the subject layer's own fields are, not a fixed shape, so
  this uses a QgsMapLayer custom property tagged on at creation time
  instead -- saved and restored with the project file, confirmed by
  an actual save/reload round-trip in the test suite, not just read
  about. This matters even more now that output layers carry real
  data: it's what stops a query from silently duplicating its whole
  GeoPackage table every time the project reopens.
"""

import os
import re

from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsApplication,
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureRequest,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsProject,
    QgsRectangle,
    QgsSpatialIndex,
    QgsTask,
    QgsVectorFileWriter,
    QgsVectorLayer,
)

PREDICATES = {
    "Intersects": lambda a, b: a.intersects(b),
    "Within": lambda a, b: a.within(b),      # subject lies within the selection feature
    "Contains": lambda a, b: a.contains(b),  # subject contains the selection feature
    "Overlaps": lambda a, b: a.overlaps(b),
    "Touches": lambda a, b: a.touches(b),
    "Equals": lambda a, b: a.equals(b),
    "Crosses": lambda a, b: a.crosses(b),
    "Disjoint": lambda a, b: a.disjoint(b),
}

# The 5 named in the original technical brief (intersect, overlap,
# strictly-within, equal, touch) plus the 3 remaining predicates
# native:extractbylocation also offers, for parity with "an existing
# instrument".
DEFAULT_PREDICATES = ["Intersects"]

ORIG_FID_FIELD = "__orig_fid"

# Namespace prefix for QgsMapLayer custom properties this plugin
# tags its output layers with -- see _find_existing_output_layer().
PROPERTY_NAMESPACE = "dynamic_spatial_query"


class SpatialQueryEngine:
    def __init__(self, iface):
        self.iface = iface
        self.subject_layer = None
        self.selection_layer = None
        self.predicates = list(DEFAULT_PREDICATES)
        self.output_name = "query_result"
        self.output_group_name = "Dynamic query results"
        self._output_layer = None
        self._orig_fid_field_name = ORIG_FID_FIELD

        self._task = None
        self._recalc_pending = False
        self._pending_on_done = None
        self._discard_next_result = False

    def set_subject_layer(self, layer):
        if layer is not self.subject_layer:
            # Geometry type / schema may differ from whatever the output
            # layer currently is -- simplest correct thing is to look
            # for a matching layer left over from a previous session
            # (see _find_existing_output_layer) or otherwise rebuild
            # fresh, rather than try to migrate the existing one.
            self._output_layer = None
        self.subject_layer = layer

    def set_selection_layer(self, layer):
        self.selection_layer = layer

    def set_predicates(self, predicate_names):
        chosen = [p for p in predicate_names if p in PREDICATES]
        self.predicates = chosen or list(DEFAULT_PREDICATES)

    def set_output_name(self, name):
        self.output_name = name or "query_result"
        if self._output_layer is not None:
            self._output_layer.setName(self.output_name)

    def cancel(self):
        """
        Best-effort cleanup for plugin unload / engine teardown while a
        background computation might still be in flight. Doesn't try to
        forcibly interrupt the read-only computation already running
        (it has no natural checkpoint to cooperatively check
        QgsTask.isCanceled() against, and it's typically fast enough
        that this hasn't mattered in testing) -- just discards its
        result instead of applying it once it does finish, and drops
        any queued rerun.
        """
        self._recalc_pending = False
        self._pending_on_done = None
        if self._task is not None:
            self._discard_next_result = True
            self._task.cancel()

    def recalculate(self, on_done=None):
        if self.subject_layer is None or self.selection_layer is None:
            if on_done:
                on_done(0, "Pick both a subject layer and a selection layer.")
            return
        if not self.predicates:
            if on_done:
                on_done(0, "Select at least one spatial predicate.")
            return

        if self._task is not None:
            # Already computing -- remember to run again once it
            # finishes (covers source data changing again mid-run)
            # rather than starting a second task that could race the
            # first one over the output layer.
            self._recalc_pending = True
            self._pending_on_done = on_done
            return

        # Snapshot everything the background thread needs. It must not
        # read self.* while the main thread might concurrently change
        # them (e.g. the user switching the subject layer combo while
        # this is running) -- and if that does happen, the resulting
        # stale-input run's result gets discarded below in favour of
        # the rerun set_subject_layer()/etc. will have queued via
        # _recalc_pending, not because of anything read here.
        subject_layer = self.subject_layer
        selection_layer = self.selection_layer
        predicates = list(self.predicates)

        def run(_task):
            return self._compute_matches(subject_layer, selection_layer, predicates)

        def finished(exception, result):
            self._task = None
            discard = self._discard_next_result
            self._discard_next_result = False
            stale = self._recalc_pending  # a newer recalc was requested meanwhile

            if not discard and not stale:
                if exception is not None:
                    count, error = 0, str(exception)
                else:
                    matches, error = result
                    count = 0
                    if not error:
                        self._write_output(matches)
                        count = len(matches)
                if on_done:
                    on_done(count, error)

            if self._recalc_pending:
                self._recalc_pending = False
                next_on_done = self._pending_on_done
                self._pending_on_done = None
                self.recalculate(on_done=next_on_done)

        self._task = QgsTask.fromFunction("Dynamic spatial query", run, on_finished=finished)
        QgsApplication.taskManager().addTask(self._task)

    # -- internals ----------------------------------------------------

    def _compute_matches(self, subject_layer, selection_layer, predicates):
        """
        Runs on a background thread (via QgsTask.fromFunction above).
        Must not touch QgsProject, the layer tree, or create/add any
        layer -- all main-thread-only operations; only reads features
        via getFeatures() and tests QgsGeometry predicates, which is
        the supported pattern for a background QgsTask. Returns
        (matches, error_message_or_None); exceptions are caught here
        rather than left to propagate out of the worker thread.
        """
        try:
            project = QgsProject.instance()
            subject_crs = subject_layer.crs()
            selection_crs = selection_layer.crs()

            transform = None
            if selection_crs != subject_crs:
                transform = QgsCoordinateTransform(selection_crs, subject_crs, project)

            same_layer = selection_layer.id() == subject_layer.id()

            # Index the (reprojected) selection features once per run --
            # cheap relative to re-testing every subject feature against
            # every selection feature with no index at all.
            index = QgsSpatialIndex()
            selection_geoms = {}
            combined_bbox = QgsRectangle()
            combined_bbox.setMinimal()
            for feat in selection_layer.getFeatures():
                geom = feat.geometry()
                if geom is None or geom.isEmpty():
                    continue
                if transform is not None:
                    geom = QgsGeometry(geom)
                    geom.transform(transform)
                selection_geoms[feat.id()] = geom
                combined_bbox.combineExtentWith(geom.boundingBox())
                idx_feat = QgsFeature(feat.id())
                idx_feat.setGeometry(geom)
                index.addFeature(idx_feat)

            if not selection_geoms:
                return [], None

            # Disjoint is fundamentally different from the other 7: it
            # means "not matching ANY selection feature", so (a) a
            # match is typically OUTSIDE the selection layer's combined
            # bounding box -- the opposite of what the prefilter below
            # assumes -- and (b) it has to be checked against the WHOLE
            # selection layer, not stop at the first candidate the way
            # an any-of-N test does. So: skip the bbox prefilter
            # entirely whenever Disjoint is one of the chosen
            # predicates (falls back to a full subject-layer scan), and
            # evaluate it as its own pass below.
            existential_predicates = [p for p in predicates if p != "Disjoint"]
            want_disjoint = "Disjoint" in predicates

            if want_disjoint:
                request = QgsFeatureRequest()
            else:
                request = QgsFeatureRequest().setFilterRect(combined_bbox)

            matches = []
            for subject_feat in subject_layer.getFeatures(request):
                subject_geom = subject_feat.geometry()
                if subject_geom is None or subject_geom.isEmpty():
                    continue
                candidate_ids = [
                    fid for fid in index.intersects(subject_geom.boundingBox())
                    if not (same_layer and fid == subject_feat.id())  # never match itself
                ]

                is_match = False
                if existential_predicates:
                    for sel_fid in candidate_ids:
                        sel_geom = selection_geoms[sel_fid]
                        if any(PREDICATES[p](subject_geom, sel_geom) for p in existential_predicates):
                            is_match = True
                            break
                if not is_match and want_disjoint:
                    # True whenever nothing nearby fails the disjoint
                    # test -- vacuously true if candidate_ids is empty,
                    # i.e. nothing shares even a bounding box with this
                    # subject feature.
                    is_match = all(subject_geom.disjoint(selection_geoms[fid]) for fid in candidate_ids)

                if is_match:
                    matches.append(subject_feat)

            return matches, None
        except Exception as exc:  # keep the worker thread from ever raising out
            return [], str(exc)

    def _write_output(self, matches):
        project = QgsProject.instance()
        layer = self._get_or_create_layer(project)
        self._clear_layer(layer)

        provider = layer.dataProvider()
        features = []
        for feat in matches:
            f = QgsFeature(layer.fields())
            f.setGeometry(QgsGeometry(feat.geometry()))
            for field in self.subject_layer.fields():
                f.setAttribute(field.name(), feat.attribute(field.name()))
            f.setAttribute(self._orig_fid_field_name, feat.id())
            features.append(f)
        if features:
            provider.addFeatures(features)
        layer.updateExtents()
        layer.triggerRepaint()

    def _get_or_create_layer(self, project):
        if self._output_layer is not None:
            return self._output_layer

        existing = self._find_existing_output_layer(project)
        if existing is not None:
            self._output_layer = existing
            self._orig_fid_field_name = existing.customProperty(
                f"{PROPERTY_NAMESPACE}/orig_fid_field", ORIG_FID_FIELD
            )
            return existing

        self._orig_fid_field_name = self._pick_orig_fid_field_name()
        fields = QgsFields()
        for field in self.subject_layer.fields():
            fields.append(field)
        fields.append(QgsField(self._orig_fid_field_name, QVariant.LongLong))

        crs = self.subject_layer.crs()
        wkb_type = self.subject_layer.wkbType()
        gpkg_path = self._output_gpkg_path(project)
        table_name = self._output_table_name()

        save_options = QgsVectorFileWriter.SaveVectorOptions()
        save_options.driverName = "GPKG"
        save_options.layerName = table_name
        save_options.actionOnExistingFile = (
            QgsVectorFileWriter.CreateOrOverwriteLayer if os.path.exists(gpkg_path)
            else QgsVectorFileWriter.CreateOrOverwriteFile
        )
        writer = QgsVectorFileWriter.create(
            gpkg_path, fields, wkb_type, crs, project.transformContext(), save_options
        )
        if writer.hasError():
            raise RuntimeError(f"Could not create output GeoPackage table: {writer.errorMessage()}")
        del writer  # must flush/close the writer before opening the file as a layer

        layer = QgsVectorLayer(f"{gpkg_path}|layername={table_name}", self.output_name, "ogr")
        if not layer.isValid():
            raise RuntimeError(f"Created GeoPackage table but QGIS could not load it back: {gpkg_path}")

        layer.setCustomProperty(f"{PROPERTY_NAMESPACE}/is_output", True)
        layer.setCustomProperty(f"{PROPERTY_NAMESPACE}/subject_layer_id", self.subject_layer.id())
        layer.setCustomProperty(f"{PROPERTY_NAMESPACE}/selection_layer_id", self.selection_layer.id())
        layer.setCustomProperty(f"{PROPERTY_NAMESPACE}/orig_fid_field", self._orig_fid_field_name)

        root = project.layerTreeRoot()
        group = root.findGroup(self.output_group_name)
        if group is None:
            group = root.insertGroup(0, self.output_group_name)
        project.addMapLayer(layer, False)
        group.addLayer(layer)

        self._output_layer = layer
        return layer

    def _output_gpkg_path(self, project):
        """
        One GeoPackage file per project (or per profile, if the project
        has never been saved), holding every query's output as a
        separate table -- chosen the first time any query in this
        project creates an output layer. If you save an unsaved
        project into a real folder afterward, existing outputs stay
        in the profile-folder file; only ones created after that save
        will use the project-folder one.
        """
        project_dir = project.absolutePath()
        if project_dir:
            return os.path.join(project_dir, "dynamic_spatial_query_outputs.gpkg")
        profile_dir = QgsApplication.qgisSettingsDirPath()
        out_dir = os.path.join(profile_dir, "dynamic_spatial_query")
        os.makedirs(out_dir, exist_ok=True)
        return os.path.join(out_dir, "outputs.gpkg")

    def _output_table_name(self):
        def safe(s):
            return re.sub(r"[^A-Za-z0-9_]", "_", s)
        # last 16 chars of the layer id (which QGIS suffixes with a
        # random UUID) is effectively guaranteed unique, while keeping
        # the table name readable and reasonably short.
        suffix = safe(self.subject_layer.id())[-16:]
        return f"{safe(self.output_name)}_{suffix}"

    def _find_existing_output_layer(self, project):
        """
        Matches the *current* subject layer against the
        subject_layer_id tagged on any layer this plugin previously
        created -- the same granularity as the in-memory
        self._output_layer it's standing in for (set_subject_layer()
        above only invalidates on a genuinely different subject layer,
        not on the selection layer or predicates changing), just able
        to survive the Python-side reference being gone.
        """
        subject_id = self.subject_layer.id()
        for layer in project.mapLayers().values():
            if not layer.customProperty(f"{PROPERTY_NAMESPACE}/is_output", False):
                continue
            if layer.customProperty(f"{PROPERTY_NAMESPACE}/subject_layer_id") == subject_id:
                return layer
        return None

    def _pick_orig_fid_field_name(self):
        existing = {f.name() for f in self.subject_layer.fields()}
        name = ORIG_FID_FIELD
        n = 1
        while name in existing:
            name = f"{ORIG_FID_FIELD}_{n}"
            n += 1
        return name

    @staticmethod
    def _clear_layer(layer):
        provider = layer.dataProvider()
        existing_ids = [f.id() for f in layer.getFeatures()]
        if existing_ids:
            provider.deleteFeatures(existing_ids)
