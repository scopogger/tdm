"""
Watches the subject and selection layers (passed in as a list -- it
doesn't care which role each one plays) for anything that should
trigger a recalculation, and emits a single debounced
sourceDataChanged signal.

Per the technical brief this plugin is implementing, the trigger set
is broader than the polygon-based predecessor's:

1. In-session edits: each layer's *committed* signals
   (committedFeaturesAdded/Removed/committedGeometriesChanges/
   committedAttributeValuesChanges). Attribute changes are included
   this time (they weren't in the polygon-drawing predecessor,
   deliberately, since that engine never used attributes) because a
   layer here can be "the result of a query" -- an attribute edit can
   change whether a row still matches the OTHER layer's filter logic
   downstream, and more generally the brief explicitly lists
   attribute changes as a trigger.
2. Filter/subset-string changes: QgsVectorLayer.subsetStringChanged,
   for when a layer that's "the result of a query" has its filter
   condition edited (Layer Properties > Source > Query Builder, or
   layer.setSubsetString() from code). Confirmed by direct testing
   that this fires and that getFeatures() immediately reflects the
   new filter afterwards -- see tests/test_engine.py.
3. Project/group membership: QgsProject.layersRemoved, so a watched
   layer being removed from the project entirely also triggers a
   refresh (the engine will then report "pick both layers" via its
   own None-check).
4. Cross-session PostGIS edits: for layers backed by the "postgres"
   provider, setListening(True) + the provider's notify signal --
   see the parent README for the one-time SQL trigger this depends
   on, and the sibling plugin (selection_intersector) this pattern
   was first verified against.

A separate, independent QTimer (see periodic_refresh_timer below) can
supplement this with unconditional periodic refresh, matching a
pattern already used elsewhere for a "buffer zones" dynamic layer --
useful as a safety net for any provider/situation these signals don't
cover, at the cost of recalculating even when nothing changed.
"""

from qgis.PyQt.QtCore import QObject, QTimer, pyqtSignal
from qgis.core import QgsProject


class ReactiveWatcher(QObject):
    sourceDataChanged = pyqtSignal()

    DEBOUNCE_MS = 400

    def __init__(self, parent=None):
        super().__init__(parent)
        self._connections = []  # list of (signal, slot) so we can cleanly disconnect
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.sourceDataChanged.emit)

        self.periodic_refresh_timer = QTimer(self)
        self.periodic_refresh_timer.timeout.connect(self.sourceDataChanged.emit)

    def watch(self, layers):
        self.stop_watching_layers()

        seen_ids = set()
        for layer in layers:
            if layer is None or layer.id() in seen_ids:
                continue  # dedupe: subject and selection are allowed to be the same layer
            seen_ids.add(layer.id())

            self._connect(layer.committedFeaturesAdded, self._schedule)
            self._connect(layer.committedFeaturesRemoved, self._schedule)
            self._connect(layer.committedGeometriesChanges, self._schedule)
            self._connect(layer.committedAttributeValuesChanges, self._schedule)
            self._connect(layer.subsetStringChanged, self._schedule)

            provider = layer.dataProvider()
            if provider is not None and provider.name() == "postgres":
                # Starts (or reuses) a background LISTEN connection in the
                # postgres provider; see class docstring point 4.
                provider.setListening(True)
                self._connect(provider.notify, self._schedule)

        self._connect(QgsProject.instance().layersRemoved, self._schedule)

    def stop_watching_layers(self):
        for signal, slot in self._connections:
            try:
                signal.disconnect(slot)
            except (TypeError, RuntimeError):
                pass  # already disconnected, or the underlying object is gone
        self._connections = []
        self._timer.stop()

    def set_periodic_refresh(self, enabled, interval_seconds):
        if enabled:
            self.periodic_refresh_timer.start(interval_seconds * 1000)
        else:
            self.periodic_refresh_timer.stop()

    def stop(self):
        self.stop_watching_layers()
        self.periodic_refresh_timer.stop()

    def _connect(self, signal, slot):
        signal.connect(slot)
        self._connections.append((signal, slot))

    def _schedule(self, *_args, **_kwargs):
        # Restarts on every call, so a burst of edits collapses into
        # one recalculation shortly after the burst ends.
        self._timer.start(self.DEBOUNCE_MS)
