"""
Dock widget, split into two sides by a QSplitter:

- Left: define and create a query. Always a blank draft -- there is
  no "load an existing query for editing" flow anymore. Pick a
  subject layer, predicates, a selection layer, a result name, click
  "Выполнить". That's the whole surface; nothing here reacts to an
  existing query's state, because nothing here can load one.
- Right (toggleable, resizable): manage queries that already exist --
  the table, "Удалить", "Обновить" (a small addition -- see plugin.py
  module docstring for why), and the two update-frequency controls,
  which act on whichever row is currently selected.

Renaming, changing an existing query's layers, or toggling its
predicates after creation is deliberately not offered -- delete and
recreate instead, which is less to get confused by than an editable
form whose meaning silently depends on what's currently selected
elsewhere in the panel (which is exactly what caused the "accidentally
edited an existing query while trying to create a new one" problem
from the previous round).

Internal predicate keys stay in English (matching
spatial_query_engine.PREDICATES) regardless of display language --
PREDICATE_LABELS_RU is presentation-only. PREDICATE_UI_ORDER is a
separate, purely cosmetic ordering for the two-column checkbox grid;
it doesn't affect PREDICATES' own iteration order anywhere else.
"""

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.core import QgsMapLayerProxyModel
from qgis.gui import QgsMapLayerComboBox
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QDockWidget,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .spatial_query_engine import PREDICATES

PREDICATE_LABELS_RU = {
    "Intersects": "Пересекает",
    "Within": "Находится внутри",
    "Contains": "Содержит",
    "Overlaps": "Накладывается",
    "Touches": "Касается",
    "Equals": "Совпадает",
    "Crosses": "Пересекает (линейно)",
    "Disjoint": "Не пересекает",
}

PREDICATE_UI_ORDER = ["Intersects", "Touches", "Contains", "Overlaps", "Disjoint", "Within", "Equals", "Crosses"]

TABLE_COLUMNS = ["Слой-результат", "Целевой слой", "Слой выборки", "Статус"]


class QueryPanel(QDockWidget):
    subjectLayerChanged = pyqtSignal(object)   # QgsVectorLayer or None
    selectionLayerChanged = pyqtSignal(object)
    createRequested = pyqtSignal()             # "Выполнить"
    queryRowSelected = pyqtSignal(object)       # registry key of the clicked row, or None
    removeRequested = pyqtSignal()              # "Удалить" -- acts on the selected row
    refreshRequested = pyqtSignal()             # "Обновить" -- acts on the selected row
    rowAutoUpdateToggled = pyqtSignal(bool)     # acts on the selected row
    rowPeriodicRefreshChanged = pyqtSignal(bool, int)  # acts on the selected row

    def __init__(self, iface, parent=None):
        super().__init__("Динамический пространственный запрос", parent)
        self.iface = iface
        self.setObjectName("DynamicSpatialQueryPanel")

        outer = QWidget(self)
        outer_layout = QVBoxLayout(outer)
        outer_layout.setContentsMargins(4, 4, 4, 4)

        toggle_row = QHBoxLayout()
        toggle_row.addStretch(2)
        self.toggle_right_btn = QPushButton("‹")
        self.toggle_right_btn.setFixedWidth(24)
        self.toggle_right_btn.setToolTip("Показать/скрыть список запросов")
        self.toggle_right_btn.clicked.connect(self._toggle_right_panel)
        toggle_row.addWidget(self.toggle_right_btn)
        toggle_row.addStretch(1)
        outer_layout.addLayout(toggle_row)

        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.addWidget(self._build_left_panel())
        self.splitter.addWidget(self._build_right_panel())
        self.splitter.setStretchFactor(0, 2)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setSizes([320, 220])
        outer_layout.addWidget(self.splitter)

        outer.setLayout(outer_layout)
        self.setWidget(outer)

        self._row_keys = []  # table row index -> registry key, kept in sync with refresh_query_table()

    # -- left side: define + create -------------------------------------

    def _build_left_panel(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        layout.addWidget(QLabel("Извлечь объекты слоя:"))
        self.subject_combo = QgsMapLayerComboBox()
        self.subject_combo.setFilters(QgsMapLayerProxyModel.VectorLayer)
        self.subject_combo.layerChanged.connect(self.subjectLayerChanged.emit)
        layout.addWidget(self.subject_combo)

        pred_box = QGroupBox("где объект (геометрический предикат):")
        pred_layout = QGridLayout()
        self.predicate_checks = {}
        for i, name in enumerate(PREDICATE_UI_ORDER):
            cb = QCheckBox(PREDICATE_LABELS_RU.get(name, name))
            cb.setChecked(name == "Intersects")
            self.predicate_checks[name] = cb
            pred_layout.addWidget(cb, i // 2, i % 2)
        pred_box.setLayout(pred_layout)
        layout.addWidget(pred_box)

        layout.addWidget(QLabel("по отношению к объектам слоя:"))
        self.selection_combo = QgsMapLayerComboBox()
        self.selection_combo.setFilters(QgsMapLayerProxyModel.VectorLayer)
        self.selection_combo.layerChanged.connect(self.selectionLayerChanged.emit)
        layout.addWidget(self.selection_combo)

        layout.addWidget(QLabel("Имя слоя-результата:"))
        self.output_name_edit = QLineEdit("query_result")
        layout.addWidget(self.output_name_edit)

        self.create_btn = QPushButton("Выполнить")
        self.create_btn.clicked.connect(self.createRequested.emit)
        layout.addWidget(self.create_btn)

        self.status_label = QLabel("Готово")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        layout.addStretch()
        return widget

    # -- right side: manage existing queries -----------------------------

    def _build_right_panel(self):
        self.right_panel = QWidget()
        layout = QVBoxLayout(self.right_panel)

        self.table_label = QLabel("Активные запросы (0):")
        layout.addWidget(self.table_label)
        self.query_table = QTableWidget(0, len(TABLE_COLUMNS))
        self.query_table.setHorizontalHeaderLabels(TABLE_COLUMNS)
        self.query_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.query_table.verticalHeader().setVisible(False)
        self.query_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.query_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.query_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.query_table.itemSelectionChanged.connect(self._on_table_selection_changed)
        layout.addWidget(self.query_table)

        btn_row = QHBoxLayout()
        self.remove_btn = QPushButton("Удалить")
        self.remove_btn.setEnabled(False)
        self.remove_btn.clicked.connect(self.removeRequested.emit)
        btn_row.addWidget(self.remove_btn)
        self.refresh_btn = QPushButton("Обновить")
        self.refresh_btn.setEnabled(False)
        self.refresh_btn.setToolTip("Пересчитать выбранный запрос сейчас")
        self.refresh_btn.clicked.connect(self.refreshRequested.emit)
        btn_row.addWidget(self.refresh_btn)
        layout.addLayout(btn_row)

        self.auto_update_check = QCheckBox("Автообновление при изменениях")
        self.auto_update_check.setEnabled(False)
        self.auto_update_check.toggled.connect(self.rowAutoUpdateToggled.emit)
        layout.addWidget(self.auto_update_check)

        periodic_row = QHBoxLayout()
        self.periodic_check = QCheckBox("Также обновлять каждые")
        self.periodic_check.setEnabled(False)
        self.periodic_check.toggled.connect(self._on_periodic_changed)
        periodic_row.addWidget(self.periodic_check)
        self.periodic_spin = QSpinBox()
        self.periodic_spin.setRange(5, 3600)
        self.periodic_spin.setValue(30)
        self.periodic_spin.setSuffix(" с")
        self.periodic_spin.setEnabled(False)
        self.periodic_spin.valueChanged.connect(self._on_periodic_changed)
        periodic_row.addWidget(self.periodic_spin)
        periodic_row.addStretch()
        layout.addLayout(periodic_row)

        layout.addStretch()
        return self.right_panel

    # -- internal handlers --------------------------------------------

    def _toggle_right_panel(self):
        # isHidden() reflects this widget's own explicit shown/hidden
        # state; isVisible() depends on the WHOLE ancestor chain
        # actually being on screen, which isn't true yet right after
        # construction (or ever, in a headless test) -- using it here
        # made the toggle always compute the same direction instead of
        # alternating, caught directly by tests/test_two_pane_ui.py.
        currently_hidden = self.right_panel.isHidden()
        self.right_panel.setVisible(currently_hidden)
        self.toggle_right_btn.setText("‹" if currently_hidden else "›")

    def _on_periodic_changed(self, *_args):
        self.rowPeriodicRefreshChanged.emit(self.periodic_check.isChecked(), self.periodic_spin.value())

    def _on_table_selection_changed(self):
        rows = self.query_table.selectionModel().selectedRows()
        if not rows:
            self.queryRowSelected.emit(None)
            return
        row = rows[0].row()
        if 0 <= row < len(self._row_keys):
            self.queryRowSelected.emit(self._row_keys[row])

    # -- public accessors used by the plugin controller ------------------

    def subject_layer(self):
        return self.subject_combo.currentLayer()

    def selection_layer(self):
        return self.selection_combo.currentLayer()

    def selected_predicates(self):
        return [name for name, cb in self.predicate_checks.items() if cb.isChecked()]

    def output_name(self):
        return self.output_name_edit.text()

    def set_status(self, text):
        self.status_label.setText(text)

    def clear_draft(self, suggested_output_name="query_result"):
        """Resets the left side back to a blank draft -- called after
        a successful creation (ready for the next one) and whenever a
        creation attempt is refused, so a failed try doesn't leave
        stale-looking state behind."""
        self.selection_combo.setLayer(None)
        for name, cb in self.predicate_checks.items():
            cb.setChecked(name == "Intersects")
        self.output_name_edit.setText(suggested_output_name)

    def set_row_controls_enabled(self, enabled):
        self.remove_btn.setEnabled(enabled)
        self.refresh_btn.setEnabled(enabled)
        self.auto_update_check.setEnabled(enabled)
        self.periodic_check.setEnabled(enabled)
        self.periodic_spin.setEnabled(enabled)

    def load_row_settings(self, auto_update_enabled, periodic_enabled, periodic_seconds):
        """Only the two update-frequency controls -- there is nothing
        else to load, since layers/predicates/name aren't editable
        once a query exists."""
        self.auto_update_check.blockSignals(True)
        self.auto_update_check.setChecked(auto_update_enabled)
        self.auto_update_check.blockSignals(False)

        self.periodic_check.blockSignals(True)
        self.periodic_check.setChecked(periodic_enabled)
        self.periodic_check.blockSignals(False)

        self.periodic_spin.blockSignals(True)
        self.periodic_spin.setValue(periodic_seconds)
        self.periodic_spin.blockSignals(False)

    def refresh_query_table(self, rows):
        """
        rows: list of (key, output_name, subject_name, selection_name,
        status_text) tuples, one per currently-registered query.
        """
        self.table_label.setText(f"Активные запросы ({len(rows)}):")
        self._row_keys = [r[0] for r in rows]
        self.query_table.setRowCount(len(rows))
        for i, (_key, output_name, subject_name, selection_name, status_text) in enumerate(rows):
            for col, value in enumerate([output_name, subject_name, selection_name, status_text]):
                item = QTableWidgetItem(value)
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.query_table.setItem(i, col, item)

    def select_table_row_for_key(self, key):
        """Highlights the row for `key` without re-emitting
        queryRowSelected (the caller already knows what it wants)."""
        self.query_table.blockSignals(True)
        try:
            if key in self._row_keys:
                self.query_table.selectRow(self._row_keys.index(key))
            else:
                self.query_table.clearSelection()
        finally:
            self.query_table.blockSignals(False)
