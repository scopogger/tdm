"""
A floating, independent window (not a QGIS dock widget -- see
plugin.py's module docstring for why), split into two sides by a
QSplitter:

- Left: define and create a query. Always a blank draft -- there is
  no "load an existing query for editing" flow anymore. Pick a
  subject layer, predicates, a selection layer, a result name, click
  "Выполнить". That's the whole surface; nothing here reacts to an
  existing query's state, because nothing here can load one.
- Right (toggleable, resizable): manage queries that already exist --
  the table, "Удалить", "Обновить", and the two update-frequency
  controls, which act on whichever row is currently selected.

The right side's show/hide toggle is a small button embedded directly
in the splitter handle (via a custom QSplitterHandle), matching QGIS's
own "Select by Location" dialog's help-panel toggle -- not a separate
button in a row above the splitter, which is a meaningfully different
visual result even though both "work". Collapsing also happens
natively by dragging the handle all the way to the right (standard
QSplitter collapsible behavior, needs no extra code); both paths are
unified through the same splitter.setSizes() mechanism and the same
remembered last-width, rather than the button using a different
show/hide mechanism than dragging does.

Renaming, changing an existing query's layers, or toggling its
predicates after creation is deliberately not offered -- delete and
recreate instead.

Internal predicate keys stay in English (matching
spatial_query_engine.PREDICATES) regardless of display language --
PREDICATE_LABELS_RU is presentation-only. PREDICATE_UI_ORDER is a
separate, purely cosmetic ordering for the two-column checkbox grid.
"""

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.core import QgsMapLayerProxyModel
from qgis.gui import QgsMapLayerComboBox
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QSplitter,
    QSplitterHandle,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .spatial_query_engine import PREDICATES

PREDICATE_LABELS_RU = {
    "Intersects": "Пересекает",
    "Within": "Находится внутри",
    "Contains": "Содержит",
    "Overlaps": "Накладывается",
    "Touches": "Касается",
    "Equals": "Совпадает",
    "Crosses": "Пересекает (линейно)",
    "Disjoint": "Не пересекает",
}

PREDICATE_UI_ORDER = ["Intersects", "Touches", "Contains", "Overlaps", "Disjoint", "Within", "Equals", "Crosses"]

TABLE_COLUMNS = ["Слой-результат", "Целевой слой", "Слой выборки", "Статус"]

DEFAULT_RIGHT_WIDTH = 220
HANDLE_WIDTH = 12


class _RightPanelToggleHandle(QSplitterHandle):
    """The splitter handle between the two sides, with a small button
    embedded at its top -- clicking it collapses/expands the right
    side to/from its last known width. Deliberately goes through
    QSplitter.setSizes() rather than QWidget.setVisible(), the same
    mechanism dragging the handle itself uses, so both ways of
    collapsing stay consistent with each other (confirmed directly
    that setSizes() alone is enough -- the widget doesn't need to
    also be explicitly hidden for this to work correctly)."""

    def __init__(self, orientation, parent):
        super().__init__(orientation, parent)
        self.toggle_btn = QPushButton("‹", self)
        self.toggle_btn.setFixedSize(HANDLE_WIDTH, 16)
        self.toggle_btn.setStyleSheet("QPushButton { padding: 0px; font-size: 8px; }")
        self.toggle_btn.setToolTip("Показать/скрыть список запросов")
        # Without this, hovering the button shows the handle's own
        # resize cursor -- a QWidget with no cursor explicitly set
        # inherits its parent's, and the splitter handle sets a
        # SplitHCursor over its whole area, button included.
        self.toggle_btn.setCursor(Qt.ArrowCursor)
        self.toggle_btn.clicked.connect(self._on_click)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        x = max(0, (self.width() - self.toggle_btn.width()) // 2)
        self.toggle_btn.move(x, 2)

    def _on_click(self):
        self.splitter()._toggle_right_panel()


class _CollapsibleSplitter(QSplitter):
    """Plain QSplitter, except createHandle() returns the custom
    handle above instead of the default one, and it remembers the
    right side's last non-zero width so both the embedded button and
    dragging the handle back out restore the SAME width instead of
    some fixed default."""

    def __init__(self, parent=None):
        super().__init__(Qt.Horizontal, parent)
        self.setHandleWidth(HANDLE_WIDTH)
        self._last_right_width = DEFAULT_RIGHT_WIDTH
        self.splitterMoved.connect(self._on_splitter_moved)

    def createHandle(self):
        return _RightPanelToggleHandle(self.orientation(), self)

    def _on_splitter_moved(self, _pos, _index):
        sizes = self.sizes()
        if len(sizes) > 1 and sizes[1] > 0:
            self._last_right_width = sizes[1]
        self._update_handle_icon()

    def _toggle_right_panel(self):
        sizes = self.sizes()
        total = sum(sizes)
        if sizes[1] > 0:
            self._last_right_width = sizes[1]
            self.setSizes([total, 0])
        else:
            restore = min(self._last_right_width, total - 80) if total > 80 else self._last_right_width
            self.setSizes([total - restore, restore])
        self._update_handle_icon()

    def _update_handle_icon(self):
        handle = self.handle(1)
        if handle is None:
            return
        collapsed = self.sizes()[1] == 0
        handle.toggle_btn.setText("›" if collapsed else "‹")


class QueryPanel(QWidget):
    subjectLayerChanged = pyqtSignal(object)   # QgsVectorLayer or None
    selectionLayerChanged = pyqtSignal(object)
    createRequested = pyqtSignal()             # "Выполнить"
    queryRowSelected = pyqtSignal(object)       # registry key of the clicked row, or None
    removeRequested = pyqtSignal()              # "Удалить" -- acts on the selected row
    refreshRequested = pyqtSignal()             # "Обновить" -- acts on the selected row
    rowAutoUpdateToggled = pyqtSignal(bool)     # acts on the selected row
    rowPeriodicRefreshChanged = pyqtSignal(bool, int)  # acts on the selected row
    windowVisibilityChanged = pyqtSignal(bool)  # replaces QDockWidget.visibilityChanged,
    # which a plain floating QWidget doesn't have

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setObjectName("DynamicSpatialQueryPanel")
        self.setWindowTitle("Динамический пространственный запрос")
        self.setWindowFlags(Qt.Window)
        self.resize(720, 480)

        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(4, 4, 4, 4)

        self.splitter = _CollapsibleSplitter()
        self.splitter.addWidget(self._build_left_panel())
        self.splitter.addWidget(self._build_right_panel())
        self.splitter.setStretchFactor(0, 2)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setCollapsible(0, False)  # only the right side collapses
        self.splitter.setCollapsible(1, True)
        self.right_panel.setMinimumWidth(150)   # drag settles at 0 or >=150, not an awkward sliver
        self.splitter.setSizes([320, DEFAULT_RIGHT_WIDTH])
        outer_layout.addWidget(self.splitter)

        self._row_keys = []  # table row index -> registry key, kept in sync with refresh_query_table()

    # -- window lifecycle (replaces QDockWidget behavior) -----------------

    def showEvent(self, event):
        super().showEvent(event)
        self.windowVisibilityChanged.emit(True)

    def hideEvent(self, event):
        super().hideEvent(event)
        self.windowVisibilityChanged.emit(False)

    def closeEvent(self, event):
        # The window's own [x] button hides rather than destroys it --
        # the plugin stays loaded and the panel can be reopened from
        # the toolbar action. This is the ONLY path that reaches
        # closeEvent(): the plugin's own unload() deliberately calls
        # hide() directly rather than close() (see plugin.py's
        # unload() for why -- close() turned out to cause a real,
        # hard-to-diagnose crash by tearing down child widgets
        # separately from this panel instead of together with it).
        event.ignore()
        self.hide()

    # -- left side: define + create -------------------------------------

    def _build_left_panel(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        layout.addWidget(QLabel("Извлечь объекты слоя:"))
        self.subject_combo = QgsMapLayerComboBox()
        self.subject_combo.setFilters(QgsMapLayerProxyModel.VectorLayer)
        self.subject_combo.layerChanged.connect(self.subjectLayerChanged.emit)
        layout.addWidget(self.subject_combo)

        pred_box = QGroupBox("где объект (геометрический предикат):")
        pred_layout = QGridLayout()
        self.predicate_checks = {}
        for i, name in enumerate(PREDICATE_UI_ORDER):
            cb = QCheckBox(PREDICATE_LABELS_RU.get(name, name))
            cb.setChecked(name == "Intersects")
            self.predicate_checks[name] = cb
            pred_layout.addWidget(cb, i // 2, i % 2)
        pred_box.setLayout(pred_layout)
        layout.addWidget(pred_box)

        layout.addWidget(QLabel("по отношению к объектам слоя:"))
        self.selection_combo = QgsMapLayerComboBox()
        self.selection_combo.setFilters(QgsMapLayerProxyModel.VectorLayer)
        self.selection_combo.layerChanged.connect(self.selectionLayerChanged.emit)
        layout.addWidget(self.selection_combo)

        separator = QFrame()
        separator.setFrameShape(QFrame.HLine)
        separator.setFrameShadow(QFrame.Sunken)
        layout.addWidget(separator)

        layout.addWidget(QLabel("Имя слоя-результата:"))
        self.output_name_edit = QLineEdit("query_result")
        layout.addWidget(self.output_name_edit)

        self.create_btn = QPushButton("Выполнить")
        self.create_btn.clicked.connect(self.createRequested.emit)
        layout.addWidget(self.create_btn)

        self.status_label = QLabel("Готово")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        layout.addStretch()
        return widget

    # -- right side: manage existing queries -----------------------------

    def _build_right_panel(self):
        self.right_panel = QWidget()
        layout = QVBoxLayout(self.right_panel)

        self.table_label = QLabel("Активные запросы (0):")
        layout.addWidget(self.table_label)
        self.query_table = QTableWidget(0, len(TABLE_COLUMNS))
        self.query_table.setHorizontalHeaderLabels(TABLE_COLUMNS)
        self.query_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.query_table.verticalHeader().setVisible(False)
        self.query_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.query_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.query_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.query_table.itemSelectionChanged.connect(self._on_table_selection_changed)
        layout.addWidget(self.query_table)

        btn_row = QHBoxLayout()
        self.remove_btn = QPushButton("Удалить")
        self.remove_btn.setEnabled(False)
        self.remove_btn.clicked.connect(self.removeRequested.emit)
        btn_row.addWidget(self.remove_btn)
        self.refresh_btn = QPushButton("Обновить")
        self.refresh_btn.setEnabled(False)
        self.refresh_btn.setToolTip("Пересчитать выбранный запрос сейчас")
        self.refresh_btn.clicked.connect(self.refreshRequested.emit)
        btn_row.addWidget(self.refresh_btn)
        layout.addLayout(btn_row)

        self.auto_update_check = QCheckBox("Автообновление при изменениях")
        self.auto_update_check.setEnabled(False)
        self.auto_update_check.toggled.connect(self.rowAutoUpdateToggled.emit)
        layout.addWidget(self.auto_update_check)

        periodic_row = QHBoxLayout()
        self.periodic_check = QCheckBox("Также обновлять каждые")
        self.periodic_check.setEnabled(False)
        self.periodic_check.toggled.connect(self._on_periodic_changed)
        periodic_row.addWidget(self.periodic_check)
        self.periodic_spin = QSpinBox()
        self.periodic_spin.setRange(5, 3600)
        self.periodic_spin.setValue(30)
        self.periodic_spin.setSuffix(" с")
        self.periodic_spin.setEnabled(False)
        self.periodic_spin.valueChanged.connect(self._on_periodic_changed)
        periodic_row.addWidget(self.periodic_spin)
        periodic_row.addStretch()
        layout.addLayout(periodic_row)

        layout.addStretch()
        return self.right_panel

    # -- internal handlers --------------------------------------------

    def _on_periodic_changed(self, *_args):
        self.rowPeriodicRefreshChanged.emit(self.periodic_check.isChecked(), self.periodic_spin.value())

    def _on_table_selection_changed(self):
        rows = self.query_table.selectionModel().selectedRows()
        if not rows:
            self.queryRowSelected.emit(None)
            return
        row = rows[0].row()
        if 0 <= row < len(self._row_keys):
            self.queryRowSelected.emit(self._row_keys[row])

    # -- public accessors used by the plugin controller ------------------

    def subject_layer(self):
        return self.subject_combo.currentLayer()

    def selection_layer(self):
        return self.selection_combo.currentLayer()

    def selected_predicates(self):
        return [name for name, cb in self.predicate_checks.items() if cb.isChecked()]

    def output_name(self):
        return self.output_name_edit.text()

    def set_status(self, text):
        self.status_label.setText(text)

    def clear_draft(self, suggested_output_name="query_result"):
        """Resets the left side back to a blank draft -- called after
        a successful creation (ready for the next one) and whenever a
        creation attempt is refused, so a failed try doesn't leave
        stale-looking state behind."""
        self.selection_combo.setLayer(None)
        for name, cb in self.predicate_checks.items():
            cb.setChecked(name == "Intersects")
        self.output_name_edit.setText(suggested_output_name)

    def set_row_controls_enabled(self, enabled):
        self.remove_btn.setEnabled(enabled)
        self.refresh_btn.setEnabled(enabled)
        self.auto_update_check.setEnabled(enabled)
        self.periodic_check.setEnabled(enabled)
        self.periodic_spin.setEnabled(enabled)

    def load_row_settings(self, auto_update_enabled, periodic_enabled, periodic_seconds):
        """Only the two update-frequency controls -- there is nothing
        else to load, since layers/predicates/name aren't editable
        once a query exists."""
        self.auto_update_check.blockSignals(True)
        self.auto_update_check.setChecked(auto_update_enabled)
        self.auto_update_check.blockSignals(False)

        self.periodic_check.blockSignals(True)
        self.periodic_check.setChecked(periodic_enabled)
        self.periodic_check.blockSignals(False)

        self.periodic_spin.blockSignals(True)
        self.periodic_spin.setValue(periodic_seconds)
        self.periodic_spin.blockSignals(False)

    def refresh_query_table(self, rows):
        """
        rows: list of (key, output_name, subject_name, selection_name,
        status_text) tuples, one per currently-registered query.
        """
        self.table_label.setText(f"Активные запросы ({len(rows)}):")
        self._row_keys = [r[0] for r in rows]
        self.query_table.setRowCount(len(rows))
        for i, (_key, output_name, subject_name, selection_name, status_text) in enumerate(rows):
            for col, value in enumerate([output_name, subject_name, selection_name, status_text]):
                item = QTableWidgetItem(value)
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.query_table.setItem(i, col, item)

    def select_table_row_for_key(self, key):
        """Highlights the row for `key` without re-emitting
        queryRowSelected (the caller already knows what it wants)."""
        self.query_table.blockSignals(True)
        try:
            if key in self._row_keys:
                self.query_table.selectRow(self._row_keys.index(key))
            else:
                self.query_table.clearSelection()
        finally:
            self.query_table.blockSignals(False)
