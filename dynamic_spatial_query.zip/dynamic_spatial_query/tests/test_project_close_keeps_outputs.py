"""
Regression: closing the project (New project, opening another
project, quitting QGIS) while the plugin is loaded used to DELETE every
query's output GeoPackage. QGIS removes all layers when a project
closes, which reached the same "output layer deleted by hand -> delete
its file" cleanup as a real manual removal. Reopening the project then
found its result layers' files gone.

Checks, with the plugin loaded the whole time (unlike
test_persistence_with_new_workflow.py, which unloads it first):
closing keeps the file, reopening restores the query with its data and
it keeps updating; and deleting an output layer by hand still deletes
its file, as before.
"""
import os
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem, QgsCoordinateTransformContext, QgsFeature, QgsGeometry,
    QgsProject, QgsVectorFileWriter, QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from _test_helpers import wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


def pump(seconds):
    t = time.time()
    while time.time() - t < seconds:
        QCoreApplication.processEvents()
        time.sleep(0.05)


WORKDIR = tempfile.mkdtemp(prefix="dsq_close_")


def gpkg(name, geometry_type, wkts):
    memory = QgsVectorLayer(f"{geometry_type}?crs=EPSG:3857", name, "memory")
    feats = []
    for wkt in wkts:
        f = QgsFeature()
        f.setGeometry(QgsGeometry.fromWkt(wkt))
        feats.append(f)
    memory.dataProvider().addFeatures(feats)
    path = os.path.join(WORKDIR, f"{name}.gpkg")
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = name
    QgsVectorFileWriter.writeAsVectorFormatV3(memory, path, QgsCoordinateTransformContext(), options)
    return QgsVectorLayer(f"{path}|layername={name}", name, "ogr")


project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))
project_path = os.path.join(WORKDIR, "close_test.qgz")
project.setFileName(project_path)
zone = gpkg("zone", "Polygon", ["POLYGON((0 0,10 0,10 10,0 10,0 0))"])
pts = gpkg("pts", "Point", ["POINT(1 1)", "POINT(50 50)"])
project.addMapLayers([zone, pts])

plugin = DynamicSpatialQueryPlugin(get_iface())
plugin.initGui()
plugin.panel.subject_combo.setLayer(pts)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)
plugin.panel.createRequested.emit()
q = list(plugin._queries.values())[0]
check("query created", wait_for(lambda: q.engine._task is None and q.engine._output_layer is not None, 10))
out_path = q.engine.output_gpkg_file_path()
project.write()

print("--- close the project with the plugin loaded ---")
project.clear()
pump(1.5)  # longer than the 500 ms deferred file cleanup
check("output file still exists after the project closed", os.path.exists(out_path))

print("--- reopen ---")
project.read(project_path)
QCoreApplication.processEvents()
check("query restored", len(plugin._queries) == 1, len(plugin._queries))
q = list(plugin._queries.values())[0] if plugin._queries else None
out = q.engine._output_layer if q else None
check("output layer valid with its data", out is not None and out.isValid() and out.featureCount() == 1,
      out.featureCount() if out else None)
pts = next(l for l in project.mapLayers().values() if l.name() == "pts")
pts.startEditing()
f = QgsFeature(pts.fields())
f.setGeometry(QgsGeometry.fromWkt("POINT(2 2)"))
pts.addFeature(f)
pts.commitChanges()
check("still live after reopening",
      q is not None and wait_for(lambda: q.engine._task is None and out.featureCount() == 2, 10),
      out.featureCount() if out else None)

print("--- deleting the output layer by hand still cleans up its file ---")
project.removeMapLayer(out.id())
pump(1.5)
check("query gone", not plugin._queries)
check("file deleted", not os.path.exists(out_path))

plugin.unload()
print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
print("RESULT: all checks passed")
