"""
The actual bug this guards against: recalculate() dispatches
_compute_matches() to a real background QgsTask (via
QgsTask.fromFunction, run through QGIS's real task manager and
thread pool -- not called directly, which would prove nothing about
thread safety). Earlier, _compute_matches() called .getFeatures()
directly on the QgsVectorLayer objects from inside that background
task -- fine against memory-provider layers (why it went unnoticed
through a lot of testing against memory layers), but this froze the
whole QGIS session against PostgreSQL-backed layers, since libpq
connections aren't safe to use from a thread other than the one they
were created on. Fixed by constructing QgsVectorLayerFeatureSource
objects on the main thread before dispatching, and using only those
inside the background task.

A frozen session doesn't raise a Python exception to catch -- it just
never completes. So the meaningful assertion here is a bounded wait:
the real background task must finish within a generous timeout, not
hang. If this regresses, this test will time out rather than fail
outright, which is a correct reflection of what the actual bug looked
like.
"""
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import QgsCoordinateReferenceSystem, QgsProject, QgsVectorLayer  # noqa: E402

from dynamic_spatial_query.spatial_query_engine import SpatialQueryEngine  # noqa: E402
from _test_helpers import run_and_wait  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


CONN = "dbname='qgis_test' host=localhost user='postgres' password='postgres'"

print("=" * 70)
print("0. Set up real PostGIS tables with real data")
print("=" * 70)

setup_sql = """
DROP TABLE IF EXISTS pg_zones CASCADE;
DROP TABLE IF EXISTS pg_buildings CASCADE;

CREATE TABLE pg_zones (
    id serial PRIMARY KEY,
    zone_name text,
    geom geometry(Polygon, 3857)
);
INSERT INTO pg_zones (zone_name, geom) VALUES
    ('Z1', ST_GeomFromText('POLYGON((0 0,100 0,100 100,0 100,0 0))', 3857));

CREATE TABLE pg_buildings (
    id serial PRIMARY KEY,
    bname text,
    geom geometry(Point, 3857)
);
INSERT INTO pg_buildings (bname, geom) VALUES
    ('b_in', ST_GeomFromText('POINT(50 50)', 3857)),
    ('b_out', ST_GeomFromText('POINT(500 500)', 3857));
"""
result = subprocess.run(
    ["psql", "-h", "localhost", "-U", "postgres", "-d", "qgis_test", "-c", setup_sql],
    env={"PGPASSWORD": "postgres", "PATH": "/usr/bin"},
    capture_output=True, text=True,
)
check("PostGIS test tables created", result.returncode == 0, result.stderr)

iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

zones = QgsVectorLayer(
    f"{CONN} sslmode=disable key='id' srid=3857 type=Polygon table=\"public\".\"pg_zones\" (geom)",
    "pg_zones", "postgres",
)
buildings = QgsVectorLayer(
    f"{CONN} sslmode=disable key='id' srid=3857 type=Point table=\"public\".\"pg_buildings\" (geom)",
    "pg_buildings", "postgres",
)
check("zones layer is valid", zones.isValid())
check("buildings layer is valid", buildings.isValid())
project.addMapLayers([zones, buildings], False)

print()
print("=" * 70)
print("1. Run the REAL engine, through a REAL background QgsTask, against real PostgreSQL layers")
print("=" * 70)

engine = SpatialQueryEngine(iface)
engine.set_subject_layer(buildings)
engine.set_selection_layer(zones)
engine.set_predicates(["Intersects"])

# The actual bug: this used to hang indefinitely against PostgreSQL
# layers. run_and_wait() has a bounded timeout -- a regression here
# shows up as a timeout, not a normal assertion failure, which is the
# correct reflection of what the bug looked like (a frozen QGIS
# session, not an exception).
count, error = run_and_wait(engine, timeout_s=15.0)
check("recalculate() against real PostgreSQL layers completed (did not hang)",
      error != "timed out waiting for recalculate() to finish", error)
check("no error", error is None, error)
check("found exactly the 1 building inside the zone", count == 1, count)

output = engine._output_layer
check("output layer created", output is not None)
if output is not None:
    names = [f["bname"] for f in output.getFeatures()]
    check("correct building in the output", names == ["b_in"], names)

print()
print("=" * 70)
print("2. A second recalculation (e.g. after an edit) also completes without hanging")
print("=" * 70)

count2, error2 = run_and_wait(engine, timeout_s=15.0)
check("second recalculation against real PostgreSQL layers also completed", error2 is None, error2)
check("count stable", count2 == 1, count2)

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
