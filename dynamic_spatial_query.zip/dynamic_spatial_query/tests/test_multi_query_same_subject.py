"""
Two independent queries sharing the same subject layer -- the actual
case the removed "already used" restriction was blocking -- must
each get their own stable query_id, their own output table (no name
collision), and both survive a project reload independently. This is
what actually makes the restriction's removal safe, not just
possible: query_id (not subject_layer_id) is what output table
naming and reattachment are keyed by now (see
spatial_query_engine.py).
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from _test_helpers import wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

buildings = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "buildings", "memory")
bf1 = QgsFeature(buildings.fields())
bf1.setGeometry(QgsGeometry.fromWkt("POINT(5 5)"))
bf1.setAttribute("name", "b_in_a")
bf2 = QgsFeature(buildings.fields())
bf2.setGeometry(QgsGeometry.fromWkt("POINT(15 15)"))
bf2.setAttribute("name", "b_in_b")
buildings.dataProvider().addFeatures([bf1, bf2])

zone_a = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone_a", "memory")
zaf = QgsFeature(zone_a.fields())
zaf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,10 0,10 10,0 10,0 0))"))
zone_a.dataProvider().addFeatures([zaf])

zone_b = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone_b", "memory")
zbf = QgsFeature(zone_b.fields())
zbf.setGeometry(QgsGeometry.fromWkt("POLYGON((10 10,20 10,20 20,10 20,10 10))"))
zone_b.dataProvider().addFeatures([zbf])

project.addMapLayers([buildings, zone_a, zone_b], False)
for lyr in (buildings, zone_a, zone_b):
    project.layerTreeRoot().addLayer(lyr)

print("=" * 70)
print("1. Create two independent queries, both with 'buildings' as subject")
print("=" * 70)

plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()

plugin.panel.subject_combo.setLayer(buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone_a)
plugin.panel.output_name_edit.setText("buildings_in_a")
plugin.panel.createRequested.emit()
ok = wait_for(lambda: len(plugin._queries) == 1, 5.0)
check("first query created", ok)
key_a = next(iter(plugin._queries.keys()))

plugin.panel.subject_combo.setLayer(buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone_b)
plugin.panel.output_name_edit.setText("buildings_in_b")
plugin.panel.createRequested.emit()
ok = wait_for(lambda: len(plugin._queries) == 2, 5.0)
check("second query created (same subject, different selection)", ok)
key_b = next(iter(set(plugin._queries.keys()) - {key_a}))

ok_a = wait_for(lambda: plugin._queries[key_a].engine._task is None, 5.0)
ok_b = wait_for(lambda: plugin._queries[key_b].engine._task is None, 5.0)
check("both settle", ok_a and ok_b)
check("query A found the building in zone A only",
      plugin._queries[key_a].engine._output_layer.featureCount() == 1)
check("query B found the building in zone B only",
      plugin._queries[key_b].engine._output_layer.featureCount() == 1)

output_a_id = plugin._queries[key_a].engine._output_layer.id()
output_b_id = plugin._queries[key_b].engine._output_layer.id()
check("distinct output layers, no collision", output_a_id != output_b_id)

print()
print("=" * 70)
print("2. Both persist independently across a real project reload")
print("=" * 70)

save_path = "/tmp/dsq_multi_query_same_subject_test.qgs"
project.write(save_path)
plugin.unload()
project.clear()
project.read(save_path)

reloaded_buildings = next(lyr for lyr in project.mapLayers().values() if lyr.name() == "buildings")
reloaded_out_a = next(lyr for lyr in project.mapLayers().values() if lyr.name() == "buildings_in_a")
reloaded_out_b = next(lyr for lyr in project.mapLayers().values() if lyr.name() == "buildings_in_b")
check("query A's output survived reload with its data", reloaded_out_a.featureCount() == 1)
check("query B's output survived reload with its data", reloaded_out_b.featureCount() == 1)
check("still two distinct output layers after reload", reloaded_out_a.id() != reloaded_out_b.id())

plugin2 = DynamicSpatialQueryPlugin(iface)
plugin2.initGui()
QCoreApplication.processEvents()

check("both queries restored on load, still independent", len(plugin2._queries) == 2,
      len(plugin2._queries))
restored_subjects = [q.engine.subject_layer.id() for q in plugin2._queries.values()]
check("both restored queries correctly point at the same reloaded subject layer",
      all(sid == reloaded_buildings.id() for sid in restored_subjects), restored_subjects)

plugin2.unload()

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
