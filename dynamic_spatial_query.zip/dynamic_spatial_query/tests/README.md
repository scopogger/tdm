# Tests

Plain scripts run against a real headless PyQGIS (3.34) with
`QT_QPA_PLATFORM=offscreen`, no display needed, `iface` mocked via
QGIS's own `qgis.testing.mocked.get_iface()`.

| File | Covers |
|---|---|
| `test_engine.py` | Core predicate correctness, attribute preservation, self-comparison, subject-layer-swap rebuilding the output type |
| `test_create_remove_workflow.py` | This round's actual changes: no auto-creation, the Create/Remove button flow, the management table, and reactive cleanup when a query's subject/selection/output layer is deleted directly from QGIS's own Layers panel |
| `test_persistence_with_new_workflow.py` | A query created through the real button flow still persists its data and resumes updating after a real project save/reload, with zero panel interaction |

Setup:

```bash
apt-get install python3-qgis python3-mock postgresql postgresql-16 postgis postgresql-16-postgis-3
service postgresql start
su postgres -c "psql -c \"ALTER USER postgres PASSWORD 'postgres';\""
su postgres -c "createdb qgis_test"
su postgres -c "psql -d qgis_test -c 'CREATE EXTENSION postgis;'"
export QT_QPA_PLATFORM=offscreen
```

Run everything:

```bash
cd dynamic_spatial_query/tests
for f in test_engine.py test_create_remove_workflow.py test_persistence_with_new_workflow.py; do
    python3 "$f" || echo "FAILED: $f"
done
```

## What actually turned up writing these

`test_create_remove_workflow.py` caught a real crash: cleanup on
layer deletion was originally wired to `QgsProject.layersRemoved`,
which fires *after* the layer's C++ object is already destroyed.
Calling `.id()` on it, or disconnecting a watcher's signal
connections from it, produced an uncatchable segfault -- not a Python
exception, so no try/except could have saved it. Switched to
`layersWillBeRemoved` (confirmed directly to fire while the layer is
still fully valid) and the crash is gone. Worth knowing about even
outside this plugin: if a QGIS plugin needs to react to a layer being
removed and touch anything about that layer, `layersWillBeRemoved` is
very likely the signal you want, not `layersRemoved`.

## What this does not prove

Same caveats as before: QGIS 3.34 rather than exactly 3.32.2, Python
3.12 runtime rather than the target 3.9 (plugin source checked
separately for 3.10+-only syntax and has none), and a mocked `iface`
rather than a real Desktop window -- so the actual visual layout of
the table/buttons in Russian is unverified; only their text content
and behavior are.
