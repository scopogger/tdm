# Tests

Plain scripts run against a real headless PyQGIS (3.34) with
`QT_QPA_PLATFORM=offscreen`, no display needed, `iface` mocked via
QGIS's own `qgis.testing.mocked.get_iface()`.

| File | Covers |
|---|---|
| `test_engine.py` | Core predicate correctness, attribute preservation, self-comparison, subject-layer-swap rebuilding the output type and resetting query_id |
| `test_two_pane_ui.py` | The split-panel UI: no auto-creation, the Create-only left side, manage-only right side, creating a second query with the same subject (now succeeds, not refused), and the embedded splitter-handle toggle button (collapse/expand, remembered width, both via the button and via simulated drag) |
| `test_persistence_with_new_workflow.py` | A query created through the real button flow still persists its data and resumes updating after a real project save/reload, with zero panel interaction |
| `test_predicate_validation.py` | The no-predicates-selected fix and predicate label terminology |
| `test_unload_crash_regression.py` | Reproduces the exact sequence that used to abort the process after `unload()` -- see the main README's crash writeup |
| `test_layer_rename_reactivity.py` | Renaming a query's subject, selection, or output layer directly (matching what QGIS's own Layers panel does) updates the management table |
| `test_postgis_thread_safety.py` | Runs the engine through a real background `QgsTask` against a real PostGIS-backed layer with a bounded timeout -- see the main README's freeze writeup |
| `test_multi_query_same_subject.py` | Two independent queries sharing the same subject layer: distinct query_ids, distinct output files (no GeoPackage contention), both settle correctly, both survive a reload independently |
| `test_output_file_organization.py` | Each query's file lives in the dedicated subfolder, not loose in the project directory; removing a query deletes its file; two queries' files are cleaned up independently |
| `test_first_query_autoselect.py` | Creating the first query (table goes from 0 rows to 1) correctly selects it and enables the row controls -- the empty-to-first-row transition that didn't fire `itemSelectionChanged` |
| `test_database_layer_filter_reactivity.py` | A database-backed query (real PostgreSQL) now defaults identically to a local-only query (auto-update on, checkbox not grayed out); changing the subject layer's filter via `setSubsetString()` (the same mechanism as QGIS's own Query Builder) triggers an instant recalculation, not just eventually via a timer -- corrects an earlier over-correction, see the main README |
| `test_user_feedback_fixes.py` | Background tasks carry the `Silent` flag (suppressing OS-level popups); the management table's status column distinguishes timer-driven updates from genuinely paused; the "Показать список запросов" menu action un-hides and un-collapses the panel |
| `test_union_mode.py` | The «Объединение» mode with tester-like GeoPackage layers (ООПТ/ТТП/ВОЗ/ИКН, one invalid polygon): polygon-only list, refusal below two layers, exact hand-worked pieces and areas, piece-by-piece match with `native:union` run directly, invalid geometry skipped and reported, live edit/filter updates, union → extract chain, schema change, rename, save/close/reopen, PostgreSQL input, teardown and «Удалить» |
| `test_merge_mode.py` | «Слияние» on the tester's lake/island/pipe example (union gives 5 m + 5 m, merge gives one object and 10 m, also with the island as a hole); identical geometry to QGIS's Merge vector layers + Dissolve; point and line merges; line and point unions vs QGIS's Union; mixed types refused; live updates; invalid geometry skipped; chaining; save/close/reopen; teardown; «Удалить» |
| `test_project_close_keeps_outputs.py` | Closing the project with the plugin loaded keeps output files (it used to delete them); reopening restores the query live; deleting an output layer by hand still deletes its file |
| `test_postgres_listen.py` (+ `_listen_gate_child.py`) | PostgreSQL LISTEN/NOTIFY: the QGIS-version gate at every release boundary; on this environment's unfixed QGIS 3.34.4, an auth-configuration layer works in automatic mode and crashes when listening is forced on (control); one shared listener connection per layer, observed via `pg_stat_activity`, released when the last query stops, left alone when QGIS's own setting or a notify-triggered action needs it; end to end, a database INSERT/DELETE through the README's trigger SQL updates the output with the periodic timer off |

Setup:

```bash
apt-get install python3-qgis python3-mock postgresql postgresql-16 postgis postgresql-16-postgis-3
service postgresql start
su postgres -c "psql -c \"ALTER USER postgres PASSWORD 'postgres';\""
su postgres -c "createdb qgis_test"
su postgres -c "psql -d qgis_test -c 'CREATE EXTENSION postgis;'"
export QT_QPA_PLATFORM=offscreen
```

Run everything:

```bash
cd dynamic_spatial_query/tests
for f in test_*.py; do
    python3 "$f" || echo "FAILED: $f"
done
```

## Two things worth knowing if you extend this plugin

**`layersWillBeRemoved` vs. `layersRemoved`**: if a QGIS plugin needs
to react to a layer being removed and touch anything about that
layer, `layersWillBeRemoved` (fires while the layer is still fully
valid) is almost certainly the signal you want, not `layersRemoved`
(fires after the layer's C++ object is already destroyed -- confirmed
directly that touching it at that point, even just to disconnect a
signal, produces an uncatchable segfault rather than a normal Python
exception).

**`close()`/`deleteLater()` on a widget with live children can tear
them down out of order**: a real crash here traced back to exactly
this -- calling `close()` then `deleteLater()` on a parent widget
destroyed its child widgets separately from, and before, the parent
itself, leaving an inconsistent state that crashed later when
something touched a signal on it. Confirmed directly by checking
`isHidden()`/liveness on both the parent and a child after teardown:
the child was already dead, the parent was still alive. Just
`hide()`-ing and dropping the last reference, letting normal
parent-child ownership handle eventual cleanup, avoided it entirely.
Two earlier, more targeted-looking fixes (disconnecting a specific
internal signal relay; calling `setProject(None)` on the child combo
boxes) were tested in isolation and did not fix it -- worth knowing
in case a similar-looking crash shows up elsewhere and invites the
same wrong-but-plausible fix.

## What this does not prove

The PostgreSQL listener checks run on QGIS 3.34.4, a version with
QGIS's own listener bug, so the "fixed version" half of the gate is
verified by reading QGIS's source at each release tag plus a manual
test on 3.44 in the affected environment -- not by this suite.

Same caveats as before: QGIS 3.34 rather than exactly 3.32.2, Python
3.12 runtime rather than the target 3.9 (plugin source checked
separately for 3.10+-only syntax and has none), and a mocked `iface`
rather than a real Desktop window -- so the actual visual layout and
pixel-level appearance (the floating window, the splitter, the
embedded handle button) is unverified; only their behavior is. One
concrete example this caused during testing: the left panel's real
minimum content width (driven by the Russian predicate labels) turned
out to be wider than assumed, which silently clamped some splitter
size requests in ways that had nothing to do with the actual toggle
logic being tested -- worth checking the real window at least once
visually before relying on the default panel proportions.
