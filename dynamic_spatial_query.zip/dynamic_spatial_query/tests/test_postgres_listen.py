"""
PostgreSQL LISTEN/NOTIFY ("changes made directly in the database"),
now switched on automatically for QGIS versions where QGIS's own
listener bug (#55707 / #54260, fixed in 3.34.6 and 3.38.0) is fixed,
and off for older ones. See ENABLE_POSTGRES_LISTEN in
reactive_watcher.py for the root cause.

This test environment runs QGIS 3.34.4 -- an UNFIXED version -- which
makes it possible to check both halves for real:

1. The version gate itself, across the exact release boundaries.
2. On this unfixed QGIS, a layer that uses a QGIS authentication
   configuration (the setup that triggers the QGIS bug): automatic
   mode keeps listening off and works; forcing it on breaks the
   process (control -- proves the check above is meaningful).
3. With listening forced on and a connection that does NOT trigger
   the bug (password in the connection), the plugin's own behavior:
   one listener connection per layer no matter how many queries
   watch it, released when the last query stops, the user's own
   Rendering-tab setting left alone.
4. End to end through the plugin: an INSERT into a real table with the
   README's NOTIFY trigger updates the query's output layer, with the
   periodic timer off.
"""
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import Qgis, QgsCoordinateReferenceSystem, QgsProject, QgsVectorLayer  # noqa: E402

import dynamic_spatial_query.reactive_watcher as rw  # noqa: E402
from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from _test_helpers import key_for_subject, wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


def psql(sql):
    return subprocess.run(
        ["psql", "-h", "localhost", "-U", "postgres", "-d", "qgis_test", "-tA", "-c", sql],
        env={"PGPASSWORD": "postgres", "PATH": "/usr/bin"},
        capture_output=True, text=True,
    )


def listener_backends():
    """Database connections currently sitting in LISTEN qgis -- one per
    active QGIS listener. Observed from the database side, so this
    checks what actually happened, not what the plugin thinks."""
    out = psql("SELECT pid FROM pg_stat_activity "
               "WHERE datname = 'qgis_test' AND query = 'LISTEN qgis' ORDER BY pid;")
    return [line for line in out.stdout.split() if line.strip()]


def wait_backends(expected, timeout_s=8.0):
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        QCoreApplication.processEvents()
        if len(listener_backends()) == expected:
            return True
        time.sleep(0.2)
    return len(listener_backends()) == expected


print("=" * 70)
print("0. Set up real PostGIS tables")
print("=" * 70)

r = psql("""
DROP TABLE IF EXISTS listentest_pts CASCADE;
DROP TABLE IF EXISTS listentest_zones CASCADE;
CREATE TABLE listentest_pts (id serial PRIMARY KEY, geom geometry(Point, 3857));
INSERT INTO listentest_pts (geom) VALUES
    (ST_GeomFromText('POINT(10 10)', 3857)),
    (ST_GeomFromText('POINT(20 20)', 3857));
CREATE TABLE listentest_zones (id serial PRIMARY KEY, geom geometry(Polygon, 3857));
INSERT INTO listentest_zones (geom) VALUES
    (ST_GeomFromText('POLYGON((0 0,100 0,100 100,0 100,0 0))', 3857));
""")
check("test tables created", r.returncode == 0, r.stderr)

print()
print("=" * 70)
print(f"1. Version gate (running on QGIS {Qgis.QGIS_VERSION}, int {Qgis.QGIS_VERSION_INT})")
print("=" * 70)

cases = {
    33202: False,  # 3.32.2 -- the version that froze
    33405: False,  # last unfixed 3.34 LTR
    33406: True,   # first fixed 3.34 LTR (backport)
    33415: True,
    33603: False,  # 3.36.3, last 3.36 release, unfixed
    33700: False,  # 3.37 dev builds -- treated as unfixed
    33800: True,   # 3.38.0, first fixed release
    34400: True,   # 3.44 -- confirmed working in the affected environment
    40000: True,
}
for v, expected in cases.items():
    got = rw.qgis_has_postgres_listener_fix(v)
    check(f"version {v} -> fixed={expected}", got == expected, got)

rw.ENABLE_POSTGRES_LISTEN = None
check("automatic mode follows this QGIS's version",
      rw.postgres_listen_enabled() == rw.qgis_has_postgres_listener_fix())
rw.ENABLE_POSTGRES_LISTEN = True
check("True forces on", rw.postgres_listen_enabled() is True)
rw.ENABLE_POSTGRES_LISTEN = False
check("False forces off", rw.postgres_listen_enabled() is False)
rw.ENABLE_POSTGRES_LISTEN = None

print()
print("=" * 70)
print("2. On an unfixed QGIS, with an auth-configuration layer (the bug's trigger)")
print("=" * 70)

child = Path(__file__).resolve().parent / "_listen_gate_child.py"


def run_child(mode):
    try:
        p = subprocess.run([sys.executable, str(child), mode],
                           capture_output=True, text=True, timeout=30)
        return p.returncode, p.stdout + p.stderr
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or "")
        return "TIMEOUT", out


if rw.qgis_has_postgres_listener_fix():
    print("(this QGIS has the fix -- the unfixed-version checks below don't apply here)")
else:
    rc, out = run_child("auto")
    check("automatic mode: layer valid, listening kept OFF on this version",
          "LAYER_VALID True" in out and "LISTEN_ENABLED False" in out, out[-500:])
    check("automatic mode: watch() returns and the process exits cleanly",
          rc == 0 and "RETURNED" in out and "STOPPED" in out, f"rc={rc} {out[-500:]}")

    rc, out = run_child("force_on")
    check("control -- forcing listening ON here breaks the process (QGIS's own bug, "
          "crash headless / freeze with a GUI)",
          rc != 0 and "RETURNED" not in out, f"rc={rc} {out[-300:]}")

print()
print("=" * 70)
print("3. Listening forced on, password in the connection (doesn't trigger the bug)")
print("=" * 70)

rw.ENABLE_POSTGRES_LISTEN = True
CONN = "dbname='qgis_test' host=localhost user='postgres' password='postgres' sslmode=disable"
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))
pts = QgsVectorLayer(f"{CONN} key='id' srid=3857 type=Point table=\"public\".\"listentest_pts\" (geom)",
                     "pg_pts", "postgres")
zones = QgsVectorLayer(f"{CONN} key='id' srid=3857 type=Polygon table=\"public\".\"listentest_zones\" (geom)",
                       "pg_zones", "postgres")
check("layers valid", pts.isValid() and zones.isValid())
project.addMapLayers([pts, zones], False)

base = len(listener_backends())

w1 = rw.ReactiveWatcher()
w1.watch([pts])
check("first watcher opens exactly one listener connection", wait_backends(base + 1),
      listener_backends())
pid_before = listener_backends()

w2 = rw.ReactiveWatcher()
w2.watch([pts])
check("a second watcher on the same layer shares it (still one)", wait_backends(base + 1),
      listener_backends())

w1.watch([pts])
time.sleep(0.5)
check("re-arming a watcher on the same layer doesn't reopen the connection",
      listener_backends() == pid_before, (pid_before, listener_backends()))

w1.stop()
time.sleep(0.5)
check("stopping one watcher keeps it while the other still needs it",
      len(listener_backends()) == base + 1, listener_backends())

w2.stop()
check("stopping the last watcher closes the listener connection", wait_backends(base),
      listener_backends())

pts.setRefreshOnNotifyEnabled(True)
check("user's own Rendering-tab setting opens its listener", wait_backends(base + 1),
      listener_backends())
w3 = rw.ReactiveWatcher()
w3.watch([pts])
w3.stop()
time.sleep(0.5)
check("a query stopping does NOT switch off the user's own setting",
      len(listener_backends()) == base + 1, listener_backends())

# QGIS's own behavior, not the plugin's: unticking the checkbox leaves
# the provider listening on purpose ("someone else could need it (e.g.
# actions)", qgsmaplayer.cpp).
pts.setRefreshOnNotifyEnabled(False)
time.sleep(0.5)
check("QGIS itself leaves the listener open after its checkbox is unticked",
      len(listener_backends()) == base + 1, listener_backends())

# A notification-triggered layer action also relies on listening.
from qgis.core import QgsAction  # noqa: E402
notify_action = QgsAction(Qgis.AttributeActionType.GenericPython, "on notify", "pass",
                          "", False, "", set(), "refresh")
pts.actions().addAction(notify_action)
w4 = rw.ReactiveWatcher()
w4.watch([pts])
w4.stop()
time.sleep(0.5)
check("a query stopping does NOT close a listener a notify-triggered layer action needs",
      len(listener_backends()) == base + 1, listener_backends())
pts.actions().removeAction(notify_action.id())

w5 = rw.ReactiveWatcher()
w5.watch([pts])
w5.stop()
check("with nothing else needing it, a query stopping closes the leftover listener",
      wait_backends(base), listener_backends())

print()
print("=" * 70)
print("4. End to end: an INSERT in the database, with the README's NOTIFY trigger,")
print("   updates the query output -- periodic timer off")
print("=" * 70)

r = psql("""
CREATE OR REPLACE FUNCTION public.notify_qgis() RETURNS trigger AS $$
BEGIN
  NOTIFY qgis;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER listentest_pts_notify_qgis
AFTER INSERT OR UPDATE OR DELETE ON public.listentest_pts
FOR EACH STATEMENT EXECUTE FUNCTION public.notify_qgis();
""")
check("README trigger SQL runs as written", r.returncode == 0, r.stderr)

iface = get_iface()
plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()
plugin.panel.subject_combo.setLayer(pts)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zones)
plugin.panel.createRequested.emit()
key = key_for_subject(plugin, pts)
ok = wait_for(lambda: key in plugin._queries and plugin._queries[key].engine._task is None, 10.0)
check("query created and settled", ok)
q = plugin._queries[key]
check("periodic refresh is off (so only NOTIFY can explain an update)",
      q.periodic_enabled is False and not q.watcher.periodic_refresh_timer.isActive())
check("initial output has 2 points", q.engine._output_layer.featureCount() == 2,
      q.engine._output_layer.featureCount())
check("query holds one listener connection per PostgreSQL layer it watches (subject + selection = 2)",
      wait_backends(base + 2), listener_backends())

r = psql("INSERT INTO listentest_pts (geom) VALUES (ST_GeomFromText('POINT(30 30)', 3857));")
check("row inserted from a separate database session", r.returncode == 0, r.stderr)
ok = wait_for(lambda: q.engine._output_layer.featureCount() == 3, timeout_s=8.0)
check("output picked up the database INSERT (3 points)", ok, q.engine._output_layer.featureCount())

r = psql("DELETE FROM listentest_pts WHERE id = 1;")
ok = wait_for(lambda: q.engine._output_layer.featureCount() == 2, timeout_s=8.0)
check("output picked up the database DELETE (2 points)", ok, q.engine._output_layer.featureCount())

plugin.panel.select_table_row_for_key(key)
QCoreApplication.processEvents()
plugin.panel.removeRequested.emit()
QCoreApplication.processEvents()
check("query removed", key not in plugin._queries)
check("removing the query closes its listener connection", wait_backends(base),
      listener_backends())

plugin.unload()
rw.ENABLE_POSTGRES_LISTEN = None
psql("DROP TABLE IF EXISTS listentest_pts CASCADE; DROP TABLE IF EXISTS listentest_zones CASCADE;")

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
print("RESULT: all checks passed")
