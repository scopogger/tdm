"""
Corrects a real over-correction from an earlier round: database-backed
layers no longer default to auto-update-off/periodic-only, and the
auto-update checkbox is no longer grayed out for them. See plugin.py's
module docstring for the full story -- the short version is that the
committed*/subsetStringChanged signals ReactiveWatcher connects to are
plain local Qt signals with nothing to do with the actual confirmed
freeze (QGIS #55707, specifically about setListening()/NOTIFY, already
separately gated off), so disabling them for database layers threw
away safe, working reactivity for no real safety benefit -- including
exactly the case that surfaced it: a filter change on a database layer
not being picked up instantly.

Runs against a REAL PostgreSQL/PostGIS connection, not a mock, since
the whole point is confirming this against an actual postgres
provider, not just the absence of a special-case in the code.
"""
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from _test_helpers import key_for_subject, wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


CONN = "dbname='qgis_test' host=localhost user='postgres' password='postgres'"

print("=" * 70)
print("0. Set up a real PostGIS table")
print("=" * 70)

setup_sql = """
DROP TABLE IF EXISTS reactivitytest_zones CASCADE;
DROP TABLE IF EXISTS reactivitytest_buildings CASCADE;
CREATE TABLE reactivitytest_zones (id serial PRIMARY KEY, geom geometry(Polygon, 3857));
INSERT INTO reactivitytest_zones (geom) VALUES
    (ST_GeomFromText('POLYGON((0 0,100 0,100 100,0 100,0 0))', 3857));
CREATE TABLE reactivitytest_buildings (
    id serial PRIMARY KEY, name text, category text, geom geometry(Point, 3857)
);
INSERT INTO reactivitytest_buildings (name, category, geom) VALUES
    ('b1', 'A', ST_GeomFromText('POINT(10 10)', 3857)),
    ('b2', 'B', ST_GeomFromText('POINT(20 20)', 3857)),
    ('b3', 'A', ST_GeomFromText('POINT(30 30)', 3857));
"""
result = subprocess.run(
    ["psql", "-h", "localhost", "-U", "postgres", "-d", "qgis_test", "-c", setup_sql],
    env={"PGPASSWORD": "postgres", "PATH": "/usr/bin"},
    capture_output=True, text=True,
)
check("PostGIS test tables created", result.returncode == 0, result.stderr)

iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

pg_zones = QgsVectorLayer(
    f"{CONN} sslmode=disable key='id' srid=3857 type=Polygon "
    'table="public"."reactivitytest_zones" (geom)',
    "pg_zones", "postgres",
)
pg_buildings = QgsVectorLayer(
    f"{CONN} sslmode=disable key='id' srid=3857 type=Point "
    'table="public"."reactivitytest_buildings" (geom)',
    "pg_buildings", "postgres",
)
check("pg_zones valid", pg_zones.isValid())
check("pg_buildings valid", pg_buildings.isValid())
project.addMapLayers([pg_zones, pg_buildings], False)

plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()

print()
print("=" * 70)
print("1. A query with a PostgreSQL subject+selection defaults EXACTLY like a local query")
print("=" * 70)

plugin.panel.subject_combo.setLayer(pg_buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(pg_zones)
plugin.panel.createRequested.emit()
key = key_for_subject(plugin, pg_buildings)
ok = wait_for(lambda: key in plugin._queries and plugin._queries[key].engine._task is None, 10.0)
check("query created and settled", ok)

q = plugin._queries[key]
check("auto_update defaults to True, same as a local-only query", q.auto_update is True, q.auto_update)
check("periodic_enabled defaults to False, same as a local-only query",
      q.periodic_enabled is False, q.periodic_enabled)
check("auto-update checkbox is NOT grayed out while this query is selected",
      plugin.panel.auto_update_check.isEnabled())
check("initial output has all 3 buildings (no filter yet)",
      q.engine._output_layer.featureCount() == 3, q.engine._output_layer.featureCount())

print()
print("=" * 70)
print("2. Changing the filter (Query Builder / subsetString) on a REAL postgres layer")
print("   triggers an INSTANT recalculation, not just eventually via a timer")
print("=" * 70)

pg_buildings.setSubsetString("category = 'A'")
ok = wait_for(lambda: q.engine._output_layer.featureCount() == 2, timeout_s=3.0)
check("output updated to 2 (category=A only) within a few seconds, not needing a 30s wait",
      ok, q.engine._output_layer.featureCount())

pg_buildings.setSubsetString("")
ok = wait_for(lambda: q.engine._output_layer.featureCount() == 3, timeout_s=3.0)
check("clearing the filter is also picked up instantly", ok, q.engine._output_layer.featureCount())

plugin.unload()

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
