"""
This round's fixes, tested directly:

1. The management table's output-name cell no longer sticks at "…" --
   it updates once the background computation that created it
   actually finishes, not just on some later unrelated refresh.
2. Opening a DIFFERENT project (not just reloading the same one, and
   not just what initGui() saw at plugin-load time) correctly
   restores and re-arms that project's own tagged queries.
3. Four distinct buttons replace the old single relabeled one --
   Create is disabled (not hidden) once an existing query is loaded,
   and "Новый запрос" gives an explicit way back to a blank draft.
4. A query's selection layer can never be set to its own output layer.
5. A fresh draft suggests an incrementing "Новый слой N" name.

Plus everything from the previous round (no auto-creation, remove via
button or via QGIS's own Layers panel, teardown on subject/selection
layer deletion, the management table itself) is re-verified here
too, since this is a substantial rewrite of both plugin.py and
query_panel.py.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from _test_helpers import wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


def settle(plugin, key, timeout_s=5.0):
    return wait_for(
        lambda: key in plugin._queries and plugin._queries[key].engine._task is None,
        timeout_s,
    )


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
zone.dataProvider().addFeatures([zf])

buildings = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "buildings", "memory")
bf = QgsFeature(buildings.fields())
bf.setGeometry(QgsGeometry.fromWkt("POINT(10 10)"))
bf.setAttribute("name", "b0")
buildings.dataProvider().addFeatures([bf])

roads = QgsVectorLayer("LineString?crs=EPSG:3857&field=name:string", "roads", "memory")
rf = QgsFeature(roads.fields())
rf.setGeometry(QgsGeometry.fromWkt("LINESTRING(5 5, 15 15)"))
rf.setAttribute("name", "r0")
roads.dataProvider().addFeatures([rf])

project.addMapLayers([zone, buildings, roads], False)
for lyr in (zone, buildings, roads):
    project.layerTreeRoot().addLayer(lyr)

print("=" * 70)
print("1. Enabling the plugin creates nothing; buttons start in the right state")
print("=" * 70)

layer_count_before = len(project.mapLayers())
plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()
QCoreApplication.processEvents()

check("no queries registered just from initGui()", len(plugin._queries) == 0)
check("no new layers were added", len(project.mapLayers()) == layer_count_before)
check("Create is enabled for the blank draft", plugin.panel.create_btn.isEnabled())
check("Recalculate is disabled with nothing loaded", not plugin.panel.recalculate_btn.isEnabled())
check("Remove is disabled with nothing loaded", not plugin.panel.remove_btn.isEnabled())
check("draft output name defaults to 'Новый слой 1'", plugin.panel.output_name() == "Новый слой 1",
      plugin.panel.output_name())

print()
print("=" * 70)
print("2. Creating a query updates the table correctly once it ACTUALLY finishes")
print("=" * 70)

plugin.panel.subject_combo.setLayer(buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)
plugin.panel.createRequested.emit()
key_a = buildings.id()

# Deliberately check the table BEFORE waiting for settle() -- this is
# exactly the window where the old bug showed a stuck "…".
QCoreApplication.processEvents()
check("Create became disabled immediately (registered, even before the async calc finishes)",
      not plugin.panel.create_btn.isEnabled())

ok = settle(plugin, key_a)
check("query A settled", ok)
check("table's output-layer cell shows the real name, not stuck on '…'",
      plugin.panel.query_table.item(0, 0).text() not in ("…", ""),
      plugin.panel.query_table.item(0, 0).text())
check("Recalculate now enabled", plugin.panel.recalculate_btn.isEnabled())
check("Remove now enabled", plugin.panel.remove_btn.isEnabled())

print()
print("=" * 70)
print("3. 'Новый запрос' explicitly clears the draft; Create stays disabled for an existing subject")
print("=" * 70)

# Still viewing query A (existing) -- Create must be OFF, matching the
# reported trap ("they can't create a new one because there's no
# Create button available" -- now it's visibly disabled instead).
check("Create disabled while an existing query (A) is loaded", not plugin.panel.create_btn.isEnabled())

plugin.panel.newQueryRequested.emit()
QCoreApplication.processEvents()
check("current key cleared after 'Новый запрос'", plugin._current_key is None)
check("Create re-enabled for the fresh draft", plugin.panel.create_btn.isEnabled())
check("Recalculate disabled again for the fresh draft", not plugin.panel.recalculate_btn.isEnabled())
check("Remove disabled again for the fresh draft", not plugin.panel.remove_btn.isEnabled())
check("suggested name increments to 'Новый слой 2'", plugin.panel.output_name() == "Новый слой 2",
      plugin.panel.output_name())
check("selection combo cleared", plugin.panel.selection_layer() is None)

print()
print("=" * 70)
print("4. A query's selection cannot be set to its own output layer")
print("=" * 70)

plugin._on_subject_changed(buildings)  # force the reload directly -- setLayer()
# would be a silent no-op here since the combo may already show
# buildings from section 2/3 (clear_draft() deliberately leaves the
# subject combo alone), and Qt widgets don't re-emit a change signal
# when set to their current value.
QCoreApplication.processEvents()
output_a = plugin._queries[key_a].engine._output_layer
excepted = [lyr.id() for lyr in plugin.panel.selection_combo.exceptedLayerList()]
check("query A's own output layer is proactively excluded from its selection combo",
      output_a.id() in excepted, excepted)

# Backstop: try setting it anyway, bypassing the combo's own filtering,
# and confirm the plugin's handler rejects it rather than accepting a
# self-referential selection layer.
plugin.panel.selectionLayerChanged.emit(output_a)
QCoreApplication.processEvents()
check("engine's selection layer was NOT changed to its own output",
      plugin._queries[key_a].engine.selection_layer.id() != output_a.id(),
      plugin._queries[key_a].engine.selection_layer.id())
check("status explains why", "нельзя выбрать" in plugin.panel.status_label.text(),
      plugin.panel.status_label.text())

print()
print("=" * 70)
print("5. Removing and reactive cleanup still work as before")
print("=" * 70)

output_a_id = output_a.id()
plugin.panel.removeRequested.emit()
QCoreApplication.processEvents()
check("query A removed", key_a not in plugin._queries)
check("output layer removed from project", project.mapLayer(output_a_id) is None)
check("Create re-enabled after removal", plugin.panel.create_btn.isEnabled())

plugin.panel.subject_combo.setLayer(roads)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)
plugin.panel.createRequested.emit()
key_b = roads.id()
ok = settle(plugin, key_b)
check("query B created", ok)
output_b_id = plugin._queries[key_b].engine._output_layer.id()
project.removeMapLayer(output_b_id)
QCoreApplication.processEvents()
check("query B cleaned up reactively after direct layer removal", key_b not in plugin._queries)

print()
print("=" * 70)
print("6. Opening a DIFFERENT project restores THAT project's queries")
print("=" * 70)

plugin.panel.subject_combo.setLayer(buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)
plugin.panel.createRequested.emit()
key_c = buildings.id()
ok = settle(plugin, key_c)
check("query C created in 'project A'", ok)

path_a = "/tmp/dsq_project_a.qgs"
project.write(path_a)

# Build and save a totally separate project B with its own layers and
# its own query, while plugin is still the same running instance.
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))
zone2 = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone2", "memory")
zf2 = QgsFeature(zone2.fields())
zf2.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,50 0,50 50,0 50,0 0))"))
zone2.dataProvider().addFeatures([zf2])
parcels2 = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "parcels2", "memory")
pf2 = QgsFeature(parcels2.fields())
pf2.setGeometry(QgsGeometry.fromWkt("POINT(5 5)"))
pf2.setAttribute("name", "p0")
parcels2.dataProvider().addFeatures([pf2])
project.addMapLayers([zone2, parcels2], False)
for lyr in (zone2, parcels2):
    project.layerTreeRoot().addLayer(lyr)

plugin.panel.subject_combo.setLayer(parcels2)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone2)
plugin.panel.createRequested.emit()
key_d = parcels2.id()
ok = settle(plugin, key_d)
check("query D created in 'project B'", ok)

path_b = "/tmp/dsq_project_b.qgs"
project.write(path_b)

print("  (re-opening project A while plugin stays loaded, simulating File > Open)")
project.read(path_a)  # fires layersWillBeRemoved for B's layers, then readProject
QCoreApplication.processEvents()

check("project B's query was torn down when its layers went away", key_d not in plugin._queries)
check("project A's query (C) is back, recognized from the reopened project",
      key_c in plugin._queries or buildings.id() in [k for k in plugin._queries], list(plugin._queries.keys()))
check("management table reflects project A's query, not project B's",
      plugin.panel.query_table.rowCount() == 1, plugin.panel.query_table.rowCount())

plugin.unload()

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
