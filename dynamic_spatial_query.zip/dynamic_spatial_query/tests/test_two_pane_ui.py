"""
This round's redesign, tested directly: the panel split into a
left side (always a blank draft, "Выполнить" creates) and a right
side (manage existing queries -- table, Удалить, the added Обновить,
and the two update-frequency controls, all acting on whichever row is
selected). No in-place editing of an existing query's layers/
predicates/name exists anymore -- delete and recreate instead.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from dynamic_spatial_query.query_panel import PREDICATE_UI_ORDER  # noqa: E402
from _test_helpers import key_for_subject, wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


def settle(plugin, key, timeout_s=5.0):
    return wait_for(
        lambda: key in plugin._queries and plugin._queries[key].engine._task is None,
        timeout_s,
    )


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
zone.dataProvider().addFeatures([zf])

buildings = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "buildings", "memory")
bf = QgsFeature(buildings.fields())
bf.setGeometry(QgsGeometry.fromWkt("POINT(10 10)"))
bf.setAttribute("name", "b0")
buildings.dataProvider().addFeatures([bf])

roads = QgsVectorLayer("LineString?crs=EPSG:3857&field=name:string", "roads", "memory")
rf = QgsFeature(roads.fields())
rf.setGeometry(QgsGeometry.fromWkt("LINESTRING(5 5, 15 15)"))
rf.setAttribute("name", "r0")
roads.dataProvider().addFeatures([rf])

project.addMapLayers([zone, buildings, roads], False)
for lyr in (zone, buildings, roads):
    project.layerTreeRoot().addLayer(lyr)

print("=" * 70)
print("1. Predicate checkbox order matches the requested layout")
print("=" * 70)

check("checkbox order is Intersects, Touches, Contains, Overlaps, Disjoint, Within, Equals, Crosses",
      PREDICATE_UI_ORDER == ["Intersects", "Touches", "Contains", "Overlaps",
                              "Disjoint", "Within", "Equals", "Crosses"],
      PREDICATE_UI_ORDER)

print()
print("=" * 70)
print("2. Enabling the plugin creates nothing; right-side controls start disabled")
print("=" * 70)

layer_count_before = len(project.mapLayers())
plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()
QCoreApplication.processEvents()

check("no queries registered from initGui()", len(plugin._queries) == 0)
check("no new layers added", len(project.mapLayers()) == layer_count_before)
check("draft output name is 'Новый слой 1'", plugin.panel.output_name() == "Новый слой 1",
      plugin.panel.output_name())
check("right side row controls start disabled",
      not plugin.panel.remove_btn.isEnabled() and not plugin.panel.refresh_btn.isEnabled()
      and not plugin.panel.auto_update_check.isEnabled())
check("right panel starts with nonzero width", plugin.panel.splitter.sizes()[1] > 0,
      plugin.panel.splitter.sizes())

print()
print("=" * 70)
print("3. Splitter handle's embedded button toggles the right side, remembering its width")
print("=" * 70)

handle = plugin.panel.splitter.handle(1)
check("handle has the embedded toggle button", hasattr(handle, "toggle_btn"))

from qgis.PyQt.QtCore import Qt as _QtCursor  # noqa: E402
check("toggle button shows a normal pointer, not the handle's resize cursor",
      handle.toggle_btn.cursor().shape() == _QtCursor.ArrowCursor,
      handle.toggle_btn.cursor().shape())
original_width = plugin.panel.splitter.sizes()[1]

handle.toggle_btn.click()
check("right panel collapsed to 0 after clicking the embedded button",
      plugin.panel.splitter.sizes()[1] == 0, plugin.panel.splitter.sizes())
check("button flipped to the 'expand' arrow", handle.toggle_btn.text() == "›", handle.toggle_btn.text())

handle.toggle_btn.click()
check("right panel restored to its ORIGINAL width, not some fixed default",
      plugin.panel.splitter.sizes()[1] == original_width, plugin.panel.splitter.sizes())
check("button flipped back to the 'collapse' arrow", handle.toggle_btn.text() == "‹", handle.toggle_btn.text())

print()
print("=" * 70)
print("4. Dragging the handle (simulated via splitterMoved) also updates the remembered width")
print("=" * 70)

real_sizes = plugin.panel.splitter.sizes
try:
    plugin.panel.splitter.sizes = lambda: [300, 250]  # a controlled, fake reading --
    # sidesteps real Qt layout resolution, which this test found isn't
    # fully reliable to predict in a headless, never-actually-shown
    # window (the left panel's real minimum width turned out to always
    # win regardless of what was requested, confirmed directly rather
    # than assumed after two different guessed numbers both failed)
    plugin.panel.splitter._on_splitter_moved(300, 1)
    check("remembered width updates from a genuine size change (simulated drag)",
          plugin.panel.splitter._last_right_width == 250, plugin.panel.splitter._last_right_width)

    plugin.panel.splitter.sizes = lambda: [550, 0]  # simulates dragging all the way to collapse
    plugin.panel.splitter._on_splitter_moved(550, 1)
    check("remembered width is NOT overwritten by a collapse-to-zero (stays 250, not 0)",
          plugin.panel.splitter._last_right_width == 250, plugin.panel.splitter._last_right_width)
    check("handle icon updates to the 'expand' arrow purely from the size change",
          handle.toggle_btn.text() == "›", handle.toggle_btn.text())
finally:
    plugin.panel.splitter.sizes = real_sizes

print()
print("=" * 70)
print("5. The embedded button restores whatever width was last remembered, via the real API")
print("=" * 70)

if plugin.panel.splitter.sizes()[1] != 0:
    handle.toggle_btn.click()  # ensure a known starting state: collapsed
    # (this click's own collapse branch records whatever the width was
    # at that moment into _last_right_width -- setting our target
    # value below, AFTER this, not before, is what matters here)
plugin.panel.splitter._last_right_width = 250
setSizes_calls = []
real_setSizes = plugin.panel.splitter.setSizes
plugin.panel.splitter.setSizes = lambda sizes: (setSizes_calls.append(sizes), real_setSizes(sizes))[-1]
try:
    setSizes_calls.clear()
    handle.toggle_btn.click()  # should ask to expand back to the remembered 250
finally:
    plugin.panel.splitter.setSizes = real_setSizes
# Checking the CALL, not the post-layout sizes() outcome: the left
# panel's real minimum content width (431px, confirmed directly)
# means Qt itself may clamp the actual result in a narrow/headless
# window regardless of what's requested -- that's correct Qt behavior
# to respect a real minimum, not something to work around, so what
# matters here is that the code asked for the right width.
check("clicking the button asks setSizes() for the remembered width",
      setSizes_calls and setSizes_calls[-1][1] == 250, setSizes_calls)

print()
print("=" * 70)
print("5b. The floating window's own lifecycle (replaces QDockWidget behavior)")
print("=" * 70)

from qgis.PyQt.QtCore import Qt as _Qt  # noqa: E402
check("panel is a plain window, not a dock widget", bool(plugin.panel.windowFlags() & _Qt.Window))
visibility_events = []
plugin.panel.windowVisibilityChanged.connect(lambda v: visibility_events.append(v))
plugin.panel.show()
check("windowVisibilityChanged fired True on show()", visibility_events == [True], visibility_events)
plugin.panel.hide()
check("windowVisibilityChanged fired False on hide()", visibility_events == [True, False], visibility_events)

plugin.panel.show()
plugin.panel.close()  # the window's own [x] -- should hide, not destroy
check("close() (the window's own X) hid the panel rather than destroying it",
      plugin.panel.isHidden() and plugin.panel is not None)

print()
print("=" * 70)
print("5c. A horizontal separator sits between the selection combo and the result-name field")
print("=" * 70)

from qgis.PyQt.QtWidgets import QFrame  # noqa: E402
left_widget = plugin.panel.splitter.widget(0)
frames = [w for w in left_widget.findChildren(QFrame) if w.frameShape() == QFrame.HLine]
check("a horizontal line separator exists in the left panel", len(frames) >= 1, len(frames))

print()
print("=" * 70)
print("4. Creating a query from the left side works and resets the draft")
print("=" * 70)

plugin.panel.subject_combo.setLayer(buildings)
plugin.panel.selection_combo.setLayer(zone)
plugin.panel.createRequested.emit()
key_a = key_for_subject(plugin, buildings)
ok = settle(plugin, key_a)
check("query A created", ok)
check("output found the 1 building", plugin._queries[key_a].engine._output_layer.featureCount() == 1)
check("left side reset to a fresh draft with the next suggested name",
      plugin.panel.output_name() == "Новый слой 2", plugin.panel.output_name())
check("left side's selection combo cleared", plugin.panel.selection_layer() is None)
check("table shows 1 row", plugin.panel.query_table.rowCount() == 1)

print()
print("=" * 70)
print("5. Creating a SECOND query with the SAME subject layer now succeeds")
print("=" * 70)

# This used to be refused -- that was never a deliberate rule, just a
# side effect of keying the registry by subject_layer_id. Queries are
# keyed by their own generated query_id now (see
# spatial_query_engine.py), so two independent queries sharing a
# subject layer against different selection layers is a real,
# supported case.
other_zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "other_zone", "memory")
ozf = QgsFeature(other_zone.fields())
ozf.setGeometry(QgsGeometry.fromWkt("POLYGON((5 5,20 5,20 20,5 20,5 5))"))
other_zone.dataProvider().addFeatures([ozf])
project.addMapLayers([other_zone], False)

before = set(plugin._queries.keys())
plugin.panel.subject_combo.setLayer(buildings)
plugin.panel.selection_combo.setLayer(other_zone)
plugin.panel.createRequested.emit()
ok = wait_for(lambda: len(plugin._queries) == 2 and all(
    plugin._queries[k].engine._task is None for k in plugin._queries), 5.0)
check("a second query was actually created (2 total now)", ok, len(plugin._queries))
new_keys = set(plugin._queries.keys()) - before
check("the second query got its OWN distinct key, not colliding with query A",
      len(new_keys) == 1 and key_a not in new_keys, new_keys)
key_a2 = next(iter(new_keys)) if new_keys else None
if key_a2 is not None:
    check("both queries share the same subject layer",
          plugin._queries[key_a2].engine.subject_layer.id() == plugin._queries[key_a].engine.subject_layer.id())
    check("but have different selection layers",
          plugin._queries[key_a2].engine.selection_layer.id() != plugin._queries[key_a].engine.selection_layer.id())
    output_a = plugin._queries[key_a].engine._output_layer
    output_a2 = plugin._queries[key_a2].engine._output_layer
    check("each got its own distinct output layer/table, no collision",
          output_a is not None and output_a2 is not None and output_a.id() != output_a2.id())
    # clean it up so it doesn't interfere with later sections that
    # assume "buildings" maps to exactly one query
    plugin._teardown_query(key_a2, delete_output_layer=True)
    plugin._refresh_query_table()

print()
print("=" * 70)
print("6. No predicates selected refuses creation, matching the earlier fix")
print("=" * 70)

count_before = len(plugin._queries)
plugin.panel.subject_combo.setLayer(roads)
plugin.panel.selection_combo.setLayer(zone)
for cb in plugin.panel.predicate_checks.values():
    cb.setChecked(False)
plugin.panel.createRequested.emit()
QCoreApplication.processEvents()
check("no query created with zero predicates", len(plugin._queries) == count_before, len(plugin._queries))
check("status explains why", "предикат" in plugin.panel.status_label.text())

print()
print("=" * 70)
print("7. Right side: selecting a row loads its update-frequency settings")
print("=" * 70)

plugin.panel.predicate_checks["Intersects"].setChecked(True)
plugin.panel.createRequested.emit()
key_b = key_for_subject(plugin, roads)
ok = settle(plugin, key_b)
check("query B created", ok)
check("table now shows 2 rows", plugin.panel.query_table.rowCount() == 2)

row_for_a = plugin.panel._row_keys.index(key_a)
plugin.panel.query_table.selectRow(row_for_a)
QCoreApplication.processEvents()
check("selecting a row enables the row controls", plugin.panel.remove_btn.isEnabled())
check("auto-update reflects query A's actual (default) state",
      plugin.panel.auto_update_check.isChecked() == plugin._queries[key_a].auto_update)

print()
print("=" * 70)
print("8. Right side: toggling auto-update and periodic refresh act on the selected row")
print("=" * 70)

plugin.panel.auto_update_check.setChecked(False)
check("query A's auto_update turned off", plugin._queries[key_a].auto_update is False)
check("query A's watcher stopped watching", plugin._queries[key_a].watcher._connections == [])
check("table reflects the paused status", "Приостановлен" in plugin.panel.query_table.item(row_for_a, 3).text())

plugin.panel.periodic_check.setChecked(True)
plugin.panel.periodic_spin.setValue(45)
check("query A's periodic refresh enabled at 45s",
      plugin._queries[key_a].periodic_enabled and plugin._queries[key_a].periodic_seconds == 45)

print()
print("=" * 70)
print("9. Right side: Обновить manually recalculates the selected query")
print("=" * 70)

buildings.dataProvider().addFeatures([  # bypassing the (paused) watcher deliberately
    QgsFeature(buildings.fields())
])
plugin.panel.refreshRequested.emit()
ok = wait_for(lambda: plugin._queries[key_a].engine._task is None, 5.0)
check("manual refresh completes without error", ok)

print()
print("=" * 70)
print("10. Right side: Удалить acts on the selected row only")
print("=" * 70)

output_a_id = plugin._queries[key_a].engine._output_layer.id()
plugin.panel.removeRequested.emit()
QCoreApplication.processEvents()
check("query A removed", key_a not in plugin._queries)
check("query A's output layer removed from the project", project.mapLayer(output_a_id) is None)
check("query B untouched", key_b in plugin._queries)
check("row controls disabled again after removal", not plugin.panel.remove_btn.isEnabled())

print()
print("=" * 70)
print("11. Reactive cleanup: deleting the selected query's output externally deselects it")
print("=" * 70)

row_for_b = plugin.panel._row_keys.index(key_b)
plugin.panel.query_table.selectRow(row_for_b)
QCoreApplication.processEvents()
check("query B is now selected", plugin._selected_key == key_b)

output_b_id = plugin._queries[key_b].engine._output_layer.id()
project.removeMapLayer(output_b_id)
QCoreApplication.processEvents()
check("query B cleaned up reactively", key_b not in plugin._queries)
check("selection cleared since the selected query is gone", plugin._selected_key is None)
check("row controls disabled", not plugin.panel.remove_btn.isEnabled())

plugin.unload()

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
