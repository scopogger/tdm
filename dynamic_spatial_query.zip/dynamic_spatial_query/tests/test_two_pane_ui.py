"""
This round's redesign, tested directly: the panel split into a
left side (always a blank draft, "Выполнить" creates) and a right
side (manage existing queries -- table, Удалить, the added Обновить,
and the two update-frequency controls, all acting on whichever row is
selected). No in-place editing of an existing query's layers/
predicates/name exists anymore -- delete and recreate instead.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from dynamic_spatial_query.query_panel import PREDICATE_UI_ORDER  # noqa: E402
from _test_helpers import wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


def settle(plugin, key, timeout_s=5.0):
    return wait_for(
        lambda: key in plugin._queries and plugin._queries[key].engine._task is None,
        timeout_s,
    )


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
zone.dataProvider().addFeatures([zf])

buildings = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "buildings", "memory")
bf = QgsFeature(buildings.fields())
bf.setGeometry(QgsGeometry.fromWkt("POINT(10 10)"))
bf.setAttribute("name", "b0")
buildings.dataProvider().addFeatures([bf])

roads = QgsVectorLayer("LineString?crs=EPSG:3857&field=name:string", "roads", "memory")
rf = QgsFeature(roads.fields())
rf.setGeometry(QgsGeometry.fromWkt("LINESTRING(5 5, 15 15)"))
rf.setAttribute("name", "r0")
roads.dataProvider().addFeatures([rf])

project.addMapLayers([zone, buildings, roads], False)
for lyr in (zone, buildings, roads):
    project.layerTreeRoot().addLayer(lyr)

print("=" * 70)
print("1. Predicate checkbox order matches the requested layout")
print("=" * 70)

check("checkbox order is Intersects, Touches, Contains, Overlaps, Disjoint, Within, Equals, Crosses",
      PREDICATE_UI_ORDER == ["Intersects", "Touches", "Contains", "Overlaps",
                              "Disjoint", "Within", "Equals", "Crosses"],
      PREDICATE_UI_ORDER)

print()
print("=" * 70)
print("2. Enabling the plugin creates nothing; right-side controls start disabled")
print("=" * 70)

layer_count_before = len(project.mapLayers())
plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()
QCoreApplication.processEvents()

check("no queries registered from initGui()", len(plugin._queries) == 0)
check("no new layers added", len(project.mapLayers()) == layer_count_before)
check("draft output name is 'Новый слой 1'", plugin.panel.output_name() == "Новый слой 1",
      plugin.panel.output_name())
check("right side row controls start disabled",
      not plugin.panel.remove_btn.isEnabled() and not plugin.panel.refresh_btn.isEnabled()
      and not plugin.panel.auto_update_check.isEnabled())
check("right panel starts visible", not plugin.panel.right_panel.isHidden())

print()
print("=" * 70)
print("3. Toggle button shows/hides the right panel")
print("=" * 70)

plugin.panel._toggle_right_panel()
check("right panel hidden after toggling", plugin.panel.right_panel.isHidden())
check("button text flipped to the 'expand' arrow", plugin.panel.toggle_right_btn.text() == "›",
      plugin.panel.toggle_right_btn.text())
plugin.panel._toggle_right_panel()
check("right panel visible again", not plugin.panel.right_panel.isHidden())

print()
print("=" * 70)
print("4. Creating a query from the left side works and resets the draft")
print("=" * 70)

plugin.panel.subject_combo.setLayer(buildings)
plugin.panel.selection_combo.setLayer(zone)
plugin.panel.createRequested.emit()
key_a = buildings.id()
ok = settle(plugin, key_a)
check("query A created", ok)
check("output found the 1 building", plugin._queries[key_a].engine._output_layer.featureCount() == 1)
check("left side reset to a fresh draft with the next suggested name",
      plugin.panel.output_name() == "Новый слой 2", plugin.panel.output_name())
check("left side's selection combo cleared", plugin.panel.selection_layer() is None)
check("table shows 1 row", plugin.panel.query_table.rowCount() == 1)

print()
print("=" * 70)
print("5. Creating a second query with the SAME subject layer is refused")
print("=" * 70)

plugin.panel.subject_combo.setLayer(buildings)
plugin.panel.selection_combo.setLayer(zone)
plugin.panel.createRequested.emit()
QCoreApplication.processEvents()
check("still only 1 query -- duplicate subject refused", len(plugin._queries) == 1)
check("status explains why", "уже используется" in plugin.panel.status_label.text(),
      plugin.panel.status_label.text())

print()
print("=" * 70)
print("6. No predicates selected refuses creation, matching the earlier fix")
print("=" * 70)

plugin.panel.subject_combo.setLayer(roads)
plugin.panel.selection_combo.setLayer(zone)
for cb in plugin.panel.predicate_checks.values():
    cb.setChecked(False)
plugin.panel.createRequested.emit()
QCoreApplication.processEvents()
check("no query created with zero predicates", roads.id() not in plugin._queries)
check("status explains why", "предикат" in plugin.panel.status_label.text())

print()
print("=" * 70)
print("7. Right side: selecting a row loads its update-frequency settings")
print("=" * 70)

plugin.panel.predicate_checks["Intersects"].setChecked(True)
plugin.panel.createRequested.emit()
key_b = roads.id()
ok = settle(plugin, key_b)
check("query B created", ok)
check("table now shows 2 rows", plugin.panel.query_table.rowCount() == 2)

row_for_a = plugin.panel._row_keys.index(key_a)
plugin.panel.query_table.selectRow(row_for_a)
QCoreApplication.processEvents()
check("selecting a row enables the row controls", plugin.panel.remove_btn.isEnabled())
check("auto-update reflects query A's actual (default) state",
      plugin.panel.auto_update_check.isChecked() == plugin._queries[key_a].auto_update)

print()
print("=" * 70)
print("8. Right side: toggling auto-update and periodic refresh act on the selected row")
print("=" * 70)

plugin.panel.auto_update_check.setChecked(False)
check("query A's auto_update turned off", plugin._queries[key_a].auto_update is False)
check("query A's watcher stopped watching", plugin._queries[key_a].watcher._connections == [])
check("table reflects the paused status", "Приостановлен" in plugin.panel.query_table.item(row_for_a, 3).text())

plugin.panel.periodic_check.setChecked(True)
plugin.panel.periodic_spin.setValue(45)
check("query A's periodic refresh enabled at 45s",
      plugin._queries[key_a].periodic_enabled and plugin._queries[key_a].periodic_seconds == 45)

print()
print("=" * 70)
print("9. Right side: Обновить manually recalculates the selected query")
print("=" * 70)

buildings.dataProvider().addFeatures([  # bypassing the (paused) watcher deliberately
    QgsFeature(buildings.fields())
])
plugin.panel.refreshRequested.emit()
ok = wait_for(lambda: plugin._queries[key_a].engine._task is None, 5.0)
check("manual refresh completes without error", ok)

print()
print("=" * 70)
print("10. Right side: Удалить acts on the selected row only")
print("=" * 70)

output_a_id = plugin._queries[key_a].engine._output_layer.id()
plugin.panel.removeRequested.emit()
QCoreApplication.processEvents()
check("query A removed", key_a not in plugin._queries)
check("query A's output layer removed from the project", project.mapLayer(output_a_id) is None)
check("query B untouched", key_b in plugin._queries)
check("row controls disabled again after removal", not plugin.panel.remove_btn.isEnabled())

print()
print("=" * 70)
print("11. Reactive cleanup: deleting the selected query's output externally deselects it")
print("=" * 70)

row_for_b = plugin.panel._row_keys.index(key_b)
plugin.panel.query_table.selectRow(row_for_b)
QCoreApplication.processEvents()
check("query B is now selected", plugin._selected_key == key_b)

output_b_id = plugin._queries[key_b].engine._output_layer.id()
project.removeMapLayer(output_b_id)
QCoreApplication.processEvents()
check("query B cleaned up reactively", key_b not in plugin._queries)
check("selection cleared since the selected query is gone", plugin._selected_key is None)
check("row controls disabled", not plugin.panel.remove_btn.isEnabled())

plugin.unload()

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
