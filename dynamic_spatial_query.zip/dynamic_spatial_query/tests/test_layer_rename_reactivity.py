"""
Renaming a layer directly in QGIS's own Layers panel (which calls
QgsMapLayer.setName() under the hood, exercised here the same way)
must update the management table's Целевой слой/Слой выборки/
Слой-результат columns to the new name -- not just leave whatever
name was captured at query-creation time.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from _test_helpers import wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
zone.dataProvider().addFeatures([zf])

buildings = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "buildings", "memory")
bf = QgsFeature(buildings.fields())
bf.setGeometry(QgsGeometry.fromWkt("POINT(10 10)"))
bf.setAttribute("name", "b0")
buildings.dataProvider().addFeatures([bf])

project.addMapLayers([zone, buildings], False)
for lyr in (zone, buildings):
    project.layerTreeRoot().addLayer(lyr)

plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()
plugin.panel.subject_combo.setLayer(buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)
plugin.panel.createRequested.emit()
key = buildings.id()
ok = wait_for(lambda: key in plugin._queries and plugin._queries[key].engine._task is None, 5.0)
check("query created", ok)

print("=" * 70)
print("1. Renaming the SUBJECT layer updates the table")
print("=" * 70)

buildings.setName("Buildings 2024")
QCoreApplication.processEvents()
row = plugin.panel._row_keys.index(key)
check("table's subject column reflects the rename",
      plugin.panel.query_table.item(row, 1).text() == "Buildings 2024",
      plugin.panel.query_table.item(row, 1).text())

print()
print("=" * 70)
print("2. Renaming the SELECTION layer updates the table")
print("=" * 70)

zone.setName("Zone A")
QCoreApplication.processEvents()
check("table's selection column reflects the rename",
      plugin.panel.query_table.item(row, 2).text() == "Zone A",
      plugin.panel.query_table.item(row, 2).text())

print()
print("=" * 70)
print("3. Renaming the OUTPUT layer updates the table")
print("=" * 70)

output_layer = plugin._queries[key].engine._output_layer
output_layer.setName("My Custom Result")
QCoreApplication.processEvents()
check("table's output column reflects the rename",
      plugin.panel.query_table.item(row, 0).text() == "My Custom Result",
      plugin.panel.query_table.item(row, 0).text())

print()
print("=" * 70)
print("4. After a rename, tearing the query down cleanly disconnects (no stale firing)")
print("=" * 70)

plugin._on_query_row_selected(key)
plugin._on_remove_requested()
QCoreApplication.processEvents()
check("query removed", key not in plugin._queries)
# renaming a layer that's no longer part of any query must not error
# even though it's still a live QgsVectorLayer object
zone.setName("Zone A Renamed Again")
QCoreApplication.processEvents()
check("renaming an unrelated layer after teardown doesn't error", True)

plugin.unload()

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
