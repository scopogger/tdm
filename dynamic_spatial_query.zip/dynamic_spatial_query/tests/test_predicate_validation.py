"""
Two things from this round not covered by the workflow test:

1. The real bug: set_predicates([]) used to silently substitute a
   default predicate, so unchecking every predicate checkbox had no
   visible effect at all -- no error, no refusal, just quietly kept
   computing as if nothing had changed. QGIS's own Extract by
   Location refuses to run with no predicate selected; this plugin
   now does too, and -- more specifically than just "recalculate()
   returns an error" -- creation itself is refused up front, so an
   incomplete query is never registered in the first place.
2. Predicate display labels match the user's own copy of QGIS's
   actual "Извлечь по расположению" dialog text exactly, not an
   approximation.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from dynamic_spatial_query.query_panel import PREDICATE_LABELS_RU  # noqa: E402
from dynamic_spatial_query.spatial_query_engine import SpatialQueryEngine  # noqa: E402
from _test_helpers import run_and_wait  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
zone.dataProvider().addFeatures([zf])

buildings = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "buildings", "memory")
bf = QgsFeature(buildings.fields())
bf.setGeometry(QgsGeometry.fromWkt("POINT(10 10)"))
bf.setAttribute("name", "b0")
buildings.dataProvider().addFeatures([bf])

project.addMapLayers([zone, buildings], False)
for lyr in (zone, buildings):
    project.layerTreeRoot().addLayer(lyr)

print("=" * 70)
print("1. Predicate labels match the user's reference exactly")
print("=" * 70)

expected = {
    "Intersects": "Пересекает",
    "Within": "Находится внутри",
    "Contains": "Содержит",
    "Overlaps": "Накладывается",
    "Touches": "Касается",
    "Equals": "Совпадает",
    "Crosses": "Пересекает (линейно)",
    "Disjoint": "Не пересекает",
}
for key, label in expected.items():
    check(f"{key} -> {label!r}", PREDICATE_LABELS_RU.get(key) == label, PREDICATE_LABELS_RU.get(key))

print()
print("=" * 70)
print("2. Engine-level: set_predicates([]) actually empties it, no silent fallback")
print("=" * 70)

engine = SpatialQueryEngine(iface)
engine.set_subject_layer(buildings)
engine.set_selection_layer(zone)
engine.set_predicates([])
check("predicates list is genuinely empty, not silently defaulted", engine.predicates == [],
      engine.predicates)

count, error = run_and_wait(engine)
check("recalculate() refuses with a clear error", error is not None and "предикат" in error, error)
check("no output layer got created for the invalid attempt", engine._output_layer is None)

print()
print("=" * 70)
print("3. Panel-level: clicking Создать with no predicates checked creates nothing")
print("=" * 70)

plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()
plugin.panel.subject_combo.setLayer(buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)

for cb in plugin.panel.predicate_checks.values():
    cb.setChecked(False)
check("panel now reports zero selected predicates", plugin.panel.selected_predicates() == [])

plugin.panel.createRequested.emit()
QCoreApplication.processEvents()

check("no query was registered", len(plugin._queries) == 0, len(plugin._queries))
check("status explains why", "предикат" in plugin.panel.status_label.text(),
      plugin.panel.status_label.text())
check("management table stayed empty", plugin.panel.query_table.rowCount() == 0)
check("Create is still enabled (nothing broken, can retry)", plugin.panel.create_btn.isEnabled())

print()
print("=" * 70)
print("4. Checking a predicate and creating now works normally")
print("=" * 70)

plugin.panel.predicate_checks["Intersects"].setChecked(True)
plugin.panel.createRequested.emit()
key = buildings.id()

from _test_helpers import wait_for  # noqa: E402
ok = wait_for(lambda: key in plugin._queries and plugin._queries[key].engine._task is None, 5.0)
check("query created successfully once a predicate is checked", ok)

plugin.unload()

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
