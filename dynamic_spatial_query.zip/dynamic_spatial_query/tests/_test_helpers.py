"""
Shared helpers for the test suite. recalculate() runs on a background
QgsTask, so tests need to pump the Qt event loop until the result
actually arrives instead of reading it back immediately.
"""
import time

from qgis.PyQt.QtCore import QCoreApplication


def wait_for(predicate, timeout_s=5.0):
    deadline = time.time() + timeout_s
    while time.time() < deadline and not predicate():
        QCoreApplication.processEvents()
        time.sleep(0.02)
    return predicate()


def run_and_wait(engine, timeout_s=5.0):
    result = {}
    engine.recalculate(on_done=lambda c, e: result.update(count=c, error=e))
    ok = wait_for(lambda: "count" in result, timeout_s)
    if not ok:
        return 0, "timed out waiting for recalculate() to finish"
    return result["count"], result["error"]
