"""
Engine-level tests. spatial_query_engine.py's core logic
(_compute_matches, predicate math) is unchanged from before this
turn's UI/workflow changes -- this mainly re-confirms it still works
correctly, since plugin.py and query_panel.py were rewritten and
could plausibly have broken something in how they drive the engine.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
)

from dynamic_spatial_query.spatial_query_engine import SpatialQueryEngine  # noqa: E402
from _test_helpers import run_and_wait  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

zones = QgsVectorLayer("Polygon?crs=EPSG:3857&field=zone_name:string", "zones", "memory")
z1 = QgsFeature(zones.fields())
z1.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
z1.setAttribute("zone_name", "Z1")
zones.dataProvider().addFeatures([z1])

parcels = QgsVectorLayer(
    "Polygon?crs=EPSG:3857&field=parcel_name:string&field=notes:string", "parcels", "memory"
)


def add_parcel(name, wkt, notes=""):
    f = QgsFeature(parcels.fields())
    f.setGeometry(QgsGeometry.fromWkt(wkt))
    f.setAttribute("parcel_name", name)
    f.setAttribute("notes", notes)
    parcels.dataProvider().addFeatures([f])


add_parcel("A_within", "POLYGON((30 30,40 30,40 40,30 40,30 30))")
add_parcel("B_contains", "POLYGON((-10 -10,110 -10,110 110,-10 110,-10 -10))")
add_parcel("C_overlaps", "POLYGON((50 50,150 50,150 150,50 150,50 50))")
add_parcel("D_touches", "POLYGON((100 20,110 20,110 30,100 30,100 20))")
add_parcel("E_equals", "POLYGON((0 0,100 0,100 100,0 100,0 0))")
add_parcel("F_disjoint", "POLYGON((500 500,510 500,510 510,500 510,500 500))")

for lyr in (zones, parcels):
    lyr.updateExtents()
project.addMapLayers([zones, parcels], False)
project.layerTreeRoot().addLayer(zones)
project.layerTreeRoot().addLayer(parcels)

print("=" * 70)
print("PREDICATE CORRECTNESS")
print("=" * 70)

engine = SpatialQueryEngine(iface)
engine.set_subject_layer(parcels)
engine.set_selection_layer(zones)


def run(predicates):
    engine.set_predicates(predicates)
    count, error = run_and_wait(engine)
    if error:
        print(f"    (unexpected error) {error}")
    out = engine._output_layer
    return sorted(f["parcel_name"] for f in out.getFeatures()) if out else []


check("Intersects matches everything but F", run(["Intersects"]) ==
      ["A_within", "B_contains", "C_overlaps", "D_touches", "E_equals"])
check("Disjoint matches only F", run(["Disjoint"]) == ["F_disjoint"])
check("Overlaps matches only C", run(["Overlaps"]) == ["C_overlaps"])
check("Touches matches only D", run(["Touches"]) == ["D_touches"])
check("Within includes A", "A_within" in run(["Within"]))
check("Contains includes B", "B_contains" in run(["Contains"]))
check("Equals matches only E", run(["Equals"]) == ["E_equals"])

print()
print("=" * 70)
print("ATTRIBUTE PRESERVATION")
print("=" * 70)

run(["Intersects"])
out = engine._output_layer
a_feat = next(f for f in out.getFeatures() if f["parcel_name"] == "A_within")
check("original attributes preserved on output", "notes" in [f.name() for f in out.fields()])
check("output layer group is in Russian", engine.output_group_name == "Результаты динамических запросов")

print()
print("=" * 70)
print("SELF-COMPARISON")
print("=" * 70)

topo = QgsVectorLayer("Polygon?crs=EPSG:3857&field=name:string", "topo", "memory")
def add_topo(name, wkt):
    f = QgsFeature(topo.fields())
    f.setGeometry(QgsGeometry.fromWkt(wkt))
    f.setAttribute("name", name)
    topo.dataProvider().addFeatures([f])

add_topo("solo", "POLYGON((300 300,310 300,310 310,300 310,300 300))")
add_topo("pair_a", "POLYGON((0 0,10 0,10 10,0 10,0 0))")
add_topo("pair_b", "POLYGON((10 0,20 0,20 10,10 10,10 0))")
project.addMapLayers([topo], False)

engine3 = SpatialQueryEngine(iface)
engine3.set_subject_layer(topo)
engine3.set_selection_layer(topo)
engine3.set_predicates(["Touches"])
run_and_wait(engine3)
names3 = sorted(f["name"] for f in engine3._output_layer.getFeatures())
check("self-comparison excludes solo, includes the real pair", names3 == ["pair_a", "pair_b"])

print()
print("=" * 70)
print("SUBJECT LAYER SWAP")
print("=" * 70)

points = QgsVectorLayer("Point?crs=EPSG:3857&field=label:string", "points", "memory")
pf = QgsFeature(points.fields())
pf.setGeometry(QgsGeometry.fromWkt("POINT(50 50)"))
pf.setAttribute("label", "p1")
points.dataProvider().addFeatures([pf])
project.addMapLayers([points], False)

engine.set_subject_layer(points)
engine.set_selection_layer(zones)
engine.set_predicates(["Intersects"])
run_and_wait(engine)
check("output layer rebuilt as Point after subject swap",
      engine._output_layer.geometryType() == QgsWkbTypes.PointGeometry)

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
