"""
Two file-organization improvements, tested directly:

1. Each query's dedicated .gpkg file lives in a subfolder
   (dynamic_spatial_query_outputs/ next to the project) instead of
   loose alongside the user's other project files.
2. Removing a query (via the panel's Удалить, or reactively when its
   output layer is deleted externally) cleans up that query's now-
   unused file, so files don't accumulate unboundedly across
   create/delete cycles -- only currently-active queries' files
   should exist on disk.
"""
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from _test_helpers import wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


PROJECT_DIR = "/tmp/dsq_file_org_test_project_dir"
os.makedirs(PROJECT_DIR, exist_ok=True)

iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))
project.write(os.path.join(PROJECT_DIR, "test.qgs"))  # gives the project an absolutePath()

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
zone.dataProvider().addFeatures([zf])

buildings = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "buildings", "memory")
bf = QgsFeature(buildings.fields())
bf.setGeometry(QgsGeometry.fromWkt("POINT(10 10)"))
bf.setAttribute("name", "b0")
buildings.dataProvider().addFeatures([bf])

project.addMapLayers([zone, buildings], False)
for lyr in (zone, buildings):
    project.layerTreeRoot().addLayer(lyr)

print("=" * 70)
print("1. A created query's file lives in the dedicated subfolder")
print("=" * 70)

plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()
plugin.panel.subject_combo.setLayer(buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)
plugin.panel.createRequested.emit()
ok = wait_for(lambda: len(plugin._queries) == 1 and
              next(iter(plugin._queries.values())).engine._task is None, 5.0)
check("query created", ok)

key = next(iter(plugin._queries.keys()))
file_path = plugin._queries[key].engine.output_gpkg_file_path()
check("file path was resolved", file_path is not None, file_path)
expected_dir = os.path.join(PROJECT_DIR, "dynamic_spatial_query_outputs")
check("file lives in the dedicated subfolder, not loose in the project directory",
      os.path.dirname(file_path) == expected_dir, file_path)
check("the file actually exists on disk", os.path.exists(file_path), file_path)

print()
print("=" * 70)
print("2. Removing the query cleans up its file")
print("=" * 70)

plugin._on_query_row_selected(key)
plugin._on_remove_requested()
QCoreApplication.processEvents()
check("query removed from the registry", key not in plugin._queries)

# cleanup is deferred (500ms) -- wait for it rather than checking immediately
ok = wait_for(lambda: not os.path.exists(file_path), timeout_s=3.0)
check("the file was deleted after removal", ok, file_path)

print()
print("=" * 70)
print("3. Two queries get two separate files, both cleaned up independently")
print("=" * 70)

plugin.panel.subject_combo.setLayer(buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)
plugin.panel.createRequested.emit()
ok = wait_for(lambda: len(plugin._queries) == 1, 5.0)
key_a = next(iter(plugin._queries.keys()))
ok_a = wait_for(lambda: plugin._queries[key_a].engine._task is None, 5.0)
file_a = plugin._queries[key_a].engine.output_gpkg_file_path()

plugin.panel.subject_combo.setLayer(buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)
plugin.panel.createRequested.emit()
ok = wait_for(lambda: len(plugin._queries) == 2, 5.0)
key_b = next(iter(set(plugin._queries.keys()) - {key_a}))
ok_b = wait_for(lambda: plugin._queries[key_b].engine._task is None, 5.0)
file_b = plugin._queries[key_b].engine.output_gpkg_file_path()

check("both settled", ok_a and ok_b)
check("two distinct files exist", file_a != file_b and os.path.exists(file_a) and os.path.exists(file_b))

plugin._on_query_row_selected(key_a)
plugin._on_remove_requested()
QCoreApplication.processEvents()
ok = wait_for(lambda: not os.path.exists(file_a), timeout_s=3.0)
check("removing query A deletes only A's file", ok)
check("query B's file is untouched", os.path.exists(file_b), file_b)

plugin.unload()

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
