"""
Auto-update/periodic settings don't persist across a reload (they
always reset to defaults) -- confirms the database-aware default from
test_database_layer_defaults.py applies again correctly on
restoration, not just at first creation, and that the periodic timer
is actually running afterward (not just the flag set).
"""
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from _test_helpers import wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


CONN = "dbname='qgis_test' host=localhost user='postgres' password='postgres'"

setup_sql = """
DROP TABLE IF EXISTS restoretest_zones CASCADE;
DROP TABLE IF EXISTS restoretest_buildings CASCADE;
CREATE TABLE restoretest_zones (id serial PRIMARY KEY, geom geometry(Polygon, 3857));
INSERT INTO restoretest_zones (geom) VALUES
    (ST_GeomFromText('POLYGON((0 0,100 0,100 100,0 100,0 0))', 3857));
CREATE TABLE restoretest_buildings (id serial PRIMARY KEY, name text, geom geometry(Point, 3857));
INSERT INTO restoretest_buildings (name, geom) VALUES ('b0', ST_GeomFromText('POINT(10 10)', 3857));
"""
result = subprocess.run(
    ["psql", "-h", "localhost", "-U", "postgres", "-d", "qgis_test", "-c", setup_sql],
    env={"PGPASSWORD": "postgres", "PATH": "/usr/bin"},
    capture_output=True, text=True,
)
check("PostGIS test tables created", result.returncode == 0, result.stderr)

iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

pg_zones = QgsVectorLayer(
    f"{CONN} sslmode=disable key='id' srid=3857 type=Polygon table=\"public\".\"restoretest_zones\" (geom)",
    "pg_zones", "postgres",
)
pg_buildings = QgsVectorLayer(
    f"{CONN} sslmode=disable key='id' srid=3857 type=Point table=\"public\".\"restoretest_buildings\" (geom)",
    "pg_buildings", "postgres",
)
check("pg_zones valid", pg_zones.isValid())
check("pg_buildings valid", pg_buildings.isValid())
project.addMapLayers([pg_zones, pg_buildings], False)

print("=" * 70)
print("1. Create a database-backed query and save the project")
print("=" * 70)

plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()
plugin.panel.subject_combo.setLayer(pg_buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(pg_zones)
plugin.panel.createRequested.emit()
ok = wait_for(lambda: len(plugin._queries) == 1, 10.0)
check("query created", ok)
key = next(iter(plugin._queries.keys()))
ok = wait_for(lambda: plugin._queries[key].engine._task is None, 10.0)
check("settled", ok)

out_name = plugin._queries[key].engine._output_layer.name()
save_path = "/tmp/dsq_db_default_restore_test.qgs"
project.write(save_path)
plugin.unload()
project.clear()
project.read(save_path)

print()
print("=" * 70)
print("2. Reloading re-applies the database default, not the plain _LiveQuery default")
print("=" * 70)

reloaded_buildings = next(lyr for lyr in project.mapLayers().values() if lyr.name() == "pg_buildings")
reloaded_out = next(lyr for lyr in project.mapLayers().values() if lyr.name() == out_name)
check("output layer survived reload with its data", reloaded_out.featureCount() == 1)

plugin2 = DynamicSpatialQueryPlugin(iface)
plugin2.initGui()
QCoreApplication.processEvents()

check("query restored", len(plugin2._queries) == 1, len(plugin2._queries))
key2 = next(iter(plugin2._queries.keys()))
q2 = plugin2._queries[key2]
check("restored query got the DATABASE default (auto_update False), not the plain default (True)",
      q2.auto_update is False, q2.auto_update)
check("restored query's periodic refresh is enabled", q2.periodic_enabled is True)
check("restored query's periodic timer is actually running (not just the flag)",
      q2.watcher.periodic_refresh_timer.isActive())

plugin2.unload()

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
