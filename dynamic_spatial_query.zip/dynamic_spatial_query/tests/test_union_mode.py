"""
The «Объединение» (union) query type, end to end through the real
panel, modeled on section I of the tester's procedure: four polygon
layers named ООПТ / ТТП / ВОЗ / ИКН, GeoPackage-backed like theirs (so
every input has a "fid" field), one of them containing an invalid
(self-intersecting) polygon.

1. The union tab lists point, line and polygon layers; fewer than two
   ticked, or mixed geometry types, is refused.
2. The result matches QGIS's own native:union run directly on the
   same layers in the same order -- same pieces, same areas, same
   attributes (source "fid" stored as fid_1) -- and the invalid
   polygon is skipped and reported.
3. Live: an edit and a filter change on inputs update the result.
4. Chaining: the union's output used as the selection layer of an
   extract query -- a new zone polygon makes a previously-outside
   point appear in the extract result, through both queries.
5. A field added to an input shows up in the result.
6. Renaming an input updates the table; save, close and reopen the
   project restores the union query, which keeps updating.
7. A PostgreSQL input works (background-thread safety), bounded wait.
8. Removing an input layer tears the query down; "Удалить" removes
   the output layer and its file.
"""
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsApplication,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransformContext,
    QgsFeature,
    QgsFeatureRequest,
    QgsField,
    QgsGeometry,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
)
from qgis.PyQt.QtCore import QVariant  # noqa: E402

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from dynamic_spatial_query.query_panel import MODE_EXTRACT, MODE_UNION  # noqa: E402
from dynamic_spatial_query.union_engine import ensure_union_algorithm  # noqa: E402
from _test_helpers import wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


WORKDIR = tempfile.mkdtemp(prefix="dsq_union_")


def make_gpkg_layer(name, geometry_type, rows):
    """rows: list of (wkt, name_value). Written to a real GeoPackage,
    so the layer has a "fid" field like the tester's layers."""
    memory = QgsVectorLayer(f"{geometry_type}?crs=EPSG:3857&field=name:string", name, "memory")
    feats = []
    for wkt, value in rows:
        f = QgsFeature(memory.fields())
        f.setGeometry(QgsGeometry.fromWkt(wkt))
        f.setAttribute("name", value)
        feats.append(f)
    memory.dataProvider().addFeatures(feats)
    path = os.path.join(WORKDIR, f"{name}.gpkg")
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = name
    QgsVectorFileWriter.writeAsVectorFormatV3(memory, path, QgsCoordinateTransformContext(), options)
    layer = QgsVectorLayer(f"{path}|layername={name}", name, "ogr")
    assert layer.isValid(), path
    return layer


def sq(x0, y0, x1, y1):
    return f"POLYGON(({x0} {y0},{x1} {y0},{x1} {y1},{x0} {y1},{x0} {y0}))"


def union_query(plugin):
    keys = [k for k, q in plugin._queries.items() if q.engine.QUERY_TYPE == "union"]
    return (keys[0], plugin._queries[keys[0]]) if len(keys) == 1 else (None, None)


def settled(query):
    return query.engine._task is None and not query.engine._recalc_pending


def signature(layer, fid_name):
    """Order-independent description of a union result: one entry per
    feature, (area, attributes by field name), with the source fid read
    from `fid_name` and the output table's own primary key ignored."""
    pk = set(layer.primaryKeyAttributes()) if layer.providerType() == "ogr" else set()
    names = [f.name() for i, f in enumerate(layer.fields()) if i not in pk]
    out = []
    for feature in layer.getFeatures():
        attrs = []
        for name in names:
            label = "fid" if name == fid_name else name
            value = feature.attribute(name)
            attrs.append((label, None if value is None or value == QVariant() else value))
        out.append((round(feature.geometry().area(), 3), tuple(sorted(attrs, key=lambda a: a[0]))))
    return sorted(out, key=repr)


def reference_union(layers):
    ensure_union_algorithm()
    registry = QgsApplication.processingRegistry()
    context = QgsProcessingContext()
    context.setProject(QgsProject.instance())
    context.setInvalidGeometryCheck(QgsFeatureRequest.GeometrySkipInvalid)
    feedback = QgsProcessingFeedback()
    current = layers[0]
    for overlay in layers[1:]:
        result, ok = registry.createAlgorithmById("native:union").run(
            {"INPUT": current, "OVERLAY": overlay, "OUTPUT": "TEMPORARY_OUTPUT"}, context, feedback)
        assert ok
        current = context.getMapLayer(result["OUTPUT"])
    return current, context  # keep the context alive while `current` is used


def total_area(layer):
    return round(sum(f.geometry().area() for f in layer.getFeatures()), 3)


print("=" * 70)
print("0. Tester-like layers: ООПТ, ТТП, ВОЗ (with an invalid polygon), ИКН, points")
print("=" * 70)

project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))
project.setFileName(os.path.join(WORKDIR, "union_test.qgz"))

oopt = make_gpkg_layer("ООПТ", "Polygon", [(sq(0, 0, 10, 10), "заказник"), (sq(40, 0, 50, 10), "памятник")])
ttp = make_gpkg_layer("ТТП", "Polygon", [(sq(5, 5, 15, 15), "угодья")])
voz = make_gpkg_layer("ВОЗ", "Polygon", [
    (sq(8, 0, 20, 3), "ВОЗ по водному кодексу"),
    ("POLYGON((60 60,70 70,70 60,60 70,60 60))", "битая геометрия"),  # self-intersecting
])
ikn = make_gpkg_layer("ИКН", "Polygon", [(sq(12, 12, 14, 14), "курган")])
points = make_gpkg_layer("Промобъекты", "Point", [
    ("POINT(1 1)", "P1 в ООПТ"), ("POINT(13 13)", "P2 в ТТП и ИКН"),
    ("POINT(30 30)", "P3 снаружи"), ("POINT(45 5)", "P4 во втором ООПТ"),
    ("POINT(25 25)", "P5 снаружи, пока"),
])
project.addMapLayers([oopt, ttp, voz, ikn, points])
inputs = [oopt, ttp, voz, ikn]
check("ВОЗ really contains an invalid geometry",
      sum(1 for f in voz.getFeatures() if not f.geometry().isGeosValid()) == 1)

iface = get_iface()
plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()
panel = plugin.panel

print()
print("=" * 70)
print("1. The «Объединение» tab")
print("=" * 70)

check("extract tab is the default", panel.current_mode() == MODE_EXTRACT)
panel.set_current_mode(MODE_UNION)
check("switching to the union tab", panel.current_mode() == MODE_UNION)

listed = {panel.union_model.data(panel.union_model.index(r, 0)) for r in range(panel.union_model.rowCount())}
check("lists every layer with geometry, points included", listed == {"ООПТ", "ТТП", "ВОЗ", "ИКН", "Промобъекты"}, listed)

panel.set_union_layers_checked([oopt, points])
panel.createRequested.emit()
check("polygons + points refused (one geometry type only), nothing created",
      not plugin._queries and "одного типа" in panel.status_label.text(), panel.status_label.text())

panel.set_union_layers_checked([oopt])
panel.createRequested.emit()
check("one ticked layer is refused, nothing created", not plugin._queries and "два" in panel.status_label.text(),
      panel.status_label.text())

panel.set_union_layers_checked(inputs)
order = panel.union_layers()
check("all four ticked", len(order) == 4, [l.name() for l in order])
panel.output_name_edit.setText("ООПТ_ТТП_ВОЗ_ИКН")
panel.createRequested.emit()
key, q = union_query(plugin)
check("union query created", q is not None)
ok = wait_for(lambda: settled(q) and q.engine._output_layer is not None, 30)
check("first computation finished", ok)
out = q.engine._output_layer
status = panel.status_label.text()
check("status reports the count and the skipped invalid polygon",
      "объектов в объединении" in status and "некорректной геометрией: 1" in status, status)
check("draft cleared after creation", panel.union_layers() == [], [l.name() for l in panel.union_layers()])
check("still on the union tab", panel.current_mode() == MODE_UNION)

row = panel._row_keys.index(key)
cells = [panel.query_table.item(row, c).text() for c in range(4)]
expected_inputs = " + ".join(l.name() for l in order)
check("table row: name / inputs / (объединение) / Активен",
      cells == ["ООПТ_ТТП_ВОЗ_ИКН", expected_inputs, "(объединение)", "Активен"], cells)
check("output is in the results group",
      project.layerTreeRoot().findGroup("Результаты динамических запросов").findLayer(out.id()) is not None)

print()
print("=" * 70)
print("2. Same result as QGIS's own «Объединение» on the same layers")
print("=" * 70)

# Worked out by hand: ООПТ1 splits into ∩ТТП (25), ∩ВОЗ (6) and the rest
# (69); ООПТ2 (100); ТТП outside ООПТ1 splits into ∩ИКН (4) and the rest
# (71); ВОЗ strip outside ООПТ1 (30). 7 pieces, 305 m².
check("exactly the 7 expected pieces", out.featureCount() == 7, out.featureCount())
check("covering exactly 305 m²", total_area(out) == 305.0, total_area(out))
check("piece areas as worked out by hand",
      sorted(round(f.geometry().area(), 3) for f in out.getFeatures()) == [4, 6, 25, 30, 69, 71, 100],
      sorted(round(f.geometry().area(), 3) for f in out.getFeatures()))

ref, ref_ctx = reference_union(order)
check("same number of pieces as native:union", out.featureCount() == ref.featureCount(),
      (out.featureCount(), ref.featureCount()))
check("same total area", total_area(out) == total_area(ref), (total_area(out), total_area(ref)))
check("same pieces with the same attributes (source fid kept as fid_1)",
      signature(out, "fid_1") == signature(ref, "fid"))
names = [f.name() for f in out.fields()]
check("QGIS-style duplicate field names kept: name, name_2, name_3, name_4",
      all(n in names for n in ["name", "name_2", "name_3", "name_4"]), names)
check("source fid renamed to fid_1; output's own fid is the GeoPackage key",
      "fid_1" in names and out.primaryKeyAttributes() == [names.index("fid")], names)
check("no piece overlaps another (no double counting)",
      all(not a.geometry().overlaps(b.geometry())
          for a in out.getFeatures() for b in out.getFeatures() if a.id() < b.id()))
del ref, ref_ctx

print()
print("=" * 70)
print("3. Live: an edit and a filter change on inputs")
print("=" * 70)

area_before = total_area(out)
oopt.startEditing()
nf = QgsFeature(oopt.fields())
nf.setGeometry(QgsGeometry.fromWkt(sq(100, 100, 110, 110)))
nf.setAttribute("name", "новый")
oopt.addFeature(nf)
oopt.commitChanges()
ok = wait_for(lambda: settled(q) and total_area(out) == round(area_before + 100, 3), 15)
check("new ООПТ polygon appears in the union (+100 m²)", ok, (area_before, total_area(out)))

voz.setSubsetString("\"name\" = 'битая геометрия'")
ok = wait_for(lambda: settled(q) and total_area(out) == round(area_before + 100 - 36 + 6, 3), 15)
check("filtering ВОЗ down to only its invalid polygon removes the strip (-36 +6 overlap)", ok, total_area(out))
voz.setSubsetString("")
ok = wait_for(lambda: settled(q) and total_area(out) == round(area_before + 100, 3), 15)
check("clearing the filter brings it back", ok, total_area(out))

print()
print("=" * 70)
print("4. Chain: union output as the selection layer of an extract query")
print("=" * 70)

panel.set_current_mode(MODE_EXTRACT)
panel.subject_combo.setLayer(points)
QCoreApplication.processEvents()
panel.selection_combo.setLayer(out)
panel.output_name_edit.setText("Промобъекты_на_ООТ")
panel.createRequested.emit()
ekey = [k for k, x in plugin._queries.items() if x.engine.QUERY_TYPE == "extract"][0]
eq = plugin._queries[ekey]
ok = wait_for(lambda: settled(eq) and eq.engine._output_layer is not None, 15)
check("extract over the union settles", ok)
check("3 of 5 points lie in the combined zones", eq.engine._output_layer.featureCount() == 3,
      eq.engine._output_layer.featureCount())

ttp.startEditing()
nf = QgsFeature(ttp.fields())
nf.setGeometry(QgsGeometry.fromWkt(sq(24, 24, 26, 26)))
nf.setAttribute("name", "новые угодья")
ttp.addFeature(nf)
ttp.commitChanges()
ok = wait_for(lambda: settled(q) and settled(eq) and eq.engine._output_layer.featureCount() == 4, 20)
check("a new ТТП polygon around P5 flows through union -> extract (4 points)", ok,
      eq.engine._output_layer.featureCount())

print()
print("=" * 70)
print("5. A field added to an input appears in the result")
print("=" * 70)

ikn.startEditing()
ikn.addAttribute(QgsField("категория", QVariant.String))
ikn.commitChanges()
ikn.startEditing()
idx = ikn.fields().indexOf("категория")
for f in ikn.getFeatures():
    ikn.changeAttributeValue(f.id(), idx, "федеральный")
ikn.commitChanges()
ok = wait_for(lambda: settled(q) and out.fields().indexOf("категория") >= 0, 15)
check("output gained the new column", ok, [f.name() for f in out.fields()])
values = {f["категория"] for f in out.getFeatures()} if ok else set()
check("with the new values", "федеральный" in values, values)

print()
print("=" * 70)
print("6. Rename, then save / close / reopen the project")
print("=" * 70)

ikn.setName("ИКН_археология")
QCoreApplication.processEvents()
row = panel._row_keys.index(key)
check("renaming an input updates the table", "ИКН_археология" in panel.query_table.item(row, 1).text(),
      panel.query_table.item(row, 1).text())

out_path = q.engine.output_gpkg_file_path()
count_before_reload = out.featureCount()
order_names = [l.name() for l in order]  # these layer objects are gone after clear()
project.write()
project.clear()
t = time.time()
while time.time() - t < 1.5:
    QCoreApplication.processEvents()
    time.sleep(0.05)
check("closing the project keeps the union's output file", os.path.exists(out_path))
check("queries stopped while no project is open", not plugin._queries)

project.read(os.path.join(WORKDIR, "union_test.qgz"))
QCoreApplication.processEvents()
key, q = union_query(plugin)
check("union query restored on reopen", q is not None)
if q is not None:
    out = q.engine._output_layer
    check("restored with its four inputs, same order", [l.name() for l in q.engine.input_layers] == order_names,
          [l.name() for l in q.engine.input_layers])
    check("output data survived", out is not None and out.featureCount() == count_before_reload,
          out.featureCount() if out else None)
    check("the chained extract query restored too",
          any(x.engine.QUERY_TYPE == "extract" for x in plugin._queries.values()))
    oopt = next(l for l in project.mapLayers().values() if l.name() == "ООПТ")
    area_before = total_area(out)
    oopt.startEditing()
    nf = QgsFeature(oopt.fields())
    nf.setGeometry(QgsGeometry.fromWkt(sq(200, 200, 201, 201)))
    oopt.addFeature(nf)
    oopt.commitChanges()
    ok = wait_for(lambda: settled(q) and total_area(out) == round(area_before + 1, 3), 15)
    check("still live after reopening", ok, (area_before, total_area(out)))

print()
print("=" * 70)
print("7. PostgreSQL input")
print("=" * 70)

r = subprocess.run(
    ["psql", "-h", "localhost", "-U", "postgres", "-d", "qgis_test", "-c", """
DROP TABLE IF EXISTS uniontest_zones;
CREATE TABLE uniontest_zones (id serial PRIMARY KEY, name text, geom geometry(Polygon, 3857));
INSERT INTO uniontest_zones (name, geom) VALUES ('pg_zone', ST_GeomFromText('POLYGON((0 0,4 0,4 4,0 4,0 0))', 3857));
"""],
    env={"PGPASSWORD": "postgres", "PATH": "/usr/bin"}, capture_output=True, text=True,
)
check("PostGIS table created", r.returncode == 0, r.stderr)
pg = QgsVectorLayer(
    "dbname='qgis_test' host=localhost user='postgres' password='postgres' sslmode=disable "
    "key='id' srid=3857 type=Polygon table=\"public\".\"uniontest_zones\" (geom)", "pg_zones", "postgres")
check("pg layer valid", pg.isValid())
project.addMapLayer(pg)
ttp = next(l for l in project.mapLayers().values() if l.name() == "ТТП")
panel.set_current_mode(MODE_UNION)
panel.set_union_layers_checked([pg, ttp])
panel.output_name_edit.setText("pg_union")
panel.createRequested.emit()
pg_query = next(x for x in plugin._queries.values()
                if x.engine.QUERY_TYPE == "union" and pg in x.engine.input_layers)
ok = wait_for(lambda: settled(pg_query) and pg_query.engine._output_layer is not None, 30)
check("union with a PostgreSQL input finishes (no hang)", ok)
if ok:
    check("area = 16 (pg) + 104 (ТТП: 100 + 4)", total_area(pg_query.engine._output_layer) == 120.0,
          total_area(pg_query.engine._output_layer))

print()
print("=" * 70)
print("8. Removing an input tears the query down; «Удалить» removes output + file")
print("=" * 70)

pg_out = pg_query.engine._output_layer
pg_key = pg_query.engine.query_id
project.removeMapLayer(pg.id())
QCoreApplication.processEvents()
check("removing an input layer removes its union query", pg_key not in plugin._queries)
check("...but leaves the output layer in place", project.mapLayer(pg_out.id()) is not None)

key, q = union_query(plugin)
out = q.engine._output_layer
out_id = out.id()
out_path = q.engine.output_gpkg_file_path()
panel.select_table_row_for_key(key)
plugin._on_query_row_selected(key)
panel.removeRequested.emit()
t = time.time()
while time.time() - t < 1.5:
    QCoreApplication.processEvents()
    time.sleep(0.05)
check("«Удалить» removes the union query", key not in plugin._queries)
check("...its output layer", project.mapLayer(out_id) is None)
check("...and its file", not os.path.exists(out_path))

plugin.unload()
subprocess.run(["psql", "-h", "localhost", "-U", "postgres", "-d", "qgis_test", "-c",
                "DROP TABLE IF EXISTS uniontest_zones;"],
               env={"PGPASSWORD": "postgres", "PATH": "/usr/bin"}, capture_output=True)

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
print("RESULT: all checks passed")
