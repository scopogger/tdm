"""
Child process for test_postgres_listen.py -- run in its own process
because on an unfixed QGIS the failure mode is a hard crash or a
permanent hang, neither of which a test can catch in-process.

Usage: python3 _listen_gate_child.py <auto|force_on>

Loads a real PostGIS layer whose credentials live in a QGIS
authentication configuration (authcfg) -- the setup that triggers the
QGIS listener bug -- then points a ReactiveWatcher at it, the same
way the plugin does for a live query. Prints RETURNED if watch()
comes back.
"""
import os
import sys
import tempfile
from pathlib import Path

mode = sys.argv[1]
os.environ["QGIS_AUTH_DB_DIR_PATH"] = tempfile.mkdtemp()
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.core import QgsApplication, QgsAuthMethodConfig, QgsVectorLayer  # noqa: E402

import dynamic_spatial_query.reactive_watcher as rw  # noqa: E402

rw.ENABLE_POSTGRES_LISTEN = None if mode == "auto" else True

am = QgsApplication.authManager()
am.setMasterPassword("masterpw", True)
cfg = QgsAuthMethodConfig()
cfg.setName("pg")
cfg.setMethod("Basic")
cfg.setConfig("username", "postgres")
cfg.setConfig("password", "postgres")
am.storeAuthenticationConfig(cfg)

layer = QgsVectorLayer(
    f"dbname='qgis_test' host=127.0.0.1 port=5432 authcfg={cfg.id()} sslmode=disable "
    "key='id' srid=3857 type=Point table=\"public\".\"listentest_pts\" (geom)",
    "authcfg_layer", "postgres",
)
print("LAYER_VALID", layer.isValid(), flush=True)
print("LISTEN_ENABLED", rw.postgres_listen_enabled(), flush=True)

watcher = rw.ReactiveWatcher()
watcher.watch([layer])
print("RETURNED", flush=True)
watcher.stop()
print("STOPPED", flush=True)
