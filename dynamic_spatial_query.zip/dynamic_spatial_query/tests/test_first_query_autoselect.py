"""
Regression test for a real bug: creating the very first query (table
goes from 0 rows to 1) left it LOOKING selected in the table (Qt's
own doing) while the controller's _selected_key stayed None forever
-- confirmed directly that itemSelectionChanged does not fire for
this specific empty-table-to-first-row transition, so nothing ever
told the plugin a row was "selected". With only one row in the table
and Qt already considering it selected, clicking the same row again
was a no-op from Qt's perspective (nothing to "change" to), which is
why clicking again didn't help and deselecting wasn't possible either
-- both symptoms follow directly from the same root cause, not two
separate bugs.

Fixed by explicitly selecting the newly-created row through the
normal controlled path (the same one a real row click drives)
immediately after creation, rather than depending on Qt's own
auto-select behavior and its signal.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from _test_helpers import key_for_subject, wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
zone.dataProvider().addFeatures([zf])

buildings = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "buildings", "memory")
bf = QgsFeature(buildings.fields())
bf.setGeometry(QgsGeometry.fromWkt("POINT(10 10)"))
bf.setAttribute("name", "b0")
buildings.dataProvider().addFeatures([bf])

project.addMapLayers([zone, buildings], False)
for lyr in (zone, buildings):
    project.layerTreeRoot().addLayer(lyr)

print("=" * 70)
print("1. Creating the very first query auto-selects it correctly")
print("=" * 70)

plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()

check("table starts empty (0 rows) -- the exact transition that triggered this",
      plugin.panel.query_table.rowCount() == 0)

plugin.panel.subject_combo.setLayer(buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)
plugin.panel.createRequested.emit()
key = key_for_subject(plugin, buildings)
ok = wait_for(lambda: key in plugin._queries and plugin._queries[key].engine._task is None, 5.0)
check("query created and settled", ok)

check("controller's _selected_key matches the new query", plugin._selected_key == key,
      plugin._selected_key)
check("table's own selection model agrees (genuinely selected, not just current)",
      [i.row() for i in plugin.panel.query_table.selectionModel().selectedRows()] == [0])
check("Удалить is enabled", plugin.panel.remove_btn.isEnabled())
check("Обновить is enabled", plugin.panel.refresh_btn.isEnabled())
check("auto-update checkbox is enabled", plugin.panel.auto_update_check.isEnabled())
check("periodic refresh checkbox is enabled", plugin.panel.periodic_check.isEnabled())

print()
print("=" * 70)
print("2. Removing it correctly deselects and disables the row controls again")
print("=" * 70)

plugin._on_remove_requested()
QCoreApplication.processEvents()
check("no longer selected after removal", plugin._selected_key is None)
check("Удалить disabled again", not plugin.panel.remove_btn.isEnabled())
check("table has no rows left", plugin.panel.query_table.rowCount() == 0)

print()
print("=" * 70)
print("3. Same check for a second 'first' query in a row (not a one-off fluke)")
print("=" * 70)

plugin.panel.subject_combo.setLayer(buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)
plugin.panel.createRequested.emit()
key2 = key_for_subject(plugin, buildings)
ok = wait_for(lambda: key2 in plugin._queries and plugin._queries[key2].engine._task is None, 5.0)
check("second query created and settled", ok)
check("auto-selected correctly again", plugin._selected_key == key2, plugin._selected_key)
check("Удалить enabled again", plugin.panel.remove_btn.isEnabled())

plugin.unload()

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
