"""
The «Слияние» (merge) query type, and «Объединение» on point and line
layers -- end to end through the real panel.

Built around the tester's own example (phone call): a round lake 10 m
across, a round island 5 m across in its middle, and a pipe straight
through both. Measuring "pipe length inside the zones":

- «Объединение» of lake + island gives two objects (the island, and the
  lake with an island-shaped hole), so the pipe cut by each object is
  5 m and 5 m -- every object reports 5 m, not 10.
- «Слияние» gives one object, so the same cut gives 10 m directly.

Then: the same with the island as a hole in the lake polygon; the merge
matches QGIS's own Merge vector layers + Dissolve; one-layer merges of
points and connected lines; live updates; invalid geometry skipped;
chaining into an extract query; save / close / reopen; teardown and
«Удалить»; union of line layers and of point layers matching QGIS's
own Union; mixed geometry types refused.
"""
import math
import os
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsApplication,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransformContext,
    QgsFeature,
    QgsFeatureRequest,
    QgsGeometry,
    QgsPointXY,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from dynamic_spatial_query.query_panel import MODE_DISSOLVE, MODE_EXTRACT, MODE_UNION  # noqa: E402
from dynamic_spatial_query.union_engine import ensure_union_algorithm  # noqa: E402
from _test_helpers import wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


WORKDIR = tempfile.mkdtemp(prefix="dsq_merge_")


def disc_ring(cx, cy, r, n=128):
    # n divisible by 4, so there are vertices exactly at (cx ± r, cy):
    # a pipe along the x axis crosses exactly 2r of the disc.
    return [QgsPointXY(cx + r * math.cos(2 * math.pi * k / n), cy + r * math.sin(2 * math.pi * k / n))
            for k in range(n)] + [QgsPointXY(cx + r, cy)]


def disc(cx, cy, r):
    return QgsGeometry.fromPolygonXY([disc_ring(cx, cy, r)])


def disc_with_hole(cx, cy, r_outer, r_hole):
    return QgsGeometry.fromPolygonXY([disc_ring(cx, cy, r_outer), list(reversed(disc_ring(cx, cy, r_hole)))])


def make_gpkg_layer(name, geometry_type, geometries, names=None):
    memory = QgsVectorLayer(f"{geometry_type}?crs=EPSG:3857&field=name:string", name, "memory")
    feats = []
    for i, geometry in enumerate(geometries):
        f = QgsFeature(memory.fields())
        f.setGeometry(geometry if isinstance(geometry, QgsGeometry) else QgsGeometry.fromWkt(geometry))
        f.setAttribute("name", (names or [f"{name}_{i + 1}" for i in range(len(geometries))])[i])
        feats.append(f)
    memory.dataProvider().addFeatures(feats)
    path = os.path.join(WORKDIR, f"{name}.gpkg")
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = name
    QgsVectorFileWriter.writeAsVectorFormatV3(memory, path, QgsCoordinateTransformContext(), options)
    layer = QgsVectorLayer(f"{path}|layername={name}", name, "ogr")
    assert layer.isValid(), path
    return layer


def part_count(layer):
    """Parts of a layer's single feature. The geometry is held in a
    variable on purpose: f.geometry().constGet() on a temporary reads
    freed memory once Python drops the temporary QgsGeometry."""
    features = list(layer.getFeatures())
    if len(features) != 1:
        return None
    geometry = features[0].geometry()
    return geometry.constGet().numGeometries()


def settled(query):
    return query.engine._task is None and not query.engine._recalc_pending


def pipe_length_inside(pipe_geometry, zone_layer):
    """What the tester measures: the pipe cut by each zone object."""
    return sorted(round(pipe_geometry.intersection(f.geometry()).length(), 6) for f in zone_layer.getFeatures())


def create(plugin, mode, layers, name):
    panel = plugin.panel
    panel.set_current_mode(mode)
    if mode == MODE_UNION:
        panel.set_union_layers_checked(layers)
    else:
        panel.set_dissolve_layers_checked(layers)
    panel.output_name_edit.setText(name)
    before = set(plugin._queries)
    panel.createRequested.emit()
    new = [k for k in plugin._queries if k not in before]
    if len(new) != 1:
        return None, None
    q = plugin._queries[new[0]]
    wait_for(lambda: settled(q) and q.engine._output_layer is not None, 30)
    return new[0], q


def run_alg(alg_id, params, context):
    ensure_union_algorithm()
    result, ok = QgsApplication.processingRegistry().createAlgorithmById(alg_id).run(
        params, context, QgsProcessingFeedback())
    assert ok, alg_id
    return context.getMapLayer(result["OUTPUT"])


def pump(seconds):
    t = time.time()
    while time.time() - t < seconds:
        QCoreApplication.processEvents()
        time.sleep(0.05)


print("=" * 70)
print("0. The tester's lake, island and pipe (+ points and lines layers)")
print("=" * 70)

project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))
project.setFileName(os.path.join(WORKDIR, "merge_test.qgz"))

lakes = make_gpkg_layer("Водоёмы", "Polygon", [disc(0, 0, 5)], ["озеро"])
islands = make_gpkg_layer("Острова", "Polygon", [disc(0, 0, 2.5)], ["остров"])
lake_ring = make_gpkg_layer("Озеро_без_острова", "Polygon", [disc_with_hole(0, 0, 5, 2.5)], ["вода"])
pipe = make_gpkg_layer("Трубопровод", "LineString", ["LINESTRING(-20 0, 20 0)"])
pipe_2 = make_gpkg_layer("Трубопровод_2", "LineString", ["LINESTRING(20 0, 30 0)"])
crossing = make_gpkg_layer("Пересекающий", "LineString", ["LINESTRING(10 -10, 10 10)"])
wells = make_gpkg_layer("Скважины", "Point", ["POINT(1 1)", "POINT(2 2)", "POINT(2 2)", "POINT(50 50)", "POINT(3 0)"])
wells_2 = make_gpkg_layer("Скважины_2", "Point", ["POINT(2 2)", "POINT(70 70)"])
project.addMapLayers([lakes, islands, lake_ring, pipe, pipe_2, crossing, wells, wells_2])
pipe_geometry = next(pipe.getFeatures()).geometry()
check("lake ring alone: pipe inside the water is 5 m (2.5 + 2.5)",
      pipe_length_inside(pipe_geometry, lake_ring) == [5.0], pipe_length_inside(pipe_geometry, lake_ring))

plugin = DynamicSpatialQueryPlugin(get_iface())
plugin.initGui()
panel = plugin.panel

print()
print("=" * 70)
print("1. The «Слияние» tab")
print("=" * 70)

panel.set_current_mode(MODE_DISSOLVE)
check("third tab is «Слияние»", panel.current_mode() == MODE_DISSOLVE
      and panel.mode_tabs.tabText(2) == "Слияние", panel.mode_tabs.tabText(2))
listed = {panel.dissolve_model.data(panel.dissolve_model.index(r, 0)) for r in range(panel.dissolve_model.rowCount())}
check("lists point, line and polygon layers", {"Водоёмы", "Трубопровод", "Скважины"} <= listed, listed)
panel.set_dissolve_layers_checked([])
panel.createRequested.emit()
check("nothing ticked is refused", not plugin._queries and "хотя бы один" in panel.status_label.text(),
      panel.status_label.text())
panel.set_dissolve_layers_checked([lakes, pipe])
panel.createRequested.emit()
check("polygons + lines refused", not plugin._queries and "одного типа" in panel.status_label.text(),
      panel.status_label.text())

print()
print("=" * 70)
print("2. The tester's example: «Объединение» gives 5 m per object")
print("=" * 70)

ukey, uq = create(plugin, MODE_UNION, [lakes, islands], "озеро_объединение")
check("union created", uq is not None)
union_out = uq.engine._output_layer
check("union: 2 objects (island, and lake with a hole)", union_out.featureCount() == 2, union_out.featureCount())
check("pipe cut by each union object: 5 m and 5 m",
      pipe_length_inside(pipe_geometry, union_out) == [5.0, 5.0], pipe_length_inside(pipe_geometry, union_out))

print()
print("=" * 70)
print("3. «Слияние» gives one object and 10 m")
print("=" * 70)

mkey, mq = create(plugin, MODE_DISSOLVE, [lakes, islands], "озеро_слияние")
check("merge created", mq is not None)
merged = mq.engine._output_layer
check("exactly one object", merged.featureCount() == 1, merged.featureCount())
pk = merged.primaryKeyAttributes()
check("no attributes kept (only the GeoPackage's own fid)",
      [f.name() for i, f in enumerate(merged.fields()) if i not in pk] == [],
      [f.name() for f in merged.fields()])
check("pipe cut by the merged object: 10 m", pipe_length_inside(pipe_geometry, merged) == [10.0],
      pipe_length_inside(pipe_geometry, merged))
check("area = the lake's (island lies inside it)",
      abs(next(merged.getFeatures()).geometry().area() - disc(0, 0, 5).area()) < 1e-6)
status = panel.status_label.text()
check("status: 2 objects merged into one", "объектов слито в один: 2" in status, status)
row = panel._row_keys.index(mkey)
cells = [panel.query_table.item(row, c).text() for c in range(4)]
check("table row: name / Водоёмы + Острова / (слияние) / Активен",
      cells == ["озеро_слияние", "Водоёмы + Острова", "(слияние)", "Активен"], cells)

print()
print("=" * 70)
print("4. Island as a hole in the lake polygon, merged with the island")
print("=" * 70)

hkey, hq = create(plugin, MODE_DISSOLVE, [lake_ring, islands], "кольцо_слияние")
check("one object, pipe 10 m", hq is not None and hq.engine._output_layer.featureCount() == 1
      and pipe_length_inside(pipe_geometry, hq.engine._output_layer) == [10.0],
      pipe_length_inside(pipe_geometry, hq.engine._output_layer) if hq else None)

print()
print("=" * 70)
print("5. Same geometry as QGIS's «Объединить векторные слои» + «Слияние по признаку»")
print("=" * 70)

context = QgsProcessingContext()
context.setProject(project)
merged_layers = run_alg("native:mergevectorlayers", {"LAYERS": [lakes, islands], "OUTPUT": "TEMPORARY_OUTPUT"}, context)
dissolved = run_alg("native:dissolve", {"INPUT": merged_layers, "OUTPUT": "TEMPORARY_OUTPUT"}, context)
reference = next(dissolved.getFeatures()).geometry()
ours = next(merged.getFeatures()).geometry()
check("QGIS gives one feature too", dissolved.featureCount() == 1)
check("identical geometry (symmetric difference area 0)", ours.symDifference(reference).area() < 1e-9,
      ours.symDifference(reference).area())

print()
print("=" * 70)
print("6. Points and lines")
print("=" * 70)

wkey, wq = create(plugin, MODE_DISSOLVE, [wells], "скважины_слияние")
wout = wq.engine._output_layer if wq else None
check("one layer of points: one multipoint object", wout is not None and wout.featureCount() == 1)
wgeom = next(wout.getFeatures()).geometry() if wout else QgsGeometry()
check("5 points, the duplicate collapsed: 4 parts", wgeom.constGet().numGeometries() == 4,
      wgeom.asWkt())

lkey, lq = create(plugin, MODE_DISSOLVE, [pipe, pipe_2], "трубы_слияние")
lout = lq.engine._output_layer if lq else None
lgeom = next(lout.getFeatures()).geometry() if lout else QgsGeometry()
check("two connected pipelines: one object, joined into one line, 50 m",
      lout is not None and lout.featureCount() == 1 and lgeom.constGet().numGeometries() == 1
      and abs(lgeom.length() - 50) < 1e-9, lgeom.asWkt())

print()
print("=" * 70)
print("7. «Объединение» of line layers and of point layers = QGIS's own Union")
print("=" * 70)

ckey, cq = create(plugin, MODE_UNION, [crossing, pipe], "линии_объединение")
cout = cq.engine._output_layer if cq else None
ref_lines = run_alg("native:union", {"INPUT": cq.engine.input_layers[0], "OVERLAY": cq.engine.input_layers[1],
                                     "OUTPUT": "TEMPORARY_OUTPUT"}, context)
check("lines: same number of objects as QGIS", cout is not None and cout.featureCount() == ref_lines.featureCount(),
      (cout.featureCount() if cout else None, ref_lines.featureCount()))
check("lines: same lengths as QGIS",
      sorted(round(f.geometry().length(), 6) for f in cout.getFeatures()) ==
      sorted(round(f.geometry().length(), 6) for f in ref_lines.getFeatures()))
check("lines: total length kept (40 + 20 m)", abs(sum(f.geometry().length() for f in cout.getFeatures()) - 60) < 1e-9)

pkey, pq = create(plugin, MODE_UNION, [wells, wells_2], "точки_объединение")
pout = pq.engine._output_layer if pq else None
ref_points = run_alg("native:union", {"INPUT": pq.engine.input_layers[0], "OVERLAY": pq.engine.input_layers[1],
                                      "OUTPUT": "TEMPORARY_OUTPUT"}, context)
check("points: same number of objects as QGIS", pout is not None and pout.featureCount() == ref_points.featureCount(),
      (pout.featureCount() if pout else None, ref_points.featureCount()))
both = [f for f in pout.getFeatures() if f["name"] and f["name_2"]] if pout else []
check("points: the shared location (2 2) carries attributes from both layers", len(both) >= 1,
      [f.attributes() for f in pout.getFeatures()] if pout else None)

print()
print("=" * 70)
print("8. Live: edits and filters; invalid geometry skipped")
print("=" * 70)

lakes.startEditing()
nf = QgsFeature(lakes.fields())
nf.setGeometry(disc(100, 0, 5))
nf.setAttribute("name", "второе озеро")
lakes.addFeature(nf)
lakes.commitChanges()
ok = wait_for(lambda: settled(mq) and part_count(merged) == 2, 15)
check("a second lake: still one object, now two parts", ok, part_count(merged))

lakes.setSubsetString("\"name\" = 'второе озеро'")
ok = wait_for(lambda: settled(mq) and merged.featureCount() == 1
              and abs(next(merged.getFeatures()).geometry().area() - disc(0, 0, 5).area() - disc(0, 0, 2.5).area()) < 1e-6, 15)
check("filtering the first lake out: island + second lake", ok)
lakes.setSubsetString("")

islands.startEditing()
bad = QgsFeature(islands.fields())
bad.setGeometry(QgsGeometry.fromWkt("POLYGON((60 60,70 70,70 60,60 70,60 60))"))
bad.setAttribute("name", "битая геометрия")
islands.addFeature(bad)
islands.commitChanges()
ok = wait_for(lambda: settled(mq) and mq.engine.last_skipped_invalid == 1, 15)
check("an invalid polygon is skipped and counted", ok, mq.engine.last_skipped_invalid)
check("result still one object", merged.featureCount() == 1)

print()
print("=" * 70)
print("9. Merge output as the selection layer of an extract query")
print("=" * 70)

panel.set_current_mode(MODE_EXTRACT)
panel.subject_combo.setLayer(wells)
QCoreApplication.processEvents()
panel.selection_combo.setLayer(merged)
panel.output_name_edit.setText("скважины_в_озёрах")
panel.createRequested.emit()
eq = next(q for q in plugin._queries.values() if q.engine.QUERY_TYPE == "extract")
ok = wait_for(lambda: settled(eq) and eq.engine._output_layer is not None, 15)
check("wells inside the merged lakes: 4 of 5 (all but 50,50)",
      ok and eq.engine._output_layer.featureCount() == 4,
      eq.engine._output_layer.featureCount() if eq.engine._output_layer else None)

print()
print("=" * 70)
print("10. Save / close / reopen")
print("=" * 70)

merged_path = mq.engine.output_gpkg_file_path()
project.write()
project.clear()
pump(1.5)
check("merge output file kept on close", os.path.exists(merged_path))
project.read(os.path.join(WORKDIR, "merge_test.qgz"))
QCoreApplication.processEvents()
restored = [q for q in plugin._queries.values() if q.engine.QUERY_TYPE == "dissolve"]
check("all four merge queries restored", len(restored) == 4, len(restored))
mq = next((q for q in restored if q.engine.output_name == "озеро_слияние"), None)
check("the lake merge restored with its inputs",
      mq is not None and [l.name() for l in mq.engine.input_layers] == ["Водоёмы", "Острова"])
if mq is not None:
    merged = mq.engine._output_layer
    check("still one object after reopening", merged.featureCount() == 1)
    lakes = next(l for l in project.mapLayers().values() if l.name() == "Водоёмы")
    lakes.startEditing()
    nf = QgsFeature(lakes.fields())
    nf.setGeometry(disc(200, 0, 5))
    lakes.addFeature(nf)
    lakes.commitChanges()
    ok = wait_for(lambda: settled(mq) and part_count(merged) == 3, 15)
    check("still live after reopening (third lake → three parts)", ok)

print()
print("=" * 70)
print("11. Teardown and «Удалить»")
print("=" * 70)

islands = next(l for l in project.mapLayers().values() if l.name() == "Острова")
before = len(plugin._queries)
project.removeMapLayer(islands.id())
QCoreApplication.processEvents()
gone = before - len(plugin._queries)
check("removing Острова removes the queries that used it (union, 2 merges)", gone == 3, gone)

wq = next(q for q in plugin._queries.values() if q.engine.output_name == "скважины_слияние")
wkey = wq.engine.query_id
out_id = wq.engine._output_layer.id()
out_path = wq.engine.output_gpkg_file_path()
panel.select_table_row_for_key(wkey)
plugin._on_query_row_selected(wkey)
panel.removeRequested.emit()
pump(1.5)
check("«Удалить» removes the merge query, its layer and its file",
      wkey not in plugin._queries and project.mapLayer(out_id) is None and not os.path.exists(out_path))

plugin.unload()
print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
print("RESULT: all checks passed")
