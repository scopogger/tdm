"""
Three fixes from a real user feedback report, tested directly:

1. Background tasks are created with the Silent flag, suppressing
   OS-level popup notifications on every completion -- a real user
   reported "messages keep popping up constantly", with a screenshot
   of a Windows toast from a NextGIS QGIS build reading "Задача
   выполнена" / "Dynamic spatial query" (this plugin's own task
   description). Confirmed this build surfaces such notifications
   for any task lacking QgsTask.Silent.
2. The management table's status column distinguishes "actively
   updating on a timer" from "genuinely not auto-updating at all" --
   previously both showed "Приостановлен" (Paused), which is
   misleading for exactly the case a database-backed query defaults
   to (auto_update off, periodic on): it IS updating, just not
   instantly, and seeing "Paused" for a query that's actually running
   could easily read as "broken" rather than "delayed".
3. A menu action explicitly re-expands the query-list side of the
   panel -- a real user reported not being able to find "which layers
   are in the query", most likely because the collapsible splitter
   (which matches QGIS's own native dialog style, complete with a
   small handle-embedded toggle button) got collapsed, deliberately
   or by an accidental drag, with no obvious way back for someone who
   doesn't know to look for that handle.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsTask,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from dynamic_spatial_query.spatial_query_engine import SpatialQueryEngine  # noqa: E402
from _test_helpers import key_for_subject, wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
zone.dataProvider().addFeatures([zf])

buildings = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "buildings", "memory")
bf = QgsFeature(buildings.fields())
bf.setGeometry(QgsGeometry.fromWkt("POINT(10 10)"))
bf.setAttribute("name", "b0")
buildings.dataProvider().addFeatures([bf])

project.addMapLayers([zone, buildings], False)
for lyr in (zone, buildings):
    project.layerTreeRoot().addLayer(lyr)

print("=" * 70)
print("1. Background tasks are created with the Silent flag")
print("=" * 70)

engine = SpatialQueryEngine(iface)
engine.set_subject_layer(buildings)
engine.set_selection_layer(zone)
engine.set_predicates(["Intersects"])

engine.recalculate(on_done=lambda c, e: None)
ok = wait_for(lambda: engine._task is not None, 2.0)
check("a task is actually running to inspect", ok)
if engine._task is not None:
    check("task has the Silent flag set", bool(engine._task.flags() & QgsTask.Silent),
          int(engine._task.flags()))
    check("task still has CanCancel (unrelated flag, should be unaffected)",
          bool(engine._task.flags() & QgsTask.CanCancel))
wait_for(lambda: engine._task is None, 5.0)  # let it finish before reusing the layers

print()
print("=" * 70)
print("2. Management table status column distinguishes timer-driven from truly paused")
print("=" * 70)

# Fresh project state -- part 1's standalone engine wrote its own
# output layer into the shared project, which would otherwise get
# picked up by the plugin's own restoration logic below, creating an
# unexpected second query sharing the same subject.
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))
zone2 = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf2 = QgsFeature(zone2.fields())
zf2.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
zone2.dataProvider().addFeatures([zf2])
buildings2 = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "buildings", "memory")
bf2 = QgsFeature(buildings2.fields())
bf2.setGeometry(QgsGeometry.fromWkt("POINT(10 10)"))
bf2.setAttribute("name", "b0")
buildings2.dataProvider().addFeatures([bf2])
project.addMapLayers([zone2, buildings2], False)
for lyr in (zone2, buildings2):
    project.layerTreeRoot().addLayer(lyr)

plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()

# query A: plain local layers, auto_update True by default -> "Активен"
plugin.panel.subject_combo.setLayer(buildings2)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone2)
plugin.panel.createRequested.emit()
key_a = key_for_subject(plugin, buildings2)
wait_for(lambda: key_a in plugin._queries and plugin._queries[key_a].engine._task is None, 5.0)

row_a = plugin.panel._row_keys.index(key_a)
status_a = plugin.panel.query_table.item(row_a, 3).text()
check("auto-updating query shows 'Активен'", status_a == "Активен", status_a)

# flip it to periodic-only (auto_update off, periodic on) -- same
# state a database-backed query defaults to
plugin._on_query_row_selected(key_a)
plugin.panel.auto_update_check.setChecked(False)
plugin.panel.periodic_check.setChecked(True)
plugin.panel.periodic_spin.setValue(45)
QCoreApplication.processEvents()

row_a = plugin.panel._row_keys.index(key_a)
status_a = plugin.panel.query_table.item(row_a, 3).text()
check("periodic-only query shows it's still active, not 'Приостановлен'",
      "Приостановлен" not in status_a, status_a)
check("periodic-only status mentions the interval", "45" in status_a, status_a)

# flip to genuinely paused (both off)
plugin.panel.periodic_check.setChecked(False)
QCoreApplication.processEvents()
row_a = plugin.panel._row_keys.index(key_a)
status_a = plugin.panel.query_table.item(row_a, 3).text()
check("genuinely paused query shows 'Приостановлен'", status_a == "Приостановлен", status_a)

print()
print("=" * 70)
print("3. 'Показать список запросов' menu action un-hides and un-collapses the panel")
print("=" * 70)

plugin.panel.splitter._toggle_right_panel()  # simulate an accidental collapse
check("right panel is now collapsed (test setup sanity check)",
      plugin.panel.splitter.sizes()[1] == 0)
plugin.panel.hide()
check("panel is hidden (test setup sanity check)", plugin.panel.isHidden())

plugin._show_query_list()
check("panel is shown again", not plugin.panel.isHidden())
check("right panel is expanded again", plugin.panel.splitter.sizes()[1] > 0,
      plugin.panel.splitter.sizes())
check("toolbar action reflects the now-visible state", plugin.action.isChecked())

plugin.unload()

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
