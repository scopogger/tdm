"""
A query involving a database-backed layer (subject or selection)
defaults to auto-update OFF / periodic refresh ON, with the
auto-update checkbox disabled for it -- see plugin.py's module
docstring for why (QGIS issue #55707). A query using only local
layers keeps the previous behavior unchanged: auto-update on by
default, checkbox enabled, periodic optional.

Runs against a REAL PostgreSQL/PostGIS connection, not a mock, since
the whole point is testing the provider-name-based detection against
an actual postgres provider.
"""
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from _test_helpers import wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


def create_and_wait(plugin, subject, selection, timeout_s=10.0):
    before = set(plugin._queries.keys())
    plugin.panel.subject_combo.setLayer(subject)
    QCoreApplication.processEvents()
    plugin.panel.selection_combo.setLayer(selection)
    plugin.panel.createRequested.emit()
    ok = wait_for(lambda: len(plugin._queries) > len(before), timeout_s)
    if not ok:
        return None
    new_key = next(iter(set(plugin._queries.keys()) - before))
    wait_for(lambda: plugin._queries[new_key].engine._task is None, timeout_s)
    return new_key


CONN = "dbname='qgis_test' host=localhost user='postgres' password='postgres'"

print("=" * 70)
print("0. Set up a real PostGIS table")
print("=" * 70)

setup_sql = """
DROP TABLE IF EXISTS dbdefault_zones CASCADE;
DROP TABLE IF EXISTS dbdefault_buildings CASCADE;
CREATE TABLE dbdefault_zones (id serial PRIMARY KEY, geom geometry(Polygon, 3857));
INSERT INTO dbdefault_zones (geom) VALUES
    (ST_GeomFromText('POLYGON((0 0,100 0,100 100,0 100,0 0))', 3857));
CREATE TABLE dbdefault_buildings (id serial PRIMARY KEY, name text, geom geometry(Point, 3857));
INSERT INTO dbdefault_buildings (name, geom) VALUES ('b0', ST_GeomFromText('POINT(10 10)', 3857));
"""
result = subprocess.run(
    ["psql", "-h", "localhost", "-U", "postgres", "-d", "qgis_test", "-c", setup_sql],
    env={"PGPASSWORD": "postgres", "PATH": "/usr/bin"},
    capture_output=True, text=True,
)
check("PostGIS test tables created", result.returncode == 0, result.stderr)

iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

pg_zones = QgsVectorLayer(
    f"{CONN} sslmode=disable key='id' srid=3857 type=Polygon table=\"public\".\"dbdefault_zones\" (geom)",
    "pg_zones", "postgres",
)
pg_buildings = QgsVectorLayer(
    f"{CONN} sslmode=disable key='id' srid=3857 type=Point table=\"public\".\"dbdefault_buildings\" (geom)",
    "pg_buildings", "postgres",
)
check("pg_zones valid", pg_zones.isValid())
check("pg_buildings valid", pg_buildings.isValid())

local_zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "local_zone", "memory")
lzf = QgsFeature(local_zone.fields())
lzf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
local_zone.dataProvider().addFeatures([lzf])

local_buildings = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "local_buildings", "memory")
lbf = QgsFeature(local_buildings.fields())
lbf.setGeometry(QgsGeometry.fromWkt("POINT(10 10)"))
lbf.setAttribute("name", "b0")
local_buildings.dataProvider().addFeatures([lbf])

project.addMapLayers([pg_zones, pg_buildings, local_zone, local_buildings], False)

plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()

print()
print("=" * 70)
print("1. A query with a PostgreSQL subject+selection defaults to periodic, checkbox disabled")
print("=" * 70)

key_pg = create_and_wait(plugin, pg_buildings, pg_zones)
check("query created", key_pg is not None)
q_pg = plugin._queries[key_pg]
check("auto_update defaults to False", q_pg.auto_update is False)
check("periodic_enabled defaults to True", q_pg.periodic_enabled is True)
check("periodic_seconds defaults to 30", q_pg.periodic_seconds == 30, q_pg.periodic_seconds)
check("auto-update checkbox is disabled while this query is selected",
      not plugin.panel.auto_update_check.isEnabled())
check("periodic checkbox reflects the default (checked)", plugin.panel.periodic_check.isChecked())
check("watcher's own periodic timer is actually running",
      q_pg.watcher.periodic_refresh_timer.isActive())

print()
print("=" * 70)
print("2. A query with only local layers is unaffected -- current behavior preserved")
print("=" * 70)

key_local = create_and_wait(plugin, local_buildings, local_zone)
check("query created", key_local is not None)
q_local = plugin._queries[key_local]
check("auto_update stays True (default)", q_local.auto_update is True)
check("periodic_enabled stays False (default)", q_local.periodic_enabled is False)
check("auto-update checkbox is enabled while this query is selected",
      plugin.panel.auto_update_check.isEnabled())

print()
print("=" * 70)
print("3. A query with ONE database layer (mixed) is still gated -- 'one of the input layers'")
print("=" * 70)

key_mixed = create_and_wait(plugin, pg_buildings, local_zone)
check("query created", key_mixed is not None)
q_mixed = plugin._queries[key_mixed]
check("mixed subject=db, selection=local still defaults to periodic", q_mixed.auto_update is False)

key_mixed2 = create_and_wait(plugin, local_buildings, pg_zones)
check("second query created", key_mixed2 is not None)
q_mixed2 = plugin._queries[key_mixed2]
check("mixed subject=local, selection=db ALSO defaults to periodic", q_mixed2.auto_update is False)

print()
print("=" * 70)
print("4. Switching the selected row correctly toggles the checkbox each time")
print("=" * 70)

plugin._on_query_row_selected(key_pg)
check("disabled when viewing the db query", not plugin.panel.auto_update_check.isEnabled())
plugin._on_query_row_selected(key_local)
check("enabled when viewing the local query", plugin.panel.auto_update_check.isEnabled())
plugin._on_query_row_selected(key_pg)
check("disabled again switching back", not plugin.panel.auto_update_check.isEnabled())

print()
print("=" * 70)
print("5. Chaining our own (GeoPackage/ogr) output layer with a local layer is NOT gated")
print("=" * 70)

output_local = q_local.engine._output_layer
check("our own output layer uses the ogr provider", output_local.dataProvider().name() == "ogr")
key_chained = create_and_wait(plugin, output_local, local_zone)
check("chained query created", key_chained is not None)
q_chained = plugin._queries[key_chained]
check("chaining our own output layer with a local layer stays on normal auto-update",
      q_chained.auto_update is True, q_chained.auto_update)

plugin.unload()

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
