"""
Regression test for a real crash: unload() followed by a QgsProject
operation elsewhere (project.clear(), specifically after a
project.write() had happened first -- confirmed necessary by
bisection, an empty repro without the write() step did not
reproduce it) used to abort the process outright, not raise a normal
Python exception. Root cause: unload() called close()/deleteLater()
on the panel, which tore its child widgets (the layer combo boxes)
down separately from, and before, the panel itself, leaving an
inconsistent state that crashed the next time something touched a
signal on it. Fixed by having unload() hide() and drop the reference
instead of closing/deleting -- cleanup happens via the normal
parent-child ownership chain (the panel is parented to
iface.mainWindow()) instead of an explicit destroy.

Also covers the _unloaded guard flag directly: layersWillBeRemoved
firing after unload() (from something unrelated to this plugin) must
be a no-op, not an AttributeError against a None self.panel -- this
was a second, related bug found by the same bisection, separate from
the crash above.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from _test_helpers import key_for_subject, wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
zone.dataProvider().addFeatures([zf])

buildings = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "buildings", "memory")
bf = QgsFeature(buildings.fields())
bf.setGeometry(QgsGeometry.fromWkt("POINT(10 10)"))
bf.setAttribute("name", "b0")
buildings.dataProvider().addFeatures([bf])

project.addMapLayers([zone, buildings], False)
for lyr in (zone, buildings):
    project.layerTreeRoot().addLayer(lyr)

print("=" * 70)
print("1. Create a query, save the project, then unload")
print("=" * 70)

plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()
plugin.panel.subject_combo.setLayer(buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)
plugin.panel.createRequested.emit()
key = key_for_subject(plugin, buildings)
ok = wait_for(lambda: key in plugin._queries and plugin._queries[key].engine._task is None, 5.0)
check("query created", ok)

save_path = "/tmp/dsq_unload_crash_regression.qgs"
project.write(save_path)
check("_unloaded flag starts False", plugin._unloaded is False)
plugin.unload()
check("_unloaded flag set True by unload()", plugin._unloaded is True)
check("panel reference dropped", plugin.panel is None)

print()
print("=" * 70)
print("2. project.clear() after unload() must not crash the process")
print("=" * 70)

project.clear()  # this is the exact operation that used to abort the process
check("project.clear() after unload() completed without crashing", True)

print()
print("=" * 70)
print("3. project.read() after unload() must also not crash")
print("=" * 70)

project.read(save_path)
check("project.read() after unload() completed without crashing", True)

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
