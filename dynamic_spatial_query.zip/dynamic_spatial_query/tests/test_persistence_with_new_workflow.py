"""
Confirms the persistence/restoration behavior from earlier turns still
holds now that query creation only happens through the explicit
Create button, not automatically. A query created this way, saved,
reloaded, must still have its real data and resume updating with zero
panel interaction -- same bar as before, just exercised through the
new creation path.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qgis.testing import start_app  # noqa: E402
start_app()

from qgis.PyQt.QtCore import QCoreApplication  # noqa: E402
from qgis.testing.mocked import get_iface  # noqa: E402
from qgis.core import (  # noqa: E402
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)

from dynamic_spatial_query.plugin import DynamicSpatialQueryPlugin  # noqa: E402
from _test_helpers import key_for_subject, wait_for  # noqa: E402

FAILURES = []
def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}" + (f" -- {detail}" if detail and not condition else ""))
    if not condition:
        FAILURES.append(label)


def settle(plugin, key, timeout_s=5.0):
    return wait_for(
        lambda: key in plugin._queries and plugin._queries[key].engine._task is None,
        timeout_s,
    )


iface = get_iface()
project = QgsProject.instance()
project.clear()
project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

zone = QgsVectorLayer("Polygon?crs=EPSG:3857", "zone", "memory")
zf = QgsFeature(zone.fields())
zf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
zone.dataProvider().addFeatures([zf])

buildings = QgsVectorLayer("Point?crs=EPSG:3857&field=name:string", "buildings", "memory")
bf = QgsFeature(buildings.fields())
bf.setGeometry(QgsGeometry.fromWkt("POINT(10 10)"))
bf.setAttribute("name", "b0")
buildings.dataProvider().addFeatures([bf])

project.addMapLayers([zone, buildings], False)
for lyr in (zone, buildings):
    project.layerTreeRoot().addLayer(lyr)

print("=" * 70)
print("1. Create a query through the real button flow")
print("=" * 70)

plugin = DynamicSpatialQueryPlugin(iface)
plugin.initGui()
plugin.panel.subject_combo.setLayer(buildings)
QCoreApplication.processEvents()
plugin.panel.selection_combo.setLayer(zone)
plugin.panel.output_name_edit.setText("buildings_in_zone")
plugin.panel.output_name_edit.editingFinished.emit()
plugin.panel.createRequested.emit()

key = key_for_subject(plugin, buildings)
ok = settle(plugin, key)
check("query created and settled", ok)
check("found the 1 building", plugin._queries[key].engine._output_layer.featureCount() == 1,
      plugin._queries[key].engine._output_layer.featureCount() if plugin._queries[key].engine._output_layer else None)

print()
print("=" * 70)
print("2. Save, reload, and confirm it resumes without any panel interaction")
print("=" * 70)

out_name = plugin._queries[key].engine._output_layer.name()
save_path = "/tmp/dsq_new_workflow_persistence_test.qgs"
project.write(save_path)
plugin.unload()
project.clear()
project.read(save_path)

reloaded_buildings = next(lyr for lyr in project.mapLayers().values() if lyr.name() == "buildings")
reloaded_zone = next(lyr for lyr in project.mapLayers().values() if lyr.name() == "zone")
reloaded_output = next(lyr for lyr in project.mapLayers().values() if lyr.name() == out_name)
check("output layer survived reload with its data", reloaded_output.featureCount() == 1,
      reloaded_output.featureCount())

# memory layers lose their data on reload -- re-seed both source layers
nzf = QgsFeature(reloaded_zone.fields())
nzf.setGeometry(QgsGeometry.fromWkt("POLYGON((0 0,100 0,100 100,0 100,0 0))"))
reloaded_zone.dataProvider().addFeatures([nzf])
nbf = QgsFeature(reloaded_buildings.fields())
nbf.setGeometry(QgsGeometry.fromWkt("POINT(10 10)"))
nbf.setAttribute("name", "b0")
reloaded_buildings.dataProvider().addFeatures([nbf])

plugin2 = DynamicSpatialQueryPlugin(iface)
plugin2.initGui()  # must restore + re-arm without any panel interaction
QCoreApplication.processEvents()

key2 = key_for_subject(plugin2, reloaded_buildings)
check("query restored on load", key2 in plugin2._queries)
check("management table shows the restored query",
      plugin2.panel.query_table.rowCount() == 1, plugin2.panel.query_table.rowCount())

reloaded_buildings.startEditing()
nbf2 = QgsFeature(reloaded_buildings.fields())
nbf2.setGeometry(QgsGeometry.fromWkt("POINT(20 20)"))
nbf2.setAttribute("name", "b1")
reloaded_buildings.addFeature(nbf2)
reloaded_buildings.commitChanges()

ok = wait_for(lambda: plugin2._queries[key2].engine._output_layer.featureCount() == 2, 5.0)
check("restored query updates on its own after an edit, no panel interaction needed", ok,
      plugin2._queries[key2].engine._output_layer.featureCount())

plugin2.unload()

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S):", FAILURES)
    sys.exit(1)
else:
    print("RESULT: ALL CHECKS PASSED")
