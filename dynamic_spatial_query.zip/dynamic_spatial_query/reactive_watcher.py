"""
Watches a set of layers (subject + selection for one query) for
anything that should trigger a recalculation, and emits a single
debounced sourceDataChanged signal. One instance per live query now
(see plugin.py's registry) -- each query watches only its own two
layers, independent of every other query.

Trigger set:

1. In-session edits: each layer's *committed* signals
   (committedFeaturesAdded/Removed/committedGeometriesChanges/
   committedAttributeValuesChanges). Attribute changes are included
   since a layer here can be "the result of a query", and the
   original technical brief explicitly lists attribute changes as a
   trigger.
2. Filter/subset-string changes: QgsVectorLayer.subsetStringChanged,
   for a layer that's "the result of a query" having its filter
   condition edited.
3. Project/group membership: QgsProject.layersRemoved. Note this is
   a coarse "something in the project changed, re-check" signal at
   the per-query level -- the plugin ALSO listens to this same signal
   at a higher level to detect one of ITS OWN watched layers being
   removed and tear the whole query down (see plugin.py), which is a
   different, more specific concern than this class's job.
4. Changes made directly in a PostgreSQL database (another user,
   another program, an SQL script): setListening(True) + the
   provider's notify signal. Automatic by QGIS version -- see
   ENABLE_POSTGRES_LISTEN below. Only hears anything if the source
   table has a `NOTIFY qgis` trigger (see the README).

A separate, independent QTimer (periodic_refresh_timer) can
supplement this with unconditional periodic refresh, matching a
pattern already used elsewhere for a "buffer zones" dynamic layer --
off by default. It catches database changes with no triggers and no
dependency on (4), and is the only way to catch them on QGIS versions
where (4) is switched off.
"""

from qgis.PyQt.QtCore import QObject, QTimer, pyqtSignal
from qgis.core import Qgis, QgsProject

# PostgreSQL LISTEN/NOTIFY -- the same mechanism as QGIS's own Layer
# Properties > Rendering > "Refresh layer on notification" checkbox.
#
#   None  = automatic: on for QGIS versions where QGIS's own bug is
#           fixed, off for versions where it freezes QGIS (default)
#   True  = always on, regardless of version
#   False = always off, regardless of version
#
# Why "automatic by version": older QGIS versions have a bug in QGIS
# ITSELF (not in this plugin) that freezes QGIS forever when listening
# is switched on -- QGIS issue #55707 "Refresh layer on notification
# for postgres layer freezes UI", a duplicate of #54260, fixed by PR
# #55062 "[Postgres] Remove listener wait condition":
#
#     https://github.com/qgis/QGIS/issues/55707
#     https://github.com/qgis/QGIS/pull/55062
#
# Verified by reading QGIS's source (src/providers/postgres/
# qgspostgreslistener.cpp) at each release tag. Up to and including
# 3.34.5 and 3.36.3, QgsPostgresListener::create() blocks the MAIN
# thread on a wait condition while a background thread opens its own
# database connection from the layer's connection string WITHOUT
# expanding a QGIS authentication configuration (authcfg). If that
# connection fails -- reproduced for an auth configuration; possibly
# other setups where the password isn't part of the saved connection,
# not verified -- the background thread asks for
# credentials via QgsCredentialDialog, which reaches back to the main
# thread through a Qt::BlockingQueuedConnection. Both threads then
# wait on each other forever. (A second failure path returns without
# ever waking the main thread at all.) Layer size is irrelevant, which
# is why a 4-feature layer froze. Whether it happens depends on how
# the connection authenticates, which is the likely reason one
# machine on the same QGIS version never froze while others did.
#
# Reproduced in this project's headless test environment (QGIS
# 3.34.4): a layer with user/password written into the connection
# works; the same layer through an authcfg crashes the moment
# listening is switched on (headless has no dialog to deadlock on, so
# it hits a double free in the same failure path instead).
#
# Fixed in 3.38.0 and backported to the 3.34 LTR in 3.34.6: the
# connection is now opened on the calling thread through QGIS's normal
# connection code (auth configs and the password prompt work as they
# do anywhere else) and the wait condition is gone. Confirmed in the
# affected environment on 3.44: both QGIS's own Rendering checkbox and
# this plugin with listening on work without freezing.
ENABLE_POSTGRES_LISTEN = None

# Dynamic property set on a PostgreSQL provider object, counting how
# many of this plugin's watchers currently need it listening. Stored
# on the provider itself (not in a dict keyed by layer id) so the
# count can never go stale: it disappears with the provider, and a
# reloaded project with the same layer ids starts from zero.
_LISTEN_REFS_PROPERTY = "dynamic_spatial_query_listen_refs"


def qgis_has_postgres_listener_fix(version_int=None):
    """True if this QGIS version's PostgreSQL listener no longer has
    the freeze described above. 3.37.x development builds are treated
    as unfixed, since the fix landed partway through that cycle."""
    v = Qgis.QGIS_VERSION_INT if version_int is None else int(version_int)
    if v >= 33800:
        return True
    return 33406 <= v < 33500


def postgres_listen_enabled():
    if ENABLE_POSTGRES_LISTEN is None:
        return qgis_has_postgres_listener_fix()
    return bool(ENABLE_POSTGRES_LISTEN)


def _acquire_listening(provider):
    count = provider.property(_LISTEN_REFS_PROPERTY) or 0
    if count == 0:
        # A no-op inside QGIS if the provider is already listening
        # (e.g. the user ticked the Rendering-tab checkbox themselves).
        provider.setListening(True)
    provider.setProperty(_LISTEN_REFS_PROPERTY, count + 1)


def _qgis_itself_needs_listening(layer):
    """Something in QGIS other than this plugin relies on this layer's
    provider listening: the layer's own "Refresh layer on notification"
    setting, or a layer action triggered by a notification (QGIS's
    QgsActionManager switches listening on for those). QGIS itself
    never switches listening off for this reason -- unticking its own
    checkbox deliberately leaves the provider listening, "because
    someone else could need it (e.g. actions)" (qgsmaplayer.cpp)."""
    if layer.isRefreshOnNotifyEnabled():
        return True
    try:
        return any(action.notificationMessage() for action in layer.actions().actions())
    except (AttributeError, RuntimeError):
        return True  # can't tell -- err on the side of leaving it on


def _release_listening(layer, provider):
    try:
        count = (provider.property(_LISTEN_REFS_PROPERTY) or 0) - 1
        if count > 0:
            provider.setProperty(_LISTEN_REFS_PROPERTY, count)
            return
        provider.setProperty(_LISTEN_REFS_PROPERTY, 0)
        if _qgis_itself_needs_listening(layer):
            return
        # Closes the extra database connection the listener held.
        provider.setListening(False)
    except RuntimeError:
        # Layer or provider already deleted (layer removed, or its
        # data source swapped) -- nothing left to release.
        pass


class ReactiveWatcher(QObject):
    sourceDataChanged = pyqtSignal()

    DEBOUNCE_MS = 400

    def __init__(self, parent=None):
        super().__init__(parent)
        self._connections = []
        # (layer, provider) pairs this watcher switched listening on for
        self._listened = []
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.sourceDataChanged.emit)

        self.periodic_refresh_timer = QTimer(self)
        self.periodic_refresh_timer.timeout.connect(self.sourceDataChanged.emit)

    def watch(self, layers):
        # Acquire listening for the new layer set BEFORE releasing the
        # old one, so re-arming a query on the same layers doesn't close
        # and reopen a database connection each time.
        previously_listened = self._listened
        self._listened = []
        self._disconnect_all()

        listen = postgres_listen_enabled()
        seen_ids = set()
        for layer in layers:
            if layer is None or layer.id() in seen_ids:
                continue
            seen_ids.add(layer.id())

            self._connect(layer.committedFeaturesAdded, self._schedule)
            self._connect(layer.committedFeaturesRemoved, self._schedule)
            self._connect(layer.committedGeometriesChanges, self._schedule)
            self._connect(layer.committedAttributeValuesChanges, self._schedule)
            # Schema changes: a union's output columns come from its
            # inputs' columns, so a field added to or removed from an
            # input should show up in the result without waiting for
            # the next data edit.
            self._connect(layer.committedAttributesAdded, self._schedule)
            self._connect(layer.committedAttributesDeleted, self._schedule)
            self._connect(layer.subsetStringChanged, self._schedule)

            if listen:
                provider = layer.dataProvider()
                if provider is not None and provider.name() == "postgres":
                    _acquire_listening(provider)
                    self._listened.append((layer, provider))
                    self._connect(provider.notify, self._schedule)

        self._connect(QgsProject.instance().layersRemoved, self._schedule)

        for layer, provider in previously_listened:
            _release_listening(layer, provider)

    def stop_watching_layers(self):
        self._disconnect_all()
        for layer, provider in self._listened:
            _release_listening(layer, provider)
        self._listened = []

    def set_periodic_refresh(self, enabled, interval_seconds):
        if enabled:
            self.periodic_refresh_timer.start(interval_seconds * 1000)
        else:
            self.periodic_refresh_timer.stop()

    def stop(self):
        self.stop_watching_layers()
        self.periodic_refresh_timer.stop()

    def _disconnect_all(self):
        for signal, slot in self._connections:
            try:
                signal.disconnect(slot)
            except (TypeError, RuntimeError):
                pass
        self._connections = []
        self._timer.stop()

    def _connect(self, signal, slot):
        signal.connect(slot)
        self._connections.append((signal, slot))

    def _schedule(self, *_args, **_kwargs):
        self._timer.start(self.DEBOUNCE_MS)
