"""
Watches a set of layers (subject + selection for one query) for
anything that should trigger a recalculation, and emits a single
debounced sourceDataChanged signal. One instance per live query now
(see plugin.py's registry) -- each query watches only its own two
layers, independent of every other query.

Trigger set:

1. In-session edits: each layer's *committed* signals
   (committedFeaturesAdded/Removed/committedGeometriesChanges/
   committedAttributeValuesChanges). Attribute changes are included
   since a layer here can be "the result of a query", and the
   original technical brief explicitly lists attribute changes as a
   trigger.
2. Filter/subset-string changes: QgsVectorLayer.subsetStringChanged,
   for a layer that's "the result of a query" having its filter
   condition edited.
3. Project/group membership: QgsProject.layersRemoved. Note this is
   a coarse "something in the project changed, re-check" signal at
   the per-query level -- the plugin ALSO listens to this same signal
   at a higher level to detect one of ITS OWN watched layers being
   removed and tear the whole query down (see plugin.py), which is a
   different, more specific concern than this class's job.
4. Cross-session PostGIS edits: setListening(True) + the provider's
   notify signal -- OFF BY DEFAULT, see ENABLE_POSTGRES_LISTEN below.

A separate, independent QTimer (periodic_refresh_timer) can
supplement this with unconditional periodic refresh, matching a
pattern already used elsewhere for a "buffer zones" dynamic layer --
off by default, and currently the only supported way to catch
cross-session PostgreSQL edits until ENABLE_POSTGRES_LISTEN is
re-enabled (see below).
"""

from qgis.PyQt.QtCore import QObject, QTimer, pyqtSignal
from qgis.core import QgsProject

# Reported: QGIS freezing permanently when using this plugin against
# PostgreSQL-connected layers, even with a tiny (4-feature) table --
# ruling out a slow computation or a large main-thread write as the
# cause. setListening(True)/the notify signal is the least-tested,
# least-standard piece of API surface this touches (compared to the
# very ordinary committed* signals used for every layer type), and
# the timing lines up: it runs synchronously on the main thread,
# BEFORE the background computation even starts, which would explain
# a freeze that a background-thread fix (see spatial_query_engine.py)
# wouldn't touch at all.
#
# Tried directly and could NOT reproduce a hang: isolated
# setListening() calls, the engine running through a real background
# QgsTask, and the complete plugin flow including this exact watch()
# call -- all against a real local PostGIS table. That doesn't clear
# this code path, though -- it just means whatever's wrong likely
# depends on something about the real environment (a remote server,
# a different QGIS build, connection pooling, something else) that
# this sandbox doesn't reproduce.
#
# Given a permanent freeze is a much worse failure mode than "cross-
# session PostgreSQL edits need the periodic timer instead of being
# instant", this is off by default until confirmed either way. Flip
# to True to test whether it's actually the cause, or once that's
# been ruled out and this is confirmed safe.
ENABLE_POSTGRES_LISTEN = False


class ReactiveWatcher(QObject):
    sourceDataChanged = pyqtSignal()

    DEBOUNCE_MS = 400

    def __init__(self, parent=None):
        super().__init__(parent)
        self._connections = []
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.sourceDataChanged.emit)

        self.periodic_refresh_timer = QTimer(self)
        self.periodic_refresh_timer.timeout.connect(self.sourceDataChanged.emit)

    def watch(self, layers):
        self.stop_watching_layers()

        seen_ids = set()
        for layer in layers:
            if layer is None or layer.id() in seen_ids:
                continue
            seen_ids.add(layer.id())

            self._connect(layer.committedFeaturesAdded, self._schedule)
            self._connect(layer.committedFeaturesRemoved, self._schedule)
            self._connect(layer.committedGeometriesChanges, self._schedule)
            self._connect(layer.committedAttributeValuesChanges, self._schedule)
            self._connect(layer.subsetStringChanged, self._schedule)

            if ENABLE_POSTGRES_LISTEN:
                provider = layer.dataProvider()
                if provider is not None and provider.name() == "postgres":
                    provider.setListening(True)
                    self._connect(provider.notify, self._schedule)

        self._connect(QgsProject.instance().layersRemoved, self._schedule)

    def stop_watching_layers(self):
        for signal, slot in self._connections:
            try:
                signal.disconnect(slot)
            except (TypeError, RuntimeError):
                pass
        self._connections = []
        self._timer.stop()

    def set_periodic_refresh(self, enabled, interval_seconds):
        if enabled:
            self.periodic_refresh_timer.start(interval_seconds * 1000)
        else:
            self.periodic_refresh_timer.stop()

    def stop(self):
        self.stop_watching_layers()
        self.periodic_refresh_timer.stop()

    def _connect(self, signal, slot):
        signal.connect(slot)
        self._connections.append((signal, slot))

    def _schedule(self, *_args, **_kwargs):
        self._timer.start(self.DEBOUNCE_MS)
