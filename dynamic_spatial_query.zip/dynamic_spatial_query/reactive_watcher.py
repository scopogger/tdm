"""
Watches a set of layers (subject + selection for one query) for
anything that should trigger a recalculation, and emits a single
debounced sourceDataChanged signal. One instance per live query now
(see plugin.py's registry) -- each query watches only its own two
layers, independent of every other query.

Trigger set:

1. In-session edits: each layer's *committed* signals
   (committedFeaturesAdded/Removed/committedGeometriesChanges/
   committedAttributeValuesChanges). Attribute changes are included
   since a layer here can be "the result of a query", and the
   original technical brief explicitly lists attribute changes as a
   trigger.
2. Filter/subset-string changes: QgsVectorLayer.subsetStringChanged,
   for a layer that's "the result of a query" having its filter
   condition edited.
3. Project/group membership: QgsProject.layersRemoved. Note this is
   a coarse "something in the project changed, re-check" signal at
   the per-query level -- the plugin ALSO listens to this same signal
   at a higher level to detect one of ITS OWN watched layers being
   removed and tear the whole query down (see plugin.py), which is a
   different, more specific concern than this class's job.
4. Cross-session PostGIS edits: setListening(True) + the provider's
   notify signal -- OFF BY DEFAULT, see ENABLE_POSTGRES_LISTEN below.

A separate, independent QTimer (periodic_refresh_timer) can
supplement this with unconditional periodic refresh, matching a
pattern already used elsewhere for a "buffer zones" dynamic layer --
off by default, and currently the only supported way to catch
cross-session PostgreSQL edits until ENABLE_POSTGRES_LISTEN is
re-enabled (see below).
"""

from qgis.PyQt.QtCore import QObject, QTimer, pyqtSignal
from qgis.core import QgsProject

# This is a known, unfixed bug in QGIS ITSELF -- not in this plugin.
# QGIS issue #55707, "Refresh layer on notification for postgres
# layer freezes UI": checking that box in Layer Properties >
# Rendering and hitting Apply freezes QGIS forever, requiring the
# process to be killed. Reported against QGIS 3.26 through 3.34,
# reproduced with a fresh QGIS profile, and reproduced only for
# postgres layers (a GeoPackage layer was tried and did not freeze).
# Closed as "not planned" -- nobody assigned, no fix branch.
#
#     https://github.com/qgis/QGIS/issues/55707
#
# That checkbox does exactly what setListening(True) + the notify
# signal does here -- it's the same provider code path. So the freeze
# reproduces with ZERO plugin code involved, which is both why it
# couldn't be reproduced in this project's headless test environment
# (no Layer Properties UI, different Qt event-loop conditions) and
# why there is no plugin-side fix available: the hang happens inside
# QGIS's own postgres provider before any of this module's code runs.
# A controlled A/B test in the affected environment matched the
# upstream report exactly -- False works, True freezes, everything
# else unchanged.
#
# Kept in the code rather than deleted, in case a future QGIS version
# fixes it (the upstream report predates the version in use here by a
# fair margin, and it was never verified against anything newer than
# 3.34). Anyone re-enabling this should FIRST test QGIS's own
# "Refresh layer on notification" checkbox on their QGIS version: if
# that freezes, this will too, and no amount of plugin-side work will
# change that.
#
# Cross-session PostgreSQL updates do not need this. See the README:
# the per-query periodic refresh timer covers that need with no
# database-side setup and no dependency on this code path at all.
ENABLE_POSTGRES_LISTEN = False


class ReactiveWatcher(QObject):
    sourceDataChanged = pyqtSignal()

    DEBOUNCE_MS = 400

    def __init__(self, parent=None):
        super().__init__(parent)
        self._connections = []
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.sourceDataChanged.emit)

        self.periodic_refresh_timer = QTimer(self)
        self.periodic_refresh_timer.timeout.connect(self.sourceDataChanged.emit)

    def watch(self, layers):
        self.stop_watching_layers()

        seen_ids = set()
        for layer in layers:
            if layer is None or layer.id() in seen_ids:
                continue
            seen_ids.add(layer.id())

            self._connect(layer.committedFeaturesAdded, self._schedule)
            self._connect(layer.committedFeaturesRemoved, self._schedule)
            self._connect(layer.committedGeometriesChanges, self._schedule)
            self._connect(layer.committedAttributeValuesChanges, self._schedule)
            self._connect(layer.subsetStringChanged, self._schedule)

            if ENABLE_POSTGRES_LISTEN:
                provider = layer.dataProvider()
                if provider is not None and provider.name() == "postgres":
                    provider.setListening(True)
                    self._connect(provider.notify, self._schedule)

        self._connect(QgsProject.instance().layersRemoved, self._schedule)

    def stop_watching_layers(self):
        for signal, slot in self._connections:
            try:
                signal.disconnect(slot)
            except (TypeError, RuntimeError):
                pass
        self._connections = []
        self._timer.stop()

    def set_periodic_refresh(self, enabled, interval_seconds):
        if enabled:
            self.periodic_refresh_timer.start(interval_seconds * 1000)
        else:
            self.periodic_refresh_timer.stop()

    def stop(self):
        self.stop_watching_layers()
        self.periodic_refresh_timer.stop()

    def _connect(self, signal, slot):
        signal.connect(slot)
        self._connections.append((signal, slot))

    def _schedule(self, *_args, **_kwargs):
        self._timer.start(self.DEBOUNCE_MS)
