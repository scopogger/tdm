"""
Core computation for the Dynamic Spatial Query plugin.

Mirrors QGIS's own "Extract by Location" tool: given a subject layer
and a selection layer, keep every subject feature that satisfies at
least one of the chosen spatial predicates against at least one
feature in the selection layer (OR across predicates, OR across
selection features -- same semantics as native:extractbylocation).

Both layers' own filters (QgsVectorLayer.setSubsetString() -- "the
layer is itself the result of a query") are respected automatically
and for free: QGIS applies a subset string at the provider level, so
every getFeatures() call here already only sees the filtered rows.
The only extra work needed elsewhere is *reacting* when the filter
itself changes (see reactive_watcher.py).

Unlike a clip/intersection tool, output features keep their ORIGINAL
geometry and ALL of their original attributes, unmodified -- this is
"extract", not "clip". An extra field (see ORIG_FID_FIELD) is added
so results can be traced back to the source feature.

Predicate directions were verified directly against real PyQGIS
before writing this (not assumed from memory) -- see
tests/test_engine.py's predicate-direction checks. subject_geometry
is always the first argument, selection_geometry the second; this
matters for the non-symmetric predicates (Within, Contains).

Output layers are GeoPackage-backed (one .gpkg file per project, one
table per subject layer), not QGIS "memory" layers -- memory layers
never write their feature data into the project file, only their
structure and custom properties, which is exactly the "layers are
empty after reopening QGIS" problem this replaces. See
_output_gpkg_path()/_output_table_name() and tests/test_persistence.py,
which confirms actual data survives a real close-and-reopen via a
fresh QgsVectorLayer object, not just an in-memory reference.

Writes go through a real layer edit session (startEditing() /
addFeatures() / deleteFeatures() / commitChanges()), not straight to
the data provider -- QGIS's "Show Feature Count" legend display (and
anything else listening for committedFeaturesAdded/
committedFeaturesRemoved) only refreshes off those commit signals,
which a provider-level write never fires. See
tests/test_legend_refresh.py.

Internal predicate keys (the PREDICATES dict below, and everything
this module stores/reads as "predicates") are intentionally kept in
English regardless of the UI's display language -- query_panel.py
maps them to Russian labels for display only. This keeps custom
properties written by older versions of this plugin (and any
external tooling that might read them) working unchanged.

Two things borrowed (and adapted) from a colleague's buffer-layer
plugin after reviewing it -- see tests/test_engine.py for both:

- Computation runs on a background QgsTask rather than the main
  thread, following their LoaderTask wrapper's pattern. Only the
  read-only matching (this module's _compute_matches) happens off the
  main thread; writing the output layer happens in the on_finished
  callback instead. A recalculate() call that arrives while one is
  already running doesn't start a second, overlapping task; it's
  remembered and re-run once the in-flight one finishes, discarding
  that one's now-stale result.
- _find_existing_output_layer() detects an output layer left over
  from a previous session via a QgsMapLayer custom property tagged on
  at creation time (their is_buffer_layer() does this by matching a
  fixed set of field names, which doesn't fit here since this
  plugin's output schema mirrors the subject layer's own fields, not
  a fixed shape).

_compute_matches() is passed QgsVectorLayerFeatureSource objects, not
the QgsVectorLayer objects themselves -- this matters a lot, not just
stylistically. QGIS's own docs are explicit that a background task
must never touch a QObject that lives on the main thread, QgsVectorLayer
included, and that doing so "will result in crashes"; the QGIS source
tree has its own fix for exactly this (accessing a layer from a
feature iterator that may run on a background thread) by switching to
QgsVectorLayerFeatureSource, which is what this follows. A real,
serious bug here for a while: calling subject_layer.getFeatures()
directly inside the background task worked fine against memory-
provider layers (which is why it went unnoticed through a lot of
testing against memory layers) but froze the whole QGIS session
against PostgreSQL-backed layers, since libpq connections aren't safe
to use from a thread other than the one they were created on.
QgsVectorLayerFeatureSource must be constructed on the MAIN thread
(recalculate() does this, before dispatching to the background task)
-- that's what makes calling .getFeatures() on it safe from the
background thread afterward.
"""

import json
import os
import uuid

from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsApplication,
    QgsCoordinateTransform,
    QgsCoordinateTransformContext,
    QgsFeature,
    QgsFeatureRequest,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsProject,
    QgsRectangle,
    QgsSpatialIndex,
    QgsTask,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsVectorLayerFeatureSource,
)

PREDICATES = {
    "Intersects": lambda a, b: a.intersects(b),
    "Within": lambda a, b: a.within(b),      # subject lies within the selection feature
    "Contains": lambda a, b: a.contains(b),  # subject contains the selection feature
    "Overlaps": lambda a, b: a.overlaps(b),
    "Touches": lambda a, b: a.touches(b),
    "Equals": lambda a, b: a.equals(b),
    "Crosses": lambda a, b: a.crosses(b),
    "Disjoint": lambda a, b: a.disjoint(b),
}

DEFAULT_PREDICATES = ["Intersects"]

ORIG_FID_FIELD = "__orig_fid"

# Namespace prefix for QgsMapLayer custom properties this plugin
# tags its output layers with -- see _find_existing_output_layer()
# and read_query_definition().
PROPERTY_NAMESPACE = "dynamic_spatial_query"


OUTPUT_GROUP_NAME = "Результаты динамических запросов"

QUERY_TYPE_EXTRACT = "extract"
QUERY_TYPE_UNION = "union"
QUERY_TYPE_DISSOLVE = "dissolve"

# Query types that take a plain list of input layers, and how many each
# needs at minimum.
LAYER_LIST_QUERY_MIN_LAYERS = {QUERY_TYPE_UNION: 2, QUERY_TYPE_DISSOLVE: 1}


def read_query_definition(layer, project):
    """
    Given a layer, checks whether it's one of this plugin's own output
    layers and, if so, reconstructs the query it represents: resolves
    the tagged input layer ids back to live layer objects via the
    project, and reads back everything else that was last written by
    _sync_properties_to_layer().

    Query types (the "query_type" property; an output layer saved
    before that property existed is an extract query):

    - "extract": {"type", "query_id", "subject_layer",
      "selection_layer", "predicates", "output_name"}
    - "union" / "dissolve": {"type", "query_id", "input_layers",
      "output_name"}

    Returns None if `layer` isn't a tagged output layer, or if any
    referenced input layer no longer exists in the project -- there's
    nothing sensible to restore in that case.
    """
    if not layer.customProperty(f"{PROPERTY_NAMESPACE}/is_output", False):
        return None

    # Falls back to a freshly generated id for a project saved by a
    # version of this plugin before query ids existed -- that project
    # still restores correctly, it just gets "migrated" to have a
    # proper query id from here on (written back on the next
    # recalculation, via _sync_properties_to_layer()).
    query_id = layer.customProperty(f"{PROPERTY_NAMESPACE}/query_id") or uuid.uuid4().hex
    output_name = layer.customProperty(f"{PROPERTY_NAMESPACE}/output_name", layer.name())
    query_type = layer.customProperty(f"{PROPERTY_NAMESPACE}/query_type") or QUERY_TYPE_EXTRACT

    if query_type in LAYER_LIST_QUERY_MIN_LAYERS:
        try:
            ids = json.loads(layer.customProperty(f"{PROPERTY_NAMESPACE}/input_layer_ids", "[]"))
        except (TypeError, ValueError):
            return None
        input_layers = [project.mapLayer(i) for i in ids if isinstance(i, str)]
        if len(input_layers) < LAYER_LIST_QUERY_MIN_LAYERS[query_type] or any(l is None for l in input_layers):
            return None
        return {
            "type": query_type,
            "query_id": query_id,
            "input_layers": input_layers,
            "output_name": output_name,
        }

    subject_id = layer.customProperty(f"{PROPERTY_NAMESPACE}/subject_layer_id")
    selection_id = layer.customProperty(f"{PROPERTY_NAMESPACE}/selection_layer_id")
    subject_layer = project.mapLayer(subject_id) if subject_id else None
    selection_layer = project.mapLayer(selection_id) if selection_id else None
    if subject_layer is None or selection_layer is None:
        return None

    predicates_str = layer.customProperty(f"{PROPERTY_NAMESPACE}/predicates", "")
    predicates = [p for p in predicates_str.split(",") if p in PREDICATES]

    return {
        "type": QUERY_TYPE_EXTRACT,
        "query_id": query_id,
        "subject_layer": subject_layer,
        "selection_layer": selection_layer,
        "predicates": predicates or list(DEFAULT_PREDICATES),
        "output_name": output_name,
    }


class LiveOutputEngine:
    """
    Everything a live query needs regardless of WHAT it computes:
    identity (query_id), the output layer and its dedicated GeoPackage
    file, tagging that layer so it can be found again after a reload,
    replacing its contents through a real edit session, and running
    the computation on a background QgsTask with the "one in flight,
    remember one rerun" rule.

    Subclasses supply four things:

    - QUERY_TYPE / TASK_DESCRIPTION
    - watched_layers(): the input layers (the plugin watches these for
      changes, tears the query down if one is removed, and shows their
      names in the management table)
    - _validation_error(): a user-facing message if the query can't run
      as configured, else None
    - _prepare(): runs on the MAIN thread right before dispatch, and
      returns (run, apply). run(task) executes on the background thread
      and returns (payload, error_message_or_None); it must only touch
      objects built inside _prepare() for exactly this purpose (see the
      QgsVectorLayerFeatureSource note in the module docstring), never
      a QgsVectorLayer. apply(payload) runs back on the main thread,
      writes the output layer, and returns the feature count to report.

    And optionally _interrupt_in_flight(), to cut a long-running
    computation short when its result is already known to be stale.
    """

    QUERY_TYPE = None
    TASK_DESCRIPTION = "Dynamic spatial query"

    def __init__(self, iface):
        self.iface = iface
        self.query_id = None
        self.output_name = "query_result"
        self.output_group_name = OUTPUT_GROUP_NAME
        self._output_layer = None

        self._task = None
        self._recalc_pending = False
        self._pending_on_done = None
        self._discard_next_result = False

    # -- subclass hooks ------------------------------------------------

    def watched_layers(self):
        raise NotImplementedError

    def _validation_error(self):
        return None

    def _prepare(self):
        raise NotImplementedError

    def _interrupt_in_flight(self):
        pass

    def _extra_properties(self):
        return {}

    # -- shared API ----------------------------------------------------

    def set_output_name(self, name):
        self.output_name = name or "query_result"
        if self._output_layer is not None:
            self._output_layer.setName(self.output_name)

    def attach_existing_output_layer(self, layer):
        """
        Directly attaches to a layer already known to be this query's
        output (e.g. found by the plugin while restoring queries on
        project load), instead of waiting for the next recalculate()
        to look it up via _find_existing_output_layer(). Safe to call
        redundantly.
        """
        self._output_layer = layer

    def output_gpkg_file_path(self):
        """
        The actual on-disk path of this query's own dedicated output
        file, read back from the output layer's own data source
        rather than recomputed via _output_gpkg_path() -- the
        project's absolutePath() could have changed since the file
        was created (e.g. a Save As), so re-deriving it could point
        at the wrong location. Used by the plugin to delete this
        query's file when the query itself is removed. Returns None
        if there's no output layer yet.
        """
        if self._output_layer is None:
            return None
        return self._output_layer.source().split("|")[0]

    def cancel(self):
        """
        Best-effort cleanup for plugin unload / engine teardown while a
        background computation might still be in flight. Discards the
        result instead of applying it once it does finish, and drops
        any queued rerun.
        """
        self._recalc_pending = False
        self._pending_on_done = None
        if self._task is not None:
            self._discard_next_result = True
            self._interrupt_in_flight()
            self._task.cancel()

    def recalculate(self, on_done=None):
        error = self._validation_error()
        if error:
            if on_done:
                on_done(0, error)
            return

        if self._task is not None:
            self._recalc_pending = True
            self._pending_on_done = on_done
            self._interrupt_in_flight()
            return

        # Everything the background task needs is captured in
        # _prepare(), on the main thread, BEFORE dispatching -- see the
        # module docstring for why that matters.
        run, apply = self._prepare()

        def finished(exception, result=None):
            self._task = None
            discard = self._discard_next_result
            self._discard_next_result = False
            stale = self._recalc_pending

            if not discard and not stale:
                if exception is not None:
                    count, error = 0, str(exception)
                else:
                    payload, error = result
                    count = 0
                    if not error:
                        try:
                            count = apply(payload)
                        except Exception as exc:  # noqa: BLE001 -- report, never crash QGIS
                            count, error = 0, str(exc)
                if on_done:
                    on_done(count, error)

            if self._recalc_pending:
                self._recalc_pending = False
                next_on_done = self._pending_on_done
                self._pending_on_done = None
                self.recalculate(on_done=next_on_done)

        # Silent (added QGIS 3.26): suppresses OS-level notifications
        # on task completion/failure -- without it, at least some QGIS
        # builds (confirmed via a real user report: NextGIS's QGIS
        # distribution, a Windows toast reading "Задача выполнена" /
        # "Dynamic spatial query") surface a popup notification EVERY
        # time a task completes. Since a query recalculates on every
        # source-layer edit, that's a notification per edit -- exactly
        # the "messages keep popping up constantly" complaint. Task
        # still shows in QGIS's own Task Manager panel if the user
        # wants to check progress; this only suppresses the OS popup.
        self._task = QgsTask.fromFunction(
            self.TASK_DESCRIPTION, run, on_finished=finished,
            flags=QgsTask.CanCancel | QgsTask.Silent,
        )
        QgsApplication.taskManager().addTask(self._task)

    # -- output layer plumbing ------------------------------------------

    def _create_output_table(self, project, fields, wkb_type, crs):
        """Creates this query's dedicated GeoPackage table, loads it,
        tags it as one of this plugin's outputs and adds it to the
        results group."""
        gpkg_path = self._output_gpkg_path(project)
        table_name = self._output_table_name()

        save_options = QgsVectorFileWriter.SaveVectorOptions()
        save_options.driverName = "GPKG"
        save_options.layerName = table_name
        save_options.actionOnExistingFile = (
            QgsVectorFileWriter.CreateOrOverwriteLayer if os.path.exists(gpkg_path)
            else QgsVectorFileWriter.CreateOrOverwriteFile
        )
        writer = QgsVectorFileWriter.create(
            gpkg_path, fields, wkb_type, crs, project.transformContext(), save_options
        )
        if writer.hasError():
            raise RuntimeError(f"Could not create output GeoPackage table: {writer.errorMessage()}")
        del writer

        layer = QgsVectorLayer(f"{gpkg_path}|layername={table_name}", self.output_name, "ogr")
        if not layer.isValid():
            raise RuntimeError(f"Created GeoPackage table but QGIS could not load it back: {gpkg_path}")

        layer.setCustomProperty(f"{PROPERTY_NAMESPACE}/is_output", True)

        root = project.layerTreeRoot()
        group = root.findGroup(self.output_group_name)
        if group is None:
            group = root.insertGroup(0, self.output_group_name)
        project.addMapLayer(layer, False)
        group.addLayer(layer)

        self._output_layer = layer
        return layer

    def _replace_features(self, layer, features, schema_change=None):
        """Swaps the output layer's whole contents through a real edit
        session (see module docstring: this is what keeps the legend's
        feature count live). `features` is a list, or a callable taking
        the layer and returning one -- the callable form builds features
        AFTER `schema_change(layer)` (if given) has run inside the same
        edit session, so field indices are already final."""
        if not layer.startEditing():
            raise RuntimeError(f"Could not open an edit session on the output layer {layer.name()!r}")
        existing_ids = [f.id() for f in layer.getFeatures()]
        if existing_ids:
            layer.deleteFeatures(existing_ids)
        if schema_change is not None:
            schema_change(layer)
        if callable(features):
            features = features(layer)
        if features:
            layer.addFeatures(features)
        if not layer.commitChanges():
            errors = layer.commitErrors()
            layer.rollBack()
            raise RuntimeError(f"Failed to save output layer: {'; '.join(errors)}")

        layer.updateExtents()
        layer.triggerRepaint()

    def _output_gpkg_path(self, project):
        # One .gpkg file PER QUERY (named by query_id), not one
        # shared file for the whole project. Found directly, not
        # theorized: creating a second query's output table in a
        # .gpkg file that an earlier query's output layer already had
        # open invalidated that earlier layer's connection --
        # "unable to open database file" errors on a layer that had
        # been working fine moments before. GDAL's SQLite/GeoPackage
        # driver isn't guaranteed to tolerate a second table being
        # added to a file some other still-open QgsVectorLayer is
        # actively using. A dedicated file per query sidesteps the
        # whole class of issue rather than trying to serialize or
        # work around it -- deliberately NOT revisited just because
        # it produces one file per query; that tradeoff is worth
        # keeping over reintroducing a real freeze/crash risk for
        # fewer files on disk. What IS addressed here: putting them
        # in their own subfolder instead of loose alongside the
        # user's other project files, which was the actual complaint
        # (clutter, not the file count itself) -- see also
        # _teardown_query() in plugin.py, which now deletes a query's
        # file when the query itself is removed, so this doesn't grow
        # unbounded across create/delete cycles either.
        if self.query_id is None:
            self.query_id = uuid.uuid4().hex
        filename = f"{self.query_id}.gpkg"
        project_dir = project.absolutePath()
        if project_dir:
            out_dir = os.path.join(project_dir, "dynamic_spatial_query_outputs")
        else:
            out_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "dynamic_spatial_query")
        os.makedirs(out_dir, exist_ok=True)
        return os.path.join(out_dir, filename)

    def _output_table_name(self):
        # A constant, not derived from output_name or query_id --
        # each query has its own dedicated .gpkg file now (see
        # _output_gpkg_path()), so there's nothing for the table name
        # itself to collide with. The layer's DISPLAY name (what the
        # user actually sees, in the legend and the management table)
        # is set separately via layer.setName(self.output_name) in
        # _get_or_create_layer() and is completely unaffected by this.
        return "features"

    def _find_existing_output_layer(self, project):
        # Matches by query_id, not subject_layer_id -- with multiple
        # queries able to share a subject layer, matching by subject
        # alone could reattach to the WRONG query's output.
        if self.query_id is None:
            return None
        for layer in project.mapLayers().values():
            if not layer.customProperty(f"{PROPERTY_NAMESPACE}/is_output", False):
                continue
            if layer.customProperty(f"{PROPERTY_NAMESPACE}/query_id") == self.query_id:
                return layer
        return None

    def _sync_properties_to_layer(self, layer):
        layer.setCustomProperty(f"{PROPERTY_NAMESPACE}/query_id", self.query_id)
        layer.setCustomProperty(f"{PROPERTY_NAMESPACE}/query_type", self.QUERY_TYPE)
        layer.setCustomProperty(f"{PROPERTY_NAMESPACE}/output_name", self.output_name)
        for key, value in self._extra_properties().items():
            layer.setCustomProperty(f"{PROPERTY_NAMESPACE}/{key}", value)

class SpatialQueryEngine(LiveOutputEngine):
    """
    The original query type: "Extract by Location", kept live.

    query_id (set by plugin.py, either freshly generated at creation
    or restored from a tagged output layer) is what a query is
    actually identified by -- NOT its subject layer. Earlier, the
    plugin's registry was keyed by subject_layer_id directly, which
    meant a subject layer could only ever back one query at a time;
    trying to create a second query against an already-used subject
    was refused outright. That wasn't a deliberate rule, just an
    accidental consequence of the keying choice -- there's a
    completely reasonable use case for two independent queries
    sharing the same subject layer against two different selection
    layers. query_id (and the output table naming and reattachment
    logic below, which both switched from subject_layer_id to this)
    is what makes that actually work: every query gets its own
    identity independent of which layers it happens to reference.
    """

    QUERY_TYPE = QUERY_TYPE_EXTRACT
    TASK_DESCRIPTION = "Dynamic spatial query"

    def __init__(self, iface):
        super().__init__(iface)
        self.subject_layer = None
        self.selection_layer = None
        self.predicates = list(DEFAULT_PREDICATES)
        self._orig_fid_field_name = ORIG_FID_FIELD

    def set_subject_layer(self, layer):
        if layer is not self.subject_layer:
            self._output_layer = None
            self.query_id = None  # a genuinely new identity, not the
            # previous subject's query wearing a new subject -- this
            # matters because _find_existing_output_layer() and the
            # output table name are both keyed by query_id now (see
            # class docstring); without this reset, reusing the same
            # engine instance for a different subject would silently
            # reattach to the PREVIOUS subject's output layer instead
            # of creating a fresh one. In normal plugin usage a fresh
            # SpatialQueryEngine is always created per query, so this
            # wouldn't come up there, but it's still the correct
            # engine-level behavior regardless of caller.
        self.subject_layer = layer

    def set_selection_layer(self, layer):
        self.selection_layer = layer

    def set_predicates(self, predicate_names):
        """
        Deliberately does NOT fall back to a default when given an
        empty list -- a genuinely empty selection has to stay empty
        so recalculate()'s "select at least one predicate" check
        actually has something to catch. An earlier version silently
        substituted DEFAULT_PREDICATES here, which meant unchecking
        every predicate checkbox in the panel had no visible effect
        at all instead of being refused the way QGIS's own Extract by
        Location refuses to run with none selected.
        """
        self.predicates = [p for p in predicate_names if p in PREDICATES]

    def watched_layers(self):
        return [l for l in (self.subject_layer, self.selection_layer) if l is not None]

    def attach_existing_output_layer(self, layer):
        super().attach_existing_output_layer(layer)
        self._orig_fid_field_name = layer.customProperty(
            f"{PROPERTY_NAMESPACE}/orig_fid_field", ORIG_FID_FIELD
        )

    def _validation_error(self):
        if self.subject_layer is None or self.selection_layer is None:
            return "Выберите оба слоя — целевой и слой выборки."
        if not self.predicates:
            return "Выберите хотя бы один геометрический предикат."
        return None

    def _prepare(self):
        # subject_layer.getFeatures() or selection_layer.getFeatures()
        # must never be called directly inside run() below -- only the
        # QgsVectorLayerFeatureSource objects built here.
        subject_layer = self.subject_layer
        selection_layer = self.selection_layer
        predicates = list(self.predicates)
        subject_crs = subject_layer.crs()
        selection_crs = selection_layer.crs()
        same_layer = subject_layer.id() == selection_layer.id()
        transform_context = QgsProject.instance().transformContext()
        subject_source = QgsVectorLayerFeatureSource(subject_layer)
        selection_source = QgsVectorLayerFeatureSource(selection_layer)

        def run(_task):
            return self._compute_matches(
                subject_source, selection_source, subject_crs, selection_crs,
                same_layer, transform_context, predicates,
            )

        def apply(matches):
            self._write_output(matches)
            return len(matches)

        return run, apply

    def _extra_properties(self):
        return {
            "subject_layer_id": self.subject_layer.id(),
            "selection_layer_id": self.selection_layer.id(),
            "predicates": ",".join(self.predicates),
        }

    # -- internals ----------------------------------------------------

    def _compute_matches(self, subject_source, selection_source, subject_crs, selection_crs,
                          same_layer, transform_context, predicates):
        """
        Runs on a background thread. Must not touch QgsProject, the
        layer tree, QgsVectorLayer itself, or create/add any layer --
        only reads features via the passed QgsVectorLayerFeatureSource
        objects (safe: constructed on the main thread before this
        task was dispatched) and tests QgsGeometry predicates. Returns
        (matches, error_message_or_None).
        """
        try:
            transform = None
            if selection_crs != subject_crs:
                transform = QgsCoordinateTransform(selection_crs, subject_crs, transform_context)

            index = QgsSpatialIndex()
            selection_geoms = {}
            combined_bbox = QgsRectangle()
            combined_bbox.setMinimal()
            for feat in selection_source.getFeatures():
                geom = feat.geometry()
                if geom is None or geom.isEmpty():
                    continue
                if transform is not None:
                    geom = QgsGeometry(geom)
                    geom.transform(transform)
                selection_geoms[feat.id()] = geom
                combined_bbox.combineExtentWith(geom.boundingBox())
                idx_feat = QgsFeature(feat.id())
                idx_feat.setGeometry(geom)
                index.addFeature(idx_feat)

            if not selection_geoms:
                return [], None

            # Disjoint means "not matching ANY selection feature", so a
            # match is typically OUTSIDE the selection layer's combined
            # bounding box -- the opposite of what the prefilter below
            # assumes -- and has to be checked against the WHOLE
            # selection layer, not stop at the first candidate. So:
            # skip the bbox prefilter entirely whenever Disjoint is
            # chosen (falls back to a full subject-layer scan).
            existential_predicates = [p for p in predicates if p != "Disjoint"]
            want_disjoint = "Disjoint" in predicates

            if want_disjoint:
                request = QgsFeatureRequest()
            else:
                request = QgsFeatureRequest().setFilterRect(combined_bbox)

            matches = []
            for subject_feat in subject_source.getFeatures(request):
                subject_geom = subject_feat.geometry()
                if subject_geom is None or subject_geom.isEmpty():
                    continue
                candidate_ids = [
                    fid for fid in index.intersects(subject_geom.boundingBox())
                    if not (same_layer and fid == subject_feat.id())
                ]

                is_match = False
                if existential_predicates:
                    for sel_fid in candidate_ids:
                        sel_geom = selection_geoms[sel_fid]
                        if any(PREDICATES[p](subject_geom, sel_geom) for p in existential_predicates):
                            is_match = True
                            break
                if not is_match and want_disjoint:
                    is_match = all(subject_geom.disjoint(selection_geoms[fid]) for fid in candidate_ids)

                if is_match:
                    matches.append(subject_feat)

            return matches, None
        except Exception as exc:
            return [], str(exc)

    def _write_output(self, matches):
        project = QgsProject.instance()
        layer = self._get_or_create_layer(project)
        self._sync_properties_to_layer(layer)

        # Only the subject fields the output table actually has: its
        # columns are fixed when it's created, and a field added to the
        # subject layer afterwards used to make every recalculation fail
        # (setAttribute() on an unknown name raises).
        output_fields = layer.fields()
        copied_names = [
            field.name() for field in self.subject_layer.fields()
            if output_fields.indexOf(field.name()) >= 0
        ]
        features = []
        for feat in matches:
            f = QgsFeature(output_fields)
            f.setGeometry(QgsGeometry(feat.geometry()))
            for name in copied_names:
                f.setAttribute(name, feat.attribute(name))
            f.setAttribute(self._orig_fid_field_name, feat.id())
            features.append(f)

        self._replace_features(layer, features)

    def _get_or_create_layer(self, project):
        if self._output_layer is not None:
            return self._output_layer

        existing = self._find_existing_output_layer(project)
        if existing is not None:
            self.attach_existing_output_layer(existing)
            return existing

        self._orig_fid_field_name = self._pick_orig_fid_field_name()
        fields = QgsFields()
        for field in self.subject_layer.fields():
            fields.append(field)
        fields.append(QgsField(self._orig_fid_field_name, QVariant.LongLong))

        layer = self._create_output_table(
            project, fields, self.subject_layer.wkbType(), self.subject_layer.crs()
        )
        layer.setCustomProperty(f"{PROPERTY_NAMESPACE}/orig_fid_field", self._orig_fid_field_name)
        self._sync_properties_to_layer(layer)
        return layer

    def _pick_orig_fid_field_name(self):
        existing = {f.name() for f in self.subject_layer.fields()}
        name = ORIG_FID_FIELD
        n = 1
        while name in existing:
            name = f"{ORIG_FID_FIELD}_{n}"
            n += 1
        return name
