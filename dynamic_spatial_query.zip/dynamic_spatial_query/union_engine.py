"""
Live «Объединение» (Union): QGIS's own Vector overlay > Union
algorithm (native:union), chained over two or more polygon layers,
kept up to date the same way as an extract-by-location query.

This reproduces section I of the tester's written procedure (building
the combined ООПТ_ТТП_ВОЗ_ИКН layer): union the first two layers, then
union that result with the third, and so on. Using QGIS's own
algorithm rather than reimplementing it means the result is exactly
what QGIS's «Объединение» dialog produces:

- Where layers overlap, the overlap becomes its own feature carrying
  the attributes of every layer covering it; non-overlapping parts
  keep their own layer's attributes, with NULLs for the rest. So the
  result covers the same area as the inputs combined, with no
  overlapping features -- which is what stops a later length/area
  calculation (e.g. "pipeline length inside protected areas") from
  counting the same stretch twice.
- Duplicate field names get QGIS's own suffixes: name, name_2, name_3.
- Input features with invalid geometry are skipped, matching the
  "Пропускать (игнорировать) объекты с некорректными геометриями"
  setting the tester's procedure applies in every tool. How many were
  skipped is reported back so it isn't silent.

Two deliberate differences from running the dialog by hand:

- A field literally named "fid" (every GeoPackage-backed input has
  one) is renamed to fid_1 in the output. A GeoPackage output table
  has its OWN "fid" primary key column, and the union result repeats
  input fids (an input feature split into several pieces keeps its
  fid on each), which a primary key can't hold. The tester's
  procedure works around the same clash by hand ("выбрать все поля
  кроме fid").
- Field order follows the order of the layers as listed in the panel
  (alphabetical), not the order they were picked.

Threading follows the same rule as the extract engine (see
spatial_query_engine.py's module docstring): input layers are only
read through QgsVectorLayerFeatureSource objects built on the main
thread. The background task copies those features into memory layers
it creates itself, runs native:union on those inside its own
QgsProcessingContext, and hands plain QgsFeature/QgsFields values back.
No QgsVectorLayer from the project is touched off the main thread.
"""

import json

from qgis.core import (
    Qgis,
    QgsApplication,
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureRequest,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsMemoryProviderUtils,
    QgsProcessing,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsProject,
    QgsVectorLayer,
    QgsVectorLayerFeatureSource,
    QgsWkbTypes,
)

from .spatial_query_engine import QUERY_TYPE_UNION, LiveOutputEngine

UNION_ALGORITHM_ID = "native:union"
CANCELED = "__canceled__"


def ensure_union_algorithm():
    """True if native:union can be used. QGIS Desktop registers the
    native algorithm provider at startup; a bare PyQGIS environment
    (like this plugin's test suite) doesn't, so register it if it's
    missing."""
    registry = QgsApplication.processingRegistry()
    if registry.algorithmById(UNION_ALGORITHM_ID) is None:
        try:
            from qgis.analysis import QgsNativeAlgorithms
            registry.addProvider(QgsNativeAlgorithms())
        except Exception:  # noqa: BLE001
            pass
    return registry.algorithmById(UNION_ALGORITHM_ID) is not None


def _skip_invalid_check():
    # Qgis.InvalidGeometryCheck exists from QGIS 3.36; older versions
    # only have the QgsFeatureRequest enum.
    try:
        return Qgis.InvalidGeometryCheck.SkipInvalid
    except AttributeError:
        return QgsFeatureRequest.GeometrySkipInvalid


try:
    _POLYGON_GEOMETRY = Qgis.GeometryType.Polygon  # QGIS 3.30+
except AttributeError:
    _POLYGON_GEOMETRY = QgsWkbTypes.PolygonGeometry


def is_polygon_layer(layer):
    try:
        return isinstance(layer, QgsVectorLayer) and layer.geometryType() == _POLYGON_GEOMETRY
    except RuntimeError:
        return False


def gpkg_safe_fields(fields):
    """Copy of `fields` with any field named "fid" (any case) renamed
    to a free fid_1, fid_1_1, ... -- see module docstring."""
    taken = {f.name().lower() for f in fields}
    out = QgsFields()
    for field in fields:
        if field.name().lower() == "fid":
            name = "fid_1"
            while name.lower() in taken:
                name += "_1"
            taken.add(name.lower())
            renamed = QgsField(field)
            renamed.setName(name)
            out.append(renamed)
        else:
            out.append(QgsField(field))
    return out


def compute_union(inputs, algorithms, transform_context, feedback):
    """
    Runs on a background thread. `inputs` is a list of
    (QgsVectorLayerFeatureSource, QgsFields, wkbType, crs) built on the
    main thread; `algorithms` holds one native:union instance per
    union step (len(inputs) - 1), also created on the main thread.

    Returns ((fields, wkb_type, crs, features, skipped_invalid), None)
    on success, (None, CANCELED) if cancelled, (None, message) on
    failure.
    """
    context = None
    copies = []
    current = None
    try:
        skip_invalid = _skip_invalid_check()
        context = QgsProcessingContext()
        context.setTransformContext(transform_context)
        # Intermediate union results can (rarely) contain invalid
        # pieces too; skip those the same way.
        context.setInvalidGeometryCheck(skip_invalid)

        skipped_invalid = 0
        for i, (source, fields, wkb_type, crs) in enumerate(inputs):
            memory_layer = QgsMemoryProviderUtils.createMemoryLayer(f"union_input_{i}", fields, wkb_type, crs)
            features = []
            for feature in source.getFeatures():
                if feedback.isCanceled():
                    return None, CANCELED
                geometry = feature.geometry()
                if geometry is not None and not geometry.isNull() and not geometry.isGeosValid():
                    skipped_invalid += 1
                    continue
                features.append(feature)
            memory_layer.dataProvider().addFeatures(features)
            copies.append(memory_layer)

        current = copies[0]
        for algorithm, overlay in zip(algorithms, copies[1:]):
            parameters = {
                "INPUT": current,
                "OVERLAY": overlay,
                "OUTPUT": QgsProcessing.TEMPORARY_OUTPUT,
            }
            results, ok = algorithm.run(parameters, context, feedback)
            if feedback.isCanceled():
                return None, CANCELED
            if not ok or not results or "OUTPUT" not in results:
                return None, "Не удалось выполнить «Объединение» (native:union)."
            current = context.getMapLayer(results["OUTPUT"])
            if current is None:
                return None, "Не удалось прочитать результат «Объединения»."

        fields = QgsFields(current.fields())
        wkb_type = current.wkbType()
        crs = current.crs()
        features = [QgsFeature(f) for f in current.getFeatures()]
        return (fields, wkb_type, crs, features, skipped_invalid), None
    except Exception as exc:  # noqa: BLE001 -- reported to the user, never crashes QGIS
        return None, str(exc)
    finally:
        # Release the temporary layers HERE, on the thread that created
        # them, even if an exception traceback is still holding this
        # frame alive.
        current = None
        copies = None
        context = None


class UnionQueryEngine(LiveOutputEngine):
    QUERY_TYPE = QUERY_TYPE_UNION
    TASK_DESCRIPTION = "Dynamic union"

    def __init__(self, iface):
        super().__init__(iface)
        self.input_layers = []
        self.last_skipped_invalid = 0
        self._feedback = None

    def set_input_layers(self, layers):
        self.input_layers = [layer for layer in layers if layer is not None]

    def watched_layers(self):
        return list(self.input_layers)

    def _validation_error(self):
        if len(self.input_layers) < 2:
            return "Выберите хотя бы два полигональных слоя для объединения."
        if not all(is_polygon_layer(layer) for layer in self.input_layers):
            return "Объединять можно только полигональные слои."
        if not ensure_union_algorithm():
            return "Алгоритм «Объединение» (native:union) недоступен в этой сборке QGIS."
        return None

    def _interrupt_in_flight(self):
        # A union of large layers can take a while; when its inputs
        # change again mid-run, its result is already stale, so stop it
        # rather than wait for it to finish.
        if self._feedback is not None:
            self._feedback.cancel()

    def _prepare(self):
        inputs = [
            (QgsVectorLayerFeatureSource(layer), QgsFields(layer.fields()), layer.wkbType(), layer.crs())
            for layer in self.input_layers
        ]
        registry = QgsApplication.processingRegistry()
        algorithms = [registry.createAlgorithmById(UNION_ALGORITHM_ID) for _ in range(len(inputs) - 1)]
        transform_context = QgsProject.instance().transformContext()
        feedback = QgsProcessingFeedback()
        self._feedback = feedback

        def run(_task):
            return compute_union(inputs, algorithms, transform_context, feedback)

        def apply(payload):
            fields, wkb_type, crs, features, skipped_invalid = payload
            self._write_output(fields, wkb_type, crs, features)
            self.last_skipped_invalid = skipped_invalid
            return len(features)

        return run, apply

    def _extra_properties(self):
        return {"input_layer_ids": json.dumps([layer.id() for layer in self.input_layers])}

    # -- writing ----------------------------------------------------------

    def _write_output(self, fields, wkb_type, crs, features):
        project = QgsProject.instance()
        out_fields = gpkg_safe_fields(fields)

        layer = self._output_layer
        if layer is None:
            layer = self._find_existing_output_layer(project)
            if layer is not None:
                self.attach_existing_output_layer(layer)
        if layer is None:
            layer = self._create_output_table(project, out_fields, wkb_type, crs)
        self._sync_properties_to_layer(layer)

        transform = None
        if crs.isValid() and layer.crs().isValid() and crs != layer.crs():
            transform = QgsCoordinateTransform(crs, layer.crs(), project.transformContext())

        def sync_schema(target):
            # Input layers can gain or lose fields after the query was
            # created; match the output's columns to the new result
            # (by name -- GeoPackage stores some types differently from
            # the source, so comparing types would rebuild columns on
            # every run). The table's own primary key is never touched.
            wanted = {f.name() for f in out_fields}
            pk = set(target.primaryKeyAttributes())
            current_fields = target.fields()
            for idx in sorted(range(current_fields.count()), reverse=True):
                if idx in pk:
                    continue
                if current_fields.at(idx).name() not in wanted:
                    target.deleteAttribute(idx)
            existing = {f.name() for f in target.fields()}
            for field in out_fields:
                if field.name() not in existing:
                    target.addAttribute(QgsField(field))

        def build(target):
            target_fields = target.fields()
            index_map = [target_fields.indexOf(f.name()) for f in out_fields]
            built = []
            for source_feature in features:
                feature = QgsFeature(target_fields)
                geometry = QgsGeometry(source_feature.geometry())
                if transform is not None and not geometry.isNull():
                    geometry.transform(transform)
                feature.setGeometry(geometry)
                for source_index, target_index in enumerate(index_map):
                    if target_index >= 0:
                        feature.setAttribute(target_index, source_feature.attribute(source_index))
                built.append(feature)
            return built

        self._replace_features(layer, build, schema_change=sync_schema)
