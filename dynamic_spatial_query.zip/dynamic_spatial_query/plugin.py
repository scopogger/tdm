"""
Main plugin class. QGIS instantiates this once (via classFactory in
__init__.py) and calls initGui() on load, unload() on unload.

Nothing is created just by picking layers in the panel -- creating a
query (a real output GeoPackage table, added to the project, with a
watcher armed) only happens when the user explicitly clicks "Создать"
(Create). Four distinct, always-visible buttons drive this rather
than one relabeled button -- see query_panel.py's module docstring
for why that changed.

Keeps one independent, always-live query PER DISTINCT SUBJECT LAYER
(self._queries) once created. Every registered query also survives a
project reload -- and, separately, survives *switching* to a
different project within the same running QGIS session: initGui()
restores whatever the project holds at plugin-load time, and
QgsProject.readProject additionally re-syncs every time a project is
subsequently opened, since that's a distinct event from plugin load
(a real gap found and fixed this round -- initGui() alone only ever
saw whatever project was open at the moment the plugin was loaded,
typically an empty one, not whatever the user opens afterward).

A query can be removed two equivalent ways: the panel's "Удалить"
button, or deleting its output layer from QGIS's own Layers panel --
both tear the query down via _teardown_query(). Deleting a query's
subject or selection layer instead also tears it down (it can't
function without them), leaving its last-computed output layer in
place rather than also deleting it. Cleanup is wired to
layersWillBeRemoved (fires while the layer is still valid), not
layersRemoved (fires after -- confirmed directly that touching a
layer reference at that point, including just to disconnect a
watcher's signals from it, segfaults rather than raising a normal
Python exception).

A query's own selection layer can never be set to its own output
layer (a direct self-reference that would feed each recalculation off
its own previous result instead of a stable source) -- proactively
excluded from the selection combo's choices, not just rejected after
the fact.
"""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QAction, QStyle
from qgis.core import QgsProject

from .query_panel import QueryPanel
from .reactive_watcher import ReactiveWatcher
from .spatial_query_engine import SpatialQueryEngine, read_query_definition

ACTION_MENU_TEXT = "&Динамический пространственный запрос"
ACTION_TOOLBAR_TEXT = "Динамический пространственный запрос"


class _LiveQuery:
    """One subject layer's worth of engine + watcher, plus its own
    independent auto-update/periodic-refresh settings."""

    def __init__(self, iface):
        self.engine = SpatialQueryEngine(iface)
        self.watcher = ReactiveWatcher()
        self.auto_update = True
        self.periodic_enabled = False
        self.periodic_seconds = 30


class DynamicSpatialQueryPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.panel = None
        self._queries = {}        # subject_layer_id -> _LiveQuery, ONLY for created queries
        self._current_key = None  # which query/draft the panel is presently showing

    def initGui(self):
        icon = self.iface.mainWindow().style().standardIcon(QStyle.SP_DialogApplyButton)
        self.action = QAction(icon, ACTION_TOOLBAR_TEXT, self.iface.mainWindow())
        self.action.setCheckable(True)
        self.action.triggered.connect(self._toggle_panel)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(ACTION_MENU_TEXT, self.action)

        self.panel = QueryPanel(self.iface)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.panel)
        self.panel.hide()
        self.panel.visibilityChanged.connect(self.action.setChecked)

        self.panel.subjectLayerChanged.connect(self._on_subject_changed)
        self.panel.selectionLayerChanged.connect(self._on_selection_changed)
        self.panel.predicatesChanged.connect(self._on_predicates_changed)
        self.panel.outputNameChanged.connect(self._on_output_name_changed)
        self.panel.autoUpdateToggled.connect(self._on_auto_update_toggled)
        self.panel.periodicRefreshChanged.connect(self._on_periodic_refresh_changed)
        self.panel.newQueryRequested.connect(self._on_new_query_requested)
        self.panel.createRequested.connect(self._on_create_requested)
        self.panel.recalculateRequested.connect(self._on_recalculate_requested)
        self.panel.removeRequested.connect(self._on_remove_requested)
        self.panel.queryRowSelected.connect(self._on_query_row_selected)

        QgsProject.instance().layersWillBeRemoved.connect(self._on_layers_will_be_removed)
        QgsProject.instance().readProject.connect(self._on_project_read)

        self._sync_with_current_project()

    def unload(self):
        self.iface.removePluginMenu(ACTION_MENU_TEXT, self.action)
        self.iface.removeToolBarIcon(self.action)
        for signal, slot in (
            (QgsProject.instance().layersWillBeRemoved, self._on_layers_will_be_removed),
            (QgsProject.instance().readProject, self._on_project_read),
        ):
            try:
                signal.disconnect(slot)
            except (TypeError, RuntimeError):
                pass
        for query in self._queries.values():
            query.watcher.stop()
            query.engine.cancel()
        if self.panel is not None:
            # deleteLater() is asynchronous -- disconnect explicitly
            # first so unload() actually means "deaf to everything"
            # immediately, not eventually.
            for signal, slot in (
                (self.panel.subjectLayerChanged, self._on_subject_changed),
                (self.panel.selectionLayerChanged, self._on_selection_changed),
                (self.panel.predicatesChanged, self._on_predicates_changed),
                (self.panel.outputNameChanged, self._on_output_name_changed),
                (self.panel.autoUpdateToggled, self._on_auto_update_toggled),
                (self.panel.periodicRefreshChanged, self._on_periodic_refresh_changed),
                (self.panel.newQueryRequested, self._on_new_query_requested),
                (self.panel.createRequested, self._on_create_requested),
                (self.panel.recalculateRequested, self._on_recalculate_requested),
                (self.panel.removeRequested, self._on_remove_requested),
                (self.panel.queryRowSelected, self._on_query_row_selected),
            ):
                signal.disconnect(slot)
            self.iface.removeDockWidget(self.panel)
            self.panel.deleteLater()
            self.panel = None

    # -- syncing with whatever project is currently open -------------------

    def _sync_with_current_project(self):
        """Shared by initGui() (whatever's open when the plugin loads)
        and _on_project_read() (whenever a project is subsequently
        opened in the same running QGIS session -- a distinct event
        from plugin load; see module docstring)."""
        self._restore_existing_queries()
        self._current_key = None
        # Baseline first (also picks a fresh suggested name), then let
        # _on_subject_changed override it below if the auto-selected
        # layer turns out to already have a query -- covers the common
        # real case where QgsMapLayerComboBox auto-selects an existing
        # layer the moment the panel is built, which used to leave the
        # output name stuck on the widget's original constructor
        # default instead of ever getting a suggested name at all.
        self.panel.clear_draft(self._suggest_new_query_name())
        initial_subject = self.panel.subject_layer()
        if initial_subject is not None:
            self._on_subject_changed(initial_subject)
        else:
            self.panel.set_create_enabled(True)
            self.panel.set_recalculate_enabled(False)
            self.panel.set_remove_enabled(False)
        self._refresh_query_table()

    def _on_project_read(self, _doc=None):
        self._sync_with_current_project()

    def _restore_existing_queries(self):
        project = QgsProject.instance()
        for layer in list(project.mapLayers().values()):
            definition = read_query_definition(layer, project)
            if definition is None:
                continue
            query = self._register_query(definition["subject_layer"])
            query.engine.set_selection_layer(definition["selection_layer"])
            query.engine.set_predicates(definition["predicates"])
            query.engine.set_output_name(definition["output_name"])
            query.engine.attach_existing_output_layer(layer)
            self._arm_watcher(query)  # resume updating; the output layer's
            # data is already correct as of last save, no need to recalculate.

    # -- UI callbacks --------------------------------------------------

    def _toggle_panel(self, checked):
        self.panel.setVisible(checked)

    def _on_subject_changed(self, layer):
        if layer is None:
            self._current_key = None
            self.panel.set_create_enabled(False)
            self.panel.set_recalculate_enabled(False)
            self.panel.set_remove_enabled(False)
            return

        key = layer.id()
        query = self._queries.get(key)
        self._current_key = key

        if query is not None:
            self.panel.load_query_state(
                query.engine.selection_layer,
                query.engine.predicates,
                query.engine.output_name,
                query.auto_update,
                query.periodic_enabled,
                query.periodic_seconds,
            )
            output_layer = query.engine._output_layer
            self.panel.set_selection_exceptions([output_layer] if output_layer is not None else [])
            self.panel.set_create_enabled(False)
            self.panel.set_recalculate_enabled(True)
            self.panel.set_remove_enabled(True)
        else:
            # Brand new subject with no query yet -- leave whatever the
            # panel's other controls currently show untouched (a
            # reasonable starting point for defining several similar
            # queries in a row); just update button state.
            self.panel.set_selection_exceptions([])
            self.panel.set_create_enabled(True)
            self.panel.set_recalculate_enabled(False)
            self.panel.set_remove_enabled(False)
        self.panel.select_table_row_for_key(key if query is not None else None)

    def _on_selection_changed(self, layer):
        query = self._current_query()
        if query is None or layer is None:
            return  # still just editing a draft, nothing registered to update yet
        if query.engine._output_layer is not None and layer.id() == query.engine._output_layer.id():
            # Backstop behind the combo's own exclusion list (belt and
            # braces -- e.g. if something ever sets this layer
            # programmatically instead of through the widget).
            self.panel.set_status("Слой-результат этого запроса нельзя выбрать в качестве слоя выборки для него же.")
            self.panel.load_query_state(
                query.engine.selection_layer, query.engine.predicates, query.engine.output_name,
                query.auto_update, query.periodic_enabled, query.periodic_seconds,
            )
            return
        query.engine.set_selection_layer(layer)
        self._arm_watcher(query)
        self._trigger_current_recalculation()

    def _on_predicates_changed(self, predicates):
        query = self._current_query()
        if query is None:
            return
        query.engine.set_predicates(predicates)
        self._trigger_current_recalculation()

    def _on_output_name_changed(self, name):
        query = self._current_query()
        if query is None:
            return
        query.engine.set_output_name(name)
        self._refresh_query_table()

    def _on_auto_update_toggled(self, enabled):
        query = self._current_query()
        if query is None:
            return
        query.auto_update = enabled
        self._arm_watcher(query)
        self._refresh_query_table()

    def _on_periodic_refresh_changed(self, enabled, seconds):
        query = self._current_query()
        if query is None:
            return
        query.periodic_enabled = enabled
        query.periodic_seconds = seconds
        query.watcher.set_periodic_refresh(enabled, seconds)

    def _on_new_query_requested(self):
        self._current_key = None
        self.panel.clear_draft(self._suggest_new_query_name())
        self.panel.set_create_enabled(True)
        self.panel.set_recalculate_enabled(False)
        self.panel.set_remove_enabled(False)
        self.panel.set_status("Готово")
        self.panel.select_table_row_for_key(None)

    def _on_create_requested(self):
        query = self._current_query()
        if query is not None:
            return  # Create is disabled in this state anyway; ignore stray signals
        self._create_query_from_panel()

    def _on_recalculate_requested(self):
        query = self._current_query()
        if query is None:
            return  # Recalculate is disabled in this state anyway
        self._trigger_current_recalculation()

    def _on_remove_requested(self):
        if self._current_key is None:
            return
        self._teardown_query(self._current_key, delete_output_layer=True)
        self._current_key = None
        self.panel.clear_draft(self._suggest_new_query_name())
        self.panel.set_create_enabled(True)
        self.panel.set_recalculate_enabled(False)
        self.panel.set_remove_enabled(False)
        self.panel.set_status("Готово")
        self._refresh_query_table()

    def _on_query_row_selected(self, key):
        query = self._queries.get(key)
        if query is None or query.engine.subject_layer is None:
            return
        # Reuses the existing subject-combo-change flow to load this
        # query's state, rather than duplicating that logic here.
        self.panel.subject_combo.setLayer(query.engine.subject_layer)

    def _on_layers_will_be_removed(self, layer_ids):
        removed = set(layer_ids)
        for key, query in list(self._queries.items()):
            ids = set()
            if query.engine.subject_layer is not None:
                ids.add(query.engine.subject_layer.id())
            if query.engine.selection_layer is not None:
                ids.add(query.engine.selection_layer.id())
            if query.engine._output_layer is not None:
                ids.add(query.engine._output_layer.id())
            if ids & removed:
                self._teardown_query(key, delete_output_layer=False)
        if self._current_key is not None and self._current_key not in self._queries:
            self._current_key = None
            self.panel.set_create_enabled(True)
            self.panel.set_recalculate_enabled(False)
            self.panel.set_remove_enabled(False)
        self._refresh_query_table()

    # -- creating / removing / registry plumbing ------------------------

    def _create_query_from_panel(self):
        subject = self.panel.subject_layer()
        selection = self.panel.selection_layer()
        if subject is None or selection is None:
            self.panel.set_status("Выберите оба слоя — целевой и слой выборки.")
            return
        predicates = self.panel.selected_predicates()
        if not predicates:
            # Checked before ever registering anything -- QGIS's own
            # Extract by Location refuses to run under the same
            # condition (worded there as a parameter-validation error;
            # this is meant to read more plainly). Without this check,
            # set_predicates([]) would leave a query registered with
            # nothing to compute, showing an error status forever
            # instead of never having been created.
            self.panel.set_status("Выберите хотя бы один геометрический предикат.")
            return

        query = self._register_query(subject)
        query.engine.set_selection_layer(selection)
        query.engine.set_predicates(predicates)
        query.engine.set_output_name(self.panel.output_name())

        self._current_key = subject.id()
        self.panel.set_create_enabled(False)
        self.panel.set_recalculate_enabled(True)
        self.panel.set_remove_enabled(True)
        self._arm_watcher(query)
        self._trigger_current_recalculation()
        self._refresh_query_table()
        self.panel.select_table_row_for_key(self._current_key)

    def _teardown_query(self, key, delete_output_layer):
        query = self._queries.pop(key, None)
        if query is None:
            return
        query.watcher.stop()
        query.engine.cancel()
        if delete_output_layer and query.engine._output_layer is not None:
            QgsProject.instance().removeMapLayer(query.engine._output_layer.id())

    def _register_query(self, subject_layer):
        """Adds subject_layer to the registry if it isn't there yet
        (used by both restoration and fresh creation); does NOT touch
        selection/predicates/output name -- the caller sets those."""
        key = subject_layer.id()
        query = self._queries.get(key)
        if query is None:
            query = _LiveQuery(self.iface)
            query.engine.set_subject_layer(subject_layer)
            query.watcher.sourceDataChanged.connect(
                lambda key=key: self._trigger_recalculation_for(key)
            )
            self._queries[key] = query
        return query

    def _current_query(self):
        if self._current_key is None:
            return None
        return self._queries.get(self._current_key)

    def _suggest_new_query_name(self):
        existing_names = {q.engine.output_name for q in self._queries.values()}
        n = len(self._queries) + 1
        name = f"Новый слой {n}"
        while name in existing_names:
            n += 1
            name = f"Новый слой {n}"
        return name

    def _trigger_recalculation_for(self, key):
        """Called by a background query's own watcher -- key may or
        may not be the one currently shown in the panel."""
        query = self._queries.get(key)
        if query is None:
            return
        if key == self._current_key:
            self.panel.set_status("Вычисление...")
        query.engine.recalculate(on_done=lambda c, e, key=key: self._on_query_recalculated(key, c, e))

    def _trigger_current_recalculation(self):
        query = self._current_query()
        if query is None:
            return
        key = self._current_key
        self.panel.set_status("Вычисление...")
        query.engine.recalculate(on_done=lambda c, e, key=key: self._on_query_recalculated(key, c, e))

    def _on_query_recalculated(self, key, feature_count, error):
        """The one place every recalculation -- current or
        background -- funnels through once it's ACTUALLY finished
        (recalculate() is async; the output layer doesn't exist, or
        reflect new data, until this fires). Refreshing the
        management table only here, not right after kicking a
        recalculation off, is what fixes a real bug: the table used
        to show a fresh query's output name as "…" until some
        unrelated later event happened to refresh the table again,
        since the refresh right after Create ran before the
        background task had actually produced an output layer yet."""
        if key == self._current_key:
            if error:
                self.panel.set_status(error)
            else:
                self.panel.set_status(f"Готово — совпадающих объектов: {feature_count}.")
            query = self._queries.get(key)
            if query is not None:
                output_layer = query.engine._output_layer
                self.panel.set_selection_exceptions([output_layer] if output_layer is not None else [])
        self._refresh_query_table()

    def _arm_watcher(self, query):
        if query.auto_update:
            query.watcher.watch([query.engine.subject_layer, query.engine.selection_layer])
        else:
            query.watcher.stop_watching_layers()

    def _refresh_query_table(self):
        rows = []
        for key, query in list(self._queries.items()):
            try:
                output_layer = query.engine._output_layer
                output_name = output_layer.name() if output_layer is not None else "…"
                subject_name = (
                    query.engine.subject_layer.name() if query.engine.subject_layer is not None else "?"
                )
                selection_name = (
                    query.engine.selection_layer.name() if query.engine.selection_layer is not None else "?"
                )
            except RuntimeError:
                # Defensive: a reference here could in principle have
                # gone stale between some other event and this
                # refresh. Don't let a display refresh crash the
                # plugin -- drop the query; a layersWillBeRemoved
                # signal, if one caused this, will have already (or
                # will shortly) clean it up properly anyway.
                self._queries.pop(key, None)
                continue
            status_text = "Активен" if query.auto_update else "Приостановлен"
            rows.append((key, output_name, subject_name, selection_name, status_text))
        self.panel.refresh_query_table(rows)
        if self._current_key is not None:
            self.panel.select_table_row_for_key(self._current_key)
