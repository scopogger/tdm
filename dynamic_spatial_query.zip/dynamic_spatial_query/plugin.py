"""
Main plugin class. QGIS instantiates this once (via classFactory in
__init__.py) and calls initGui() on load, unload() on unload.

Matches the two-sided panel in query_panel.py: the left side is
always a blank draft (subjectLayerChanged/selectionLayerChanged
aren't even connected to anything here anymore -- there's nothing to
react to until "Выполнить" is actually clicked, at which point every
value needed is just read directly off the panel). The right side
manages whatever already exists; _selected_key tracks which table row
is selected, independent of anything happening on the left.

Query definitions are not editable after creation -- no
renaming/layer-changing/predicate-toggling once a query exists,
delete and recreate instead. This also means the self-reference
problem from the previous round (a query's selection layer pointed at
its own output) can no longer occur at all: a brand new query's
output doesn't exist yet at creation time, and there's no later path
to redirect an existing query's selection layer to anything, so
there's nothing left to guard against -- that code is gone, not just
disabled.

One layer id can only back a single query at a time -- trying to
create a second one with a subject layer that already has a query is
refused with a message pointing at deleting the existing one first,
consistent with "delete and recreate" being the only way to change a
query's definition.

Added beyond what was specified: an "Обновить" (Refresh) button next
to "Удалить" on the right side, manually triggering the selected
query's recalculation. Without it, a query with both auto-update and
periodic refresh turned off would have no way to ever refresh again
short of toggling auto-update on and back off.

Keeps one independent, always-live query PER DISTINCT SUBJECT LAYER
(self._queries). Every registered query survives both a project
reload and opening a DIFFERENT project within the same running QGIS
session (QgsProject.readProject, not just initGui() -- see
_sync_with_current_project()). A query can be removed via the panel's
"Удалить" button or by deleting its output layer directly from QGIS's
own Layers panel; both go through _teardown_query(). Cleanup is wired
to layersWillBeRemoved (fires while the layer is still valid), not
layersRemoved (fires after -- confirmed to segfault instead of
raising a normal Python exception if touched at that point).
"""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QAction, QStyle
from qgis.core import QgsProject

from .query_panel import QueryPanel
from .reactive_watcher import ReactiveWatcher
from .spatial_query_engine import SpatialQueryEngine, read_query_definition

ACTION_MENU_TEXT = "&Динамический пространственный запрос"
ACTION_TOOLBAR_TEXT = "Динамический пространственный запрос"


class _LiveQuery:
    """One subject layer's worth of engine + watcher, plus its own
    independent auto-update/periodic-refresh settings."""

    def __init__(self, iface):
        self.engine = SpatialQueryEngine(iface)
        self.watcher = ReactiveWatcher()
        self.auto_update = True
        self.periodic_enabled = False
        self.periodic_seconds = 30


class DynamicSpatialQueryPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.panel = None
        self._queries = {}        # subject_layer_id -> _LiveQuery
        self._selected_key = None  # which row is selected in the right-side table

    def initGui(self):
        icon = self.iface.mainWindow().style().standardIcon(QStyle.SP_DialogApplyButton)
        self.action = QAction(icon, ACTION_TOOLBAR_TEXT, self.iface.mainWindow())
        self.action.setCheckable(True)
        self.action.triggered.connect(self._toggle_panel)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(ACTION_MENU_TEXT, self.action)

        self.panel = QueryPanel(self.iface)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.panel)
        self.panel.hide()
        self.panel.visibilityChanged.connect(self.action.setChecked)

        self.panel.createRequested.connect(self._on_create_requested)
        self.panel.queryRowSelected.connect(self._on_query_row_selected)
        self.panel.removeRequested.connect(self._on_remove_requested)
        self.panel.refreshRequested.connect(self._on_refresh_requested)
        self.panel.rowAutoUpdateToggled.connect(self._on_row_auto_update_toggled)
        self.panel.rowPeriodicRefreshChanged.connect(self._on_row_periodic_refresh_changed)

        QgsProject.instance().layersWillBeRemoved.connect(self._on_layers_will_be_removed)
        QgsProject.instance().readProject.connect(self._on_project_read)

        self._sync_with_current_project()

    def unload(self):
        self.iface.removePluginMenu(ACTION_MENU_TEXT, self.action)
        self.iface.removeToolBarIcon(self.action)
        for signal, slot in (
            (QgsProject.instance().layersWillBeRemoved, self._on_layers_will_be_removed),
            (QgsProject.instance().readProject, self._on_project_read),
        ):
            try:
                signal.disconnect(slot)
            except (TypeError, RuntimeError):
                pass
        for query in self._queries.values():
            query.watcher.stop()
            query.engine.cancel()
        if self.panel is not None:
            for signal, slot in (
                (self.panel.createRequested, self._on_create_requested),
                (self.panel.queryRowSelected, self._on_query_row_selected),
                (self.panel.removeRequested, self._on_remove_requested),
                (self.panel.refreshRequested, self._on_refresh_requested),
                (self.panel.rowAutoUpdateToggled, self._on_row_auto_update_toggled),
                (self.panel.rowPeriodicRefreshChanged, self._on_row_periodic_refresh_changed),
            ):
                signal.disconnect(slot)
            self.iface.removeDockWidget(self.panel)
            self.panel.deleteLater()
            self.panel = None

    # -- syncing with whatever project is currently open -------------------

    def _sync_with_current_project(self):
        """Shared by initGui() (whatever's open when the plugin loads)
        and _on_project_read() (whenever a project is subsequently
        opened in the same running QGIS session -- a distinct event
        from plugin load, since QGIS loads plugins before opening
        whatever project you actually asked for)."""
        self._restore_existing_queries()
        self._selected_key = None
        self.panel.clear_draft(self._suggest_new_query_name())
        self.panel.set_row_controls_enabled(False)
        self._refresh_query_table()

    def _on_project_read(self, _doc=None):
        self._sync_with_current_project()

    def _restore_existing_queries(self):
        project = QgsProject.instance()
        for layer in list(project.mapLayers().values()):
            definition = read_query_definition(layer, project)
            if definition is None:
                continue
            query = self._register_query(definition["subject_layer"])
            query.engine.set_selection_layer(definition["selection_layer"])
            query.engine.set_predicates(definition["predicates"])
            query.engine.set_output_name(definition["output_name"])
            query.engine.attach_existing_output_layer(layer)
            self._arm_watcher(query)  # resume updating; the output layer's
            # data is already correct as of last save, no need to recalculate.

    def _toggle_panel(self, checked):
        self.panel.setVisible(checked)

    # -- left side: create -----------------------------------------------

    def _on_create_requested(self):
        subject = self.panel.subject_layer()
        selection = self.panel.selection_layer()
        if subject is None or selection is None:
            self.panel.set_status("Выберите оба слоя — целевой и слой выборки.")
            return
        predicates = self.panel.selected_predicates()
        if not predicates:
            self.panel.set_status("Выберите хотя бы один геометрический предикат.")
            return
        key = subject.id()
        if key in self._queries:
            self.panel.set_status(
                "Этот целевой слой уже используется в другом запросе. "
                "Удалите его в списке справа, чтобы создать новый."
            )
            return

        query = self._register_query(subject)
        query.engine.set_selection_layer(selection)
        query.engine.set_predicates(predicates)
        query.engine.set_output_name(self.panel.output_name())

        self.panel.set_status("Вычисление...")
        self._arm_watcher(query)
        query.engine.recalculate(on_done=lambda c, e, key=key: self._on_created_query_recalculated(key, c, e))

        self._refresh_query_table()
        self.panel.clear_draft(self._suggest_new_query_name())

    def _on_created_query_recalculated(self, key, feature_count, error):
        # Reports on the LEFT side's status label, since that's where
        # the user just clicked "Выполнить" -- independent of whatever
        # is or isn't selected in the right-side table.
        if error:
            self.panel.set_status(error)
        else:
            self.panel.set_status(f"Готово — совпадающих объектов: {feature_count}.")
        self._refresh_query_table()
        if key in self._queries:
            self.panel.select_table_row_for_key(key)

    # -- right side: manage existing queries -----------------------------

    def _on_query_row_selected(self, key):
        self._selected_key = key
        query = self._queries.get(key) if key is not None else None
        if query is None:
            self.panel.set_row_controls_enabled(False)
            return
        self.panel.set_row_controls_enabled(True)
        self.panel.load_row_settings(query.auto_update, query.periodic_enabled, query.periodic_seconds)

    def _on_remove_requested(self):
        if self._selected_key is None:
            return
        self._teardown_query(self._selected_key, delete_output_layer=True)
        self._selected_key = None
        self.panel.set_row_controls_enabled(False)
        self.panel.select_table_row_for_key(None)
        self._refresh_query_table()

    def _on_refresh_requested(self):
        query = self._selected_query()
        if query is None:
            return
        query.engine.recalculate(on_done=lambda c, e: self._refresh_query_table())

    def _on_row_auto_update_toggled(self, enabled):
        query = self._selected_query()
        if query is None:
            return
        query.auto_update = enabled
        self._arm_watcher(query)
        self._refresh_query_table()

    def _on_row_periodic_refresh_changed(self, enabled, seconds):
        query = self._selected_query()
        if query is None:
            return
        query.periodic_enabled = enabled
        query.periodic_seconds = seconds
        query.watcher.set_periodic_refresh(enabled, seconds)

    def _on_layers_will_be_removed(self, layer_ids):
        removed = set(layer_ids)
        for key, query in list(self._queries.items()):
            ids = set()
            if query.engine.subject_layer is not None:
                ids.add(query.engine.subject_layer.id())
            if query.engine.selection_layer is not None:
                ids.add(query.engine.selection_layer.id())
            if query.engine._output_layer is not None:
                ids.add(query.engine._output_layer.id())
            if ids & removed:
                self._teardown_query(key, delete_output_layer=False)
        if self._selected_key is not None and self._selected_key not in self._queries:
            self._selected_key = None
            self.panel.set_row_controls_enabled(False)
        self._refresh_query_table()

    # -- registry plumbing ------------------------------------------------

    def _teardown_query(self, key, delete_output_layer):
        query = self._queries.pop(key, None)
        if query is None:
            return
        query.watcher.stop()
        query.engine.cancel()
        if delete_output_layer and query.engine._output_layer is not None:
            QgsProject.instance().removeMapLayer(query.engine._output_layer.id())

    def _register_query(self, subject_layer):
        key = subject_layer.id()
        query = self._queries.get(key)
        if query is None:
            query = _LiveQuery(self.iface)
            query.engine.set_subject_layer(subject_layer)
            query.watcher.sourceDataChanged.connect(
                lambda key=key: self._trigger_recalculation_for(key)
            )
            self._queries[key] = query
        return query

    def _selected_query(self):
        if self._selected_key is None:
            return None
        return self._queries.get(self._selected_key)

    def _suggest_new_query_name(self):
        existing_names = {q.engine.output_name for q in self._queries.values()}
        n = len(self._queries) + 1
        name = f"Новый слой {n}"
        while name in existing_names:
            n += 1
            name = f"Новый слой {n}"
        return name

    def _trigger_recalculation_for(self, key):
        """Called by a background query's own watcher when its source
        data changes -- purely a table refresh, no status label
        anywhere reports on it, matching the "always-live, no need to
        announce every recompute" philosophy the right side follows."""
        query = self._queries.get(key)
        if query is None:
            return
        query.engine.recalculate(on_done=lambda c, e: self._refresh_query_table())

    def _arm_watcher(self, query):
        if query.auto_update:
            query.watcher.watch([query.engine.subject_layer, query.engine.selection_layer])
        else:
            query.watcher.stop_watching_layers()

    def _refresh_query_table(self):
        rows = []
        for key, query in list(self._queries.items()):
            try:
                output_layer = query.engine._output_layer
                output_name = output_layer.name() if output_layer is not None else "…"
                subject_name = (
                    query.engine.subject_layer.name() if query.engine.subject_layer is not None else "?"
                )
                selection_name = (
                    query.engine.selection_layer.name() if query.engine.selection_layer is not None else "?"
                )
            except RuntimeError:
                self._queries.pop(key, None)
                continue
            status_text = "Активен" if query.auto_update else "Приостановлен"
            rows.append((key, output_name, subject_name, selection_name, status_text))
        self.panel.refresh_query_table(rows)
        if self._selected_key is not None:
            self.panel.select_table_row_for_key(self._selected_key)
