"""
Main plugin class. QGIS instantiates this once (via classFactory in
__init__.py) and calls initGui() on load, unload() on unload.

Matches the two-sided panel in query_panel.py: the left side is
always a blank draft (subjectLayerChanged/selectionLayerChanged
aren't even connected to anything here anymore -- there's nothing to
react to until "Выполнить" is actually clicked, at which point every
value needed is just read directly off the panel). The right side
manages whatever already exists; _selected_key tracks which table row
is selected, independent of anything happening on the left.

Query definitions are not editable after creation -- no
renaming/layer-changing/predicate-toggling once a query exists,
delete and recreate instead. This also means the self-reference
problem from the previous round (a query's selection layer pointed at
its own output) can no longer occur at all: a brand new query's
output doesn't exist yet at creation time, and there's no later path
to redirect an existing query's selection layer to anything, so
there's nothing left to guard against -- that code is gone, not just
disabled.

A subject layer can back more than one query at once -- each query
gets its own independently-generated id (query_id, see
spatial_query_engine.py), not derived from which layers it
references, so two queries sharing a subject layer against different
selection layers is fully supported.

Added beyond what was specified: an "Обновить" (Refresh) button next
to "Удалить" on the right side, manually triggering the selected
query's recalculation. Without it, a query with both auto-update and
periodic refresh turned off would have no way to ever refresh again
short of toggling auto-update on and back off.

Keeps one independent, always-live query PER DISTINCT SUBJECT LAYER
(self._queries). Every registered query survives both a project
reload and opening a DIFFERENT project within the same running QGIS
session (QgsProject.readProject, not just initGui() -- see
_sync_with_current_project()). A query can be removed via the panel's
"Удалить" button or by deleting its output layer directly from QGIS's
own Layers panel; both go through _teardown_query(). Cleanup is wired
to layersWillBeRemoved (fires while the layer is still valid), not
layersRemoved (fires after -- confirmed to segfault instead of
raising a normal Python exception if touched at that point).

A query whose subject or selection layer is database-backed (not a
local memory/GeoPackage/OGR layer) defaults to auto-update OFF and
periodic refresh ON, and the auto-update checkbox is disabled for it
-- see _is_database_layer()/_apply_default_update_strategy() below.
This isn't about performance; it's a direct consequence of QGIS issue
#55707 (https://github.com/qgis/QGIS/issues/55707), a confirmed,
unfixed upstream bug where enabling "Refresh layer on notification"
for a PostgreSQL layer freezes QGIS outright. That's the same
underlying provider mechanism ENABLE_POSTGRES_LISTEN in
reactive_watcher.py gates (already off by default) -- this is the
UI-level companion to that: rather than requiring the user to
remember not to touch a setting that's disabled anyway, the option is
made unavailable for exactly the layers where it would matter, and
periodic refresh (unaffected by this bug -- it's a plain timer, no
provider-level listening involved) is defaulted on in its place so
these queries still update themselves.
"""

import os
import uuid

from qgis.PyQt.QtCore import QTimer
from qgis.PyQt.QtWidgets import QAction, QStyle
from qgis.core import QgsProject

from .query_panel import QueryPanel
from .reactive_watcher import ReactiveWatcher
from .spatial_query_engine import SpatialQueryEngine, read_query_definition

ACTION_MENU_TEXT = "&Динамический пространственный запрос"
ACTION_TOOLBAR_TEXT = "Динамический пространственный запрос"

# Provider names treated as "local" -- anything else (postgres,
# oracle, mssql, wfs, ...) is treated as a database/remote layer for
# the purposes of the auto-update-vs-periodic default below. This
# errs toward the safe side deliberately: an unrecognized provider
# name is treated as a database layer (periodic default, checkbox
# disabled) rather than as local, since the actual known freeze is
# specifically a provider-level connection issue, and any provider
# not in this list is one this plugin has no basis to vouch for.
LOCAL_PROVIDER_NAMES = {"memory", "ogr", "delimitedtext", "spatialite"}

DEFAULT_DB_PERIODIC_SECONDS = 30


def _is_database_layer(layer):
    if layer is None:
        return False
    provider = layer.dataProvider()
    if provider is None:
        return False
    return provider.name() not in LOCAL_PROVIDER_NAMES


def _query_involves_database_layer(query):
    return (
        _is_database_layer(query.engine.subject_layer)
        or _is_database_layer(query.engine.selection_layer)
    )


class _LiveQuery:
    """One subject layer's worth of engine + watcher, plus its own
    independent auto-update/periodic-refresh settings."""

    def __init__(self, iface):
        self.engine = SpatialQueryEngine(iface)
        self.watcher = ReactiveWatcher()
        self.auto_update = True
        self.periodic_enabled = False
        self.periodic_seconds = 30
        self.name_change_connections = []  # (signal, slot) pairs, for the management table


class DynamicSpatialQueryPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.panel = None
        self._queries = {}        # subject_layer_id -> _LiveQuery
        self._selected_key = None  # which row is selected in the right-side table
        self._unloaded = False

    def initGui(self):
        icon = self.iface.mainWindow().style().standardIcon(QStyle.SP_DialogApplyButton)
        self.action = QAction(icon, ACTION_TOOLBAR_TEXT, self.iface.mainWindow())
        self.action.setCheckable(True)
        self.action.triggered.connect(self._toggle_panel)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(ACTION_MENU_TEXT, self.action)

        self.panel = QueryPanel(self.iface, parent=self.iface.mainWindow())
        self.panel.hide()
        self.panel.windowVisibilityChanged.connect(self.action.setChecked)

        self.panel.createRequested.connect(self._on_create_requested)
        self.panel.queryRowSelected.connect(self._on_query_row_selected)
        self.panel.removeRequested.connect(self._on_remove_requested)
        self.panel.refreshRequested.connect(self._on_refresh_requested)
        self.panel.rowAutoUpdateToggled.connect(self._on_row_auto_update_toggled)
        self.panel.rowPeriodicRefreshChanged.connect(self._on_row_periodic_refresh_changed)

        QgsProject.instance().layersWillBeRemoved.connect(self._on_layers_will_be_removed)
        QgsProject.instance().readProject.connect(self._on_project_read)

        self._sync_with_current_project()

    def unload(self):
        self._unloaded = True
        self.iface.removePluginMenu(ACTION_MENU_TEXT, self.action)
        self.iface.removeToolBarIcon(self.action)
        for signal, slot in (
            (QgsProject.instance().layersWillBeRemoved, self._on_layers_will_be_removed),
            (QgsProject.instance().readProject, self._on_project_read),
        ):
            try:
                signal.disconnect(slot)
            except (TypeError, RuntimeError):
                pass
        for query in self._queries.values():
            query.watcher.stop()
            query.engine.cancel()
        if self.panel is not None:
            for signal, slot in (
                (self.panel.createRequested, self._on_create_requested),
                (self.panel.queryRowSelected, self._on_query_row_selected),
                (self.panel.removeRequested, self._on_remove_requested),
                (self.panel.refreshRequested, self._on_refresh_requested),
                (self.panel.rowAutoUpdateToggled, self._on_row_auto_update_toggled),
                (self.panel.rowPeriodicRefreshChanged, self._on_row_periodic_refresh_changed),
            ):
                signal.disconnect(slot)
            # Deliberately hide() and drop the reference rather than
            # close()/deleteLater() -- confirmed directly (a real
            # crash, tracked down by bisection) that calling close()
            # on this panel causes its child widgets (the layer
            # combos) to be torn down separately from, and before,
            # the parent panel itself, leaving things in an
            # inconsistent state that crashes -- not with a normal
            # Python exception, but an outright process abort -- the
            # next time something (e.g. a project.clear() elsewhere,
            # nothing to do with this plugin) touches a signal on the
            # still-alive-but-orphaned panel. Just hiding and
            # dropping the reference leaves cleanup to the normal
            # parent-child ownership chain (the panel is parented to
            # iface.mainWindow(), so it's genuinely cleaned up when
            # QGIS itself closes, not leaked) instead of forcing an
            # explicit destroy that turned out to be unsafe here.
            self.panel.hide()
            self.panel = None

    # -- syncing with whatever project is currently open -------------------

    def _sync_with_current_project(self):
        """Shared by initGui() (whatever's open when the plugin loads)
        and _on_project_read() (whenever a project is subsequently
        opened in the same running QGIS session -- a distinct event
        from plugin load, since QGIS loads plugins before opening
        whatever project you actually asked for)."""
        self._restore_existing_queries()
        self._selected_key = None
        self.panel.clear_draft(self._suggest_new_query_name())
        self.panel.set_row_controls_enabled(False)
        self._refresh_query_table()

    def _on_project_read(self, _doc=None):
        if self._unloaded:
            return
        self._sync_with_current_project()

    def _restore_existing_queries(self):
        project = QgsProject.instance()
        for layer in list(project.mapLayers().values()):
            definition = read_query_definition(layer, project)
            if definition is None:
                continue
            query = self._register_query(definition["subject_layer"], query_id=definition["query_id"])
            query.engine.set_selection_layer(definition["selection_layer"])
            query.engine.set_predicates(definition["predicates"])
            query.engine.set_output_name(definition["output_name"])
            query.engine.attach_existing_output_layer(layer)
            self._apply_default_update_strategy(query)  # auto-update/periodic
            # settings don't persist across a reload anyway (always reset to
            # _LiveQuery's defaults), so this applies the same database-aware
            # default here as at creation, not just once at first creation.
            self._arm_watcher(query)  # resume updating; the output layer's
            # data is already correct as of last save, no need to recalculate.
            self._sync_name_change_listeners(query)

    def _toggle_panel(self, checked):
        self.panel.setVisible(checked)

    # -- left side: create -----------------------------------------------

    def _on_create_requested(self):
        subject = self.panel.subject_layer()
        selection = self.panel.selection_layer()
        if subject is None or selection is None:
            self.panel.set_status("Выберите оба слоя — целевой и слой выборки.")
            return
        predicates = self.panel.selected_predicates()
        if not predicates:
            self.panel.set_status("Выберите хотя бы один геометрический предикат.")
            return

        # Always a fresh query -- no "this subject layer is already
        # used" refusal here anymore. That refusal was never a
        # deliberate rule; it was a side effect of keying the
        # registry by subject_layer_id, which meant a subject layer
        # could only ever back one query. Queries are keyed by their
        # own query_id now (see spatial_query_engine.py), so two
        # independent queries can share the same subject layer
        # against two different selection layers without colliding.
        query = self._register_query(subject)
        key = query.engine.query_id
        query.engine.set_selection_layer(selection)
        query.engine.set_predicates(predicates)
        query.engine.set_output_name(self.panel.output_name())
        self._apply_default_update_strategy(query)
        self._sync_name_change_listeners(query)

        self.panel.set_status("Вычисление...")
        self._arm_watcher(query)
        query.engine.recalculate(on_done=lambda c, e, key=key: self._on_created_query_recalculated(key, c, e))

        self._refresh_query_table()
        # Explicitly select the row just created, through the same
        # path a real row click uses -- not relying on Qt's own
        # auto-select-on-first-row behavior, which turned out not to
        # fire itemSelectionChanged for the empty-table-to-first-row
        # case specifically. Without this, the row could end up
        # LOOKING selected (Qt's own doing) while the controller's
        # _selected_key stayed None, permanently -- with only one row
        # in the table, there's nothing else to click to force a new
        # selection event, so clicking the same (already, silently,
        # Qt-selected) row again was a no-op, and there was no way to
        # deselect it either.
        self._on_query_row_selected(key)
        self.panel.select_table_row_for_key(key)
        self.panel.clear_draft(self._suggest_new_query_name())

    def _on_created_query_recalculated(self, key, feature_count, error):
        if self._unloaded:
            return
        # Reports on the LEFT side's status label, since that's where
        # the user just clicked "Выполнить" -- independent of whatever
        # is or isn't selected in the right-side table.
        if error:
            self.panel.set_status(error)
        else:
            self.panel.set_status(f"Готово — совпадающих объектов: {feature_count}.")
        query = self._queries.get(key)
        if query is not None:
            self._sync_name_change_listeners(query)  # the output layer now exists
        self._refresh_query_table()
        if key in self._queries:
            self.panel.select_table_row_for_key(key)

    # -- right side: manage existing queries -----------------------------

    def _on_query_row_selected(self, key):
        self._selected_key = key
        query = self._queries.get(key) if key is not None else None
        if query is None:
            self.panel.set_row_controls_enabled(False)
            return
        self.panel.set_row_controls_enabled(True)
        self.panel.set_auto_update_checkbox_enabled(not _query_involves_database_layer(query))
        self.panel.load_row_settings(query.auto_update, query.periodic_enabled, query.periodic_seconds)

    def _on_remove_requested(self):
        if self._selected_key is None:
            return
        self._teardown_query(self._selected_key, delete_output_layer=True)
        self._selected_key = None
        self.panel.set_row_controls_enabled(False)
        self.panel.select_table_row_for_key(None)
        self._refresh_query_table()

    def _on_refresh_requested(self):
        query = self._selected_query()
        if query is None:
            return
        query.engine.recalculate(on_done=lambda c, e: self._refresh_query_table())

    def _on_row_auto_update_toggled(self, enabled):
        query = self._selected_query()
        if query is None:
            return
        query.auto_update = enabled
        self._arm_watcher(query)
        self._refresh_query_table()

    def _on_row_periodic_refresh_changed(self, enabled, seconds):
        query = self._selected_query()
        if query is None:
            return
        query.periodic_enabled = enabled
        query.periodic_seconds = seconds
        query.watcher.set_periodic_refresh(enabled, seconds)

    def _on_layers_will_be_removed(self, layer_ids):
        if self._unloaded:
            # The real bug this guards against: layersWillBeRemoved
            # can fire from something else entirely (project.clear(),
            # confirmed directly -- not necessarily this plugin's own
            # unload sequence) after unload() has already run.
            # Disconnecting this handler in unload() is not reliably
            # enough on its own to prevent that -- confirmed by
            # testing the disconnect alone and having it still crash
            # -- since self.panel may be scheduled for deletion
            # (deleteLater() only schedules, it doesn't immediately
            # destroy) without having been destroyed yet, so touching
            # it here can still reach a half-torn-down object. This
            # explicit flag doesn't depend on exact signal-disconnect
            # timing at all.
            return
        removed = set(layer_ids)
        for key, query in list(self._queries.items()):
            ids = set()
            if query.engine.subject_layer is not None:
                ids.add(query.engine.subject_layer.id())
            if query.engine.selection_layer is not None:
                ids.add(query.engine.selection_layer.id())
            if query.engine._output_layer is not None:
                ids.add(query.engine._output_layer.id())
            if ids & removed:
                self._teardown_query(key, delete_output_layer=False)
        if self._selected_key is not None and self._selected_key not in self._queries:
            self._selected_key = None
            self.panel.set_row_controls_enabled(False)
        self._refresh_query_table()

    # -- registry plumbing ------------------------------------------------

    def _teardown_query(self, key, delete_output_layer):
        query = self._queries.pop(key, None)
        if query is None:
            return
        query.watcher.stop()
        query.engine.cancel()
        self._disconnect_name_change_listeners(query)
        file_path = query.engine.output_gpkg_file_path()
        if delete_output_layer and query.engine._output_layer is not None:
            QgsProject.instance().removeMapLayer(query.engine._output_layer.id())
        if file_path is not None:
            self._cleanup_output_file_later(file_path)

    @staticmethod
    def _cleanup_output_file_later(file_path):
        """Best-effort cleanup of a query's now-unused dedicated
        output .gpkg file (see spatial_query_engine.py's
        _output_gpkg_path() for why each query has its own). Deferred
        via a zero-delay timer rather than deleted immediately here --
        this can run from inside a layersWillBeRemoved handler, before
        QGIS has actually finished removing the layer, and an open
        file generally can't be deleted at all on Windows. Any
        failure (still locked, already gone, whatever) is silently
        ignored: this is tidiness, not correctness, and must never be
        allowed to crash the plugin."""
        def try_delete():
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
            except OSError:
                pass
        QTimer.singleShot(500, try_delete)

    def _register_query(self, subject_layer, query_id=None):
        """Always creates a NEW query entry -- multiple queries can
        share the same subject layer, so this never looks up or
        reuses an existing entry by subject anymore. query_id is
        generated fresh for a normal creation; passed in explicitly
        when restoring a query that already has one tagged on its
        output layer, so its identity stays stable across a reload
        instead of getting a new one every time the project opens."""
        if query_id is None:
            query_id = uuid.uuid4().hex
        query = _LiveQuery(self.iface)
        query.engine.set_subject_layer(subject_layer)
        query.engine.query_id = query_id
        query.watcher.sourceDataChanged.connect(
            lambda key=query_id: self._trigger_recalculation_for(key)
        )
        self._queries[query_id] = query
        return query

    def _sync_name_change_listeners(self, query):
        """Keeps the management table's Целевой слой/Слой выборки/
        Слой-результат columns showing whatever a layer's CURRENT name
        is, including a rename done directly in QGIS's own Layers
        panel -- not just whatever it was named at query-creation
        time. Re-syncing (rather than connecting once) is needed
        because the output layer doesn't exist yet at creation time;
        this gets called again once it does. Disconnects any previous
        connections first so calling it repeatedly for the same query
        doesn't stack up duplicate connections."""
        self._disconnect_name_change_listeners(query)
        for layer in (query.engine.subject_layer, query.engine.selection_layer, query.engine._output_layer):
            if layer is not None:
                layer.nameChanged.connect(self._on_layer_name_changed)
                query.name_change_connections.append((layer.nameChanged, self._on_layer_name_changed))

    def _disconnect_name_change_listeners(self, query):
        for signal, slot in query.name_change_connections:
            try:
                signal.disconnect(slot)
            except (TypeError, RuntimeError):
                pass
        query.name_change_connections = []

    def _on_layer_name_changed(self):
        if self._unloaded:
            return
        self._refresh_query_table()

    def _selected_query(self):
        if self._selected_key is None:
            return None
        return self._queries.get(self._selected_key)

    def _suggest_new_query_name(self):
        existing_names = {q.engine.output_name for q in self._queries.values()}
        n = len(self._queries) + 1
        name = f"Новый слой {n}"
        while name in existing_names:
            n += 1
            name = f"Новый слой {n}"
        return name

    def _trigger_recalculation_for(self, key):
        """Called by a background query's own watcher when its source
        data changes -- purely a table refresh, no status label
        anywhere reports on it, matching the "always-live, no need to
        announce every recompute" philosophy the right side follows."""
        if self._unloaded:
            return
        query = self._queries.get(key)
        if query is None:
            return
        query.engine.recalculate(on_done=lambda c, e: self._refresh_query_table())

    def _arm_watcher(self, query):
        if query.auto_update:
            query.watcher.watch([query.engine.subject_layer, query.engine.selection_layer])
        else:
            query.watcher.stop_watching_layers()

    def _apply_default_update_strategy(self, query):
        """Sets auto-update/periodic-refresh defaults for a query
        based on whether it involves a database-backed layer -- see
        the module docstring for why. Called before _arm_watcher(),
        both at creation and at restoration, so the rule applies
        consistently either way. Local-only queries keep _LiveQuery's
        own defaults (auto-update on, periodic off) untouched."""
        if _query_involves_database_layer(query):
            query.auto_update = False
            query.periodic_enabled = True
            query.periodic_seconds = DEFAULT_DB_PERIODIC_SECONDS
            query.watcher.set_periodic_refresh(True, DEFAULT_DB_PERIODIC_SECONDS)

    def _refresh_query_table(self):
        if self.panel is None:
            return
        rows = []
        for key, query in list(self._queries.items()):
            try:
                output_layer = query.engine._output_layer
                output_name = output_layer.name() if output_layer is not None else "…"
                subject_name = (
                    query.engine.subject_layer.name() if query.engine.subject_layer is not None else "?"
                )
                selection_name = (
                    query.engine.selection_layer.name() if query.engine.selection_layer is not None else "?"
                )
            except RuntimeError:
                self._queries.pop(key, None)
                continue
            status_text = "Активен" if query.auto_update else "Приостановлен"
            rows.append((key, output_name, subject_name, selection_name, status_text))
        self.panel.refresh_query_table(rows)
        if self._selected_key is not None:
            self.panel.select_table_row_for_key(self._selected_key)
