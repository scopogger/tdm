# Dynamic Spatial Query -- QGIS 3.32 plugin (Russian UI)

An "Extract by Location" that keeps itself up to date: define a
query (subject layer, selection layer, spatial predicates), click
"Создать" (Create), and get an output layer that stays live --
automatically re-extracting whenever either input layer's features,
attributes, geometry, or filter condition change -- until you
explicitly remove it. The UI is in Russian; this document is in
English.

This is a working skeleton, not a finished product -- see "Known
simplifications" near the bottom.

## What changed this round -- correcting an over-correction

Two rounds ago, a database-backed query was made to default to
auto-update off / periodic refresh on, with the checkbox grayed out,
as a "belt and suspenders" precaution around the confirmed QGIS
#55707 freeze. A direct question about why a filter change on a
database layer wasn't updating instantly prompted a closer look, and
that precaution turned out to be wrong -- not risky, just
unnecessary, and it broke real functionality along the way.

**The actual reasoning**: QGIS #55707 is specifically about
`setListening(True)` + the PostgreSQL provider's `notify` signal --
already, separately, unconditionally disabled via
`ENABLE_POSTGRES_LISTEN = False` in `reactive_watcher.py`, regardless
of anything in `plugin.py`. The `committedFeaturesAdded/Removed/
GeometriesChanges/AttributeValuesChanges` and `subsetStringChanged`
signals `ReactiveWatcher` also connects to are a completely different,
unrelated thing: plain, local, in-process `QObject` signals that fire
whenever `.commitChanges()`/`.setSubsetString()` is called, entirely
within the QGIS process -- they never open or touch a database
connection at all. Confirmed directly against a real PostgreSQL
layer: connecting to and firing `subsetStringChanged` is instant,
with no hang, regardless of provider. Forcing periodic-only for
database layers disabled that completely safe reactivity for no
actual safety benefit -- and that's exactly what caused the reported
"filter change doesn't update" symptom for database layers.

**Reverted**: database-backed layers now default to auto-update ON,
exactly like local layers -- no special-casing by provider type at
all anymore. `_is_database_layer()`/`_query_involves_database_layer()`/
`_apply_default_update_strategy()` and the checkbox-graying UI code
are removed, not just disabled, since keeping unused special-casing
code around is how this kind of mistake gets made again later.
Confirmed directly against a real PostgreSQL layer:
`tests/test_database_layer_filter_reactivity.py` creates a query
against real postgres tables, confirms it defaults identically to a
local-only query, then changes the subject layer's filter (the same
Query Builder / `setSubsetString()` a user would use) and confirms
the output updates within a couple of seconds, not needing to wait
out a 30-second timer.

**Status column wording**: updated to "По таймеру (каждые N с)"
instead of "Периодически (каждые N с)" for a query that's auto-update
off but periodic-refresh on -- this state is still fully reachable
(a user can still choose it manually, e.g. to reduce load against a
large or busy source), just no longer anything this plugin forces
based on layer type. "Приостановлен" (masculine, agreeing with
"Статус") kept over an alternative neuter form, for grammatical
consistency with the column header.

## What changed the round before this one -- real user feedback, three fixes

A user reported three things: constant popup messages, a filter
change not updating results, and no way to see which layers are in a
query. Addressed all three, plus one bug the testing for these
surfaced along the way.

- **Popup notifications, confirmed and fixed.** The screenshot
  attached to the report (a Windows 10 toast from a NextGIS QGIS
  build reading "Задача выполнена" / "Dynamic spatial query" -- this
  plugin's own task description) pointed straight at it:
  `QgsTask.fromFunction()` defaults to flags that do *not* suppress
  OS-level notifications on completion. Since a query recalculates on
  every source-layer edit, that's a popup per edit. Fixed with
  `QgsTask.Silent` (added QGIS 3.26), confirmed directly to actually
  set the flag on real running tasks. The task still shows in QGIS's
  own Task Manager panel if someone wants to check progress -- this
  only suppresses the OS popup.
- **"Filter change doesn't update" -- the core mechanism is confirmed
  working**, tested directly: change a subset string on a local
  layer with auto-update on (the default), the query recalculates
  correctly. The much more likely explanation, given the database-
  aware defaulting from the round before this one: if the user's
  layers are database-backed, auto-update is now off by default and
  updates happen on the periodic timer (30s) instead of instantly --
  which could easily look identical to "broken" if someone expects
  an immediate result. See the reply below for what to actually check.
- **"Can't see which layers are in the query" -- most likely the
  collapsible right-side panel got collapsed**, deliberately or by an
  accidental drag of the splitter handle, with no obvious way back
  for someone who doesn't know that handle exists. Added a
  **"Показать список запросов"** menu action that un-hides the panel
  and re-expands the query list side regardless of its current state
  -- a discoverable path that doesn't depend on finding or
  understanding the handle. Also confirmed directly, so it doesn't
  need to be guessed at going forward: plain window resizing can't
  cause this on its own -- Qt's own minimum-size-hint mechanism
  already floors the right side at 150px, well above 0, during a
  resize. Only a deliberate handle-drag or the toggle button can
  actually collapse it.
- **A real bug found while testing the above**: toggling periodic
  refresh for a query didn't refresh the management table, so the
  status column could show stale text after changing it (unlike
  toggling auto-update, which already refreshed correctly). Fixed.
- **Status column accuracy**: a query with auto-update off but
  periodic refresh on -- exactly what a database-backed query now
  defaults to -- was showing "Приостановлен" (Paused), which is
  misleading: it's actively updating, just not instantly. Now shows
  "Периодически (каждые N с)" for that state, reserving "Приостановлен"
  for a query that genuinely isn't auto-updating at all.

See `tests/test_user_feedback_fixes.py`.

## What changed the round before this one -- database-aware auto-update defaults

Different users hit the QGIS #55707 freeze differently -- confirmed
directly: the same QGIS version, side by side, froze for one person
and not for their colleague on the same "Refresh layer on
notification" checkbox. Since that's unpredictable per-installation,
and since a permanent freeze is a far worse failure mode than a
30-second-instead-of-instant update, the plugin now steers away from
the risky path by default rather than requiring anyone to remember
not to touch a setting:

- **A query whose subject or selection layer is database-backed**
  (postgres, oracle, mssql, wfs, or any provider not recognized as
  local -- see `LOCAL_PROVIDER_NAMES` in `plugin.py`) now defaults to
  **auto-update OFF, periodic refresh ON at 30 seconds**, and the
  auto-update checkbox is disabled (grayed out, with a tooltip
  explaining why) for as long as that query is selected. This applies
  whether *either* layer is database-backed -- subject, selection, or
  both.
- **A query using only local layers** (memory, GeoPackage/OGR,
  delimited text, SpatiaLite) is completely unaffected: auto-update
  on by default, checkbox enabled, periodic optional, exactly as
  before.
- **Chaining one of this plugin's own output layers (GeoPackage-
  backed) with another local layer is correctly NOT treated as a
  database query** -- confirmed directly, since neither layer touches
  a database provider at all, there's no reason to expect the QGIS
  #55707 mechanism to apply.
- The default is re-applied on **project reload** too, not just at
  creation -- these settings don't persist across a restart regardless
  (see "Known simplifications" below), so restoring a database-backed
  query needs the same rule applied again, and does.
- Unrecognized provider names are deliberately treated as database
  layers (the cautious direction), not as local -- the known freeze is
  provider-connection-specific, and any provider not in the explicit
  local list is one this plugin has no basis to vouch for.

This is a UI-level companion to `ENABLE_POSTGRES_LISTEN` already
being off by default (see the round before this one): rather than
relying on that flag alone and hoping nobody flips it back on for the
wrong reason, the option most directly tied to the known freeze is
made unavailable specifically where it would matter, with the
periodic timer filling the gap automatically.

Tested against a real PostgreSQL/PostGIS connection (not a mock),
covering: the default itself, that only local queries are unaffected,
that a *mixed* query (one database layer, one local) is still gated,
that switching the selected table row toggles the checkbox correctly
each time, that the chaining case is correctly excluded, and that the
default re-applies correctly (including the periodic timer actually
running, not just the flag being set) after a real project reload.
See `tests/test_database_layer_defaults.py` and
`tests/test_database_layer_defaults_restore.py`.

## What changed the round before this one

### The PostgreSQL freeze is a known QGIS bug, not a plugin bug

Identified: **QGIS issue #55707, "Refresh layer on notification for
postgres layer freezes UI"** —
https://github.com/qgis/QGIS/issues/55707

The upstream report matches this situation exactly:

- Checking "Refresh layer on notification" in Layer Properties >
  Rendering and hitting Apply **freezes QGIS forever**; only killing
  the process helps.
- Reported against **QGIS 3.26 through 3.34** (the version in use
  here, 3.32.2, is inside that range).
- Reproduced with a **fresh QGIS profile**, so it isn't a corrupted
  config.
- Reproduced **only for postgres layers** — the reporter tried a
  GeoPackage layer, which did not freeze.
- **Closed as "not planned"**: no assignee, no fix branch, nobody
  working on it.

That checkbox is exactly what `setListening(True)` + the `notify`
signal does in `reactive_watcher.py` — the same provider code path.
So the freeze reproduces with **zero plugin code involved**, which
explains both things that were previously confusing: why it never
reproduced in this project's headless test environment (no Layer
Properties UI, different Qt event-loop conditions), and why no
amount of plugin-side rework fixed it. The hang happens inside
QGIS's own postgres provider, before any of this plugin's code runs.

**A 30-second test to confirm this independently, with the plugin
completely uninvolved** (worth doing — it's the difference between
"my plugin is broken" and "this QGIS version has a known bug"):

1. Load any PostgreSQL layer.
2. Right-click it > Properties > Rendering tab.
3. Check "Refresh layer on notification" (Обновлять слой по
   уведомлению), click Apply.

If QGIS freezes, that's the upstream bug reproduced with no plugin
in the picture at all. If it *doesn't* freeze on a given QGIS
version, that version may have fixed it, and
`ENABLE_POSTGRES_LISTEN` would be worth re-testing there — the
upstream report was never verified against anything newer than 3.34,
so a newer QGIS is the one realistic path to getting this working.

The flag stays `False`. There is no plugin-side fix to write, and
nothing about this blocks dynamic updates: the per-query periodic
refresh timer covers cross-session PostgreSQL changes with no
database-side setup and no dependency on this code path.

One related dead end, noted so it isn't attempted later: rolling our
own `LISTEN` via psycopg2 inside the plugin has its own well-reported
failure mode (QGIS issues #28772 and #29208 both describe a psycopg2
`LISTEN` blocking QGIS and eventually crashing it). Doing it safely
would mean hand-managing a background thread and socket polling
around a library that already has thread-affinity constraints — real
concurrency risk, in an application that's already demonstrated it
will hard-freeze on this exact feature, to save a polling interval.
Not worth it unless the periodic timer proves genuinely insufficient.

## What changed the round before this one

### Fixed: creating the first query left "Удалить"/"Обновить" disabled

**Symptom**: creating a query auto-highlighted it in the management
table, but the row controls stayed disabled -- as if it wasn't really
selected. Clicking the row again did nothing, and there was no way
to deselect it either.

**Root cause, found by tracing exactly when (and whether) the
relevant signal fired**: `QTableWidget` auto-selects a row as a side
effect of populating it when the table goes from empty to its first
row -- but, confirmed directly by instrumenting the signal itself,
this specific transition does not fire `itemSelectionChanged`. The
selection model genuinely considered the row selected (this wasn't a
rendering-only "looks selected"), but nothing ever told the plugin's
own controller, so its `_selected_key` stayed `None` and the row
controls, which depend on it, stayed disabled. With only one row in
the table and Qt already considering it selected, clicking the same
row again was a no-op from Qt's own perspective -- nothing to
"change" to -- which is exactly why clicking again didn't help and
deselecting wasn't possible: both symptoms were the same root cause,
not two separate bugs.

**Fix**: creating a query now explicitly selects its row through the
same controlled path a real row click uses, immediately after
creation, rather than depending on Qt's own auto-select behavior and
a signal that doesn't reliably fire for this specific case. See
`tests/test_first_query_autoselect.py`, which reproduces the exact
empty-to-first-row transition and confirms the controller and the
widget's own selection model agree afterward, twice in a row (not a
one-off).

## What changed the round before this one

### The freeze: confirmed, not just suspected

A controlled A/B test in the actually-affected environment settled
it: `ENABLE_POSTGRES_LISTEN = False` works correctly; flipping it back
to `True` reproduces the freeze on the same setup, same layer,
everything else unchanged. This is the real fix for that environment,
not a precaution pending more data -- the flag stays off by default.

### PostgreSQL SQL triggers are not required

Worth stating plainly, since it wasn't obvious this was the answer
until the above was confirmed: **dynamic updates for PostgreSQL
layers do not require the NOTIFY trigger from earlier in this
project's README.** That trigger only mattered for *instant*
updates when something *outside this QGIS session* edits the table.
The periodic timer -- already built, already per-query, requiring
zero database-side setup -- covers the same need on a polling
interval instead of instantly. Concretely, for a deployment with many
schemas where only some are in active use at a given time: the timer
is opt-in per query (the right-side panel's "Также обновлять каждые"
checkbox + interval), so it naturally scales with however many
queries someone has actually created, not with how many schemas or
tables exist. Nothing needs pre-provisioning across all 40 schemas --
a query against a table that never gets a periodic refresh enabled
costs nothing extra at all; one where it is enabled costs one
lightweight background read per interval, same as it would for any
other layer type.

If tighter efficiency ever matters here -- e.g. a very expensive
recompute against a rarely-changing but very large table -- a
cheap-check-then-recompute hybrid (poll something lightweight like a
`MAX(updated_at)` or row count, only run the real spatial computation
if that changed) would be a reasonable next step, but wasn't built
speculatively; ask if it turns out to be worth it.

### Output file organization

Two improvements, both aimed at what was actually being asked for --
less visual clutter -- without touching the one-file-per-query
architecture that fixes the GeoPackage contention bug from the
previous round (reintroducing shared files for fewer files on disk
would trade a cosmetic improvement for a real crash risk, not a trade
worth making):

- Each query's dedicated `.gpkg` file now lives in a
  `dynamic_spatial_query_outputs/` subfolder next to the project,
  instead of loose alongside the user's other project files.
- Removing a query (via "Удалить", or reactively when its output
  layer is deleted directly from QGIS's own Layers panel) now deletes
  that query's now-unused file too, so files no longer accumulate
  unboundedly across create/delete cycles -- only currently-active
  queries have a file on disk. Deferred by 500ms rather than deleted
  immediately, since this can run from inside a `layersWillBeRemoved`
  handler before QGIS has actually finished removing the layer, and
  an open file generally can't be deleted at all on Windows; any
  failure is silently ignored (this is tidiness, not correctness, and
  must never crash the plugin).

## What changed the round before this one

### The freeze -- still under investigation, one precaution applied

The thread-safety fix from the previous round was real and worth
keeping, but it turned out not to be the whole story: the freeze was
reported to still happen afterward, with a tiny 4-feature table,
which rules out a slow computation as the cause. I tested three more
angles against a real PostgreSQL table (isolated `setListening()`,
the engine through a real background task, and the complete plugin
flow including the watcher) and could not reproduce a hang in this
environment. `setListening(True)`/the NOTIFY mechanism is the leading
remaining suspect -- it's the least-standard API surface this plugin
touches, and it runs synchronously on the main thread *before* any
background computation starts, which would explain a freeze the
earlier fix wouldn't touch. **It's now off by default**
(`ENABLE_POSTGRES_LISTEN` in `reactive_watcher.py`) as a precaution,
not a confirmed fix -- a permanent freeze is a much worse failure mode
than losing instant cross-session updates (the periodic timer still
covers that). If the freeze persists even with this disabled, that's
important information: it would mean something else entirely is
going on, most likely in how QGIS's own postgres provider handles a
`QgsVectorLayer` connection in this specific environment, not in this
plugin's own code.

### Removed the "layer already used in another query" restriction

This was never a deliberate rule -- it was a side effect of keying the
query registry by the subject layer's own id, which meant a subject
layer could only ever back one query. Two independent queries
sharing a subject layer against two different selection layers is a
completely reasonable case (e.g. "buildings in zone A" and
"buildings in zone B" as separate, independently-updating queries).

Every query now gets its own generated id (`query_id`), completely
decoupled from which layers it happens to reference. This touched
more than just the registry key:

- **Output table naming**: previously derived from the subject
  layer's id, which could no longer guarantee uniqueness once two
  queries could share a subject. Now derived from `query_id`.
- **Reattachment on project load** (`_find_existing_output_layer()`):
  previously matched a tagged output layer back to its query by
  subject layer id -- now matches by `query_id`, since subject id
  alone is no longer specific enough.
- **A real bug found while testing this properly, not a test
  artifact**: creating a second query while the first's output layer
  was still open crashed with "unable to open database file". All
  queries in a project were sharing one `.gpkg` file; GDAL's SQLite/
  GeoPackage driver isn't guaranteed to tolerate a second table being
  added to a file some other still-open `QgsVectorLayer` is actively
  using. Fixed by giving **each query its own dedicated `.gpkg`
  file** (named by `query_id`) instead of one shared file per
  project -- sidesteps the whole class of issue rather than trying to
  serialize around it. See `tests/test_multi_query_same_subject.py`,
  which reproduces the exact scenario (two queries, same subject,
  created back to back) and confirms both settle correctly and
  survive a reload independently.
- Backward compatible with projects saved before `query_id` existed:
  `read_query_definition()` generates a fresh one on the spot if a
  tagged output layer doesn't have one yet.

## What changed the round before this one -- a real thread-safety bug freezing QGIS with PostgreSQL layers

**The bug**: `_compute_matches()` (the read-only matching step that
runs on a background `QgsTask`) called `.getFeatures()` directly on
the `QgsVectorLayer` objects themselves, from inside that background
task. QGIS's own documentation is explicit that this is unsafe --
*"Any background task... must NEVER use any QObject that lives on the
main thread, such as accessing QgsVectorLayer... Attempting to use
them from background threads will result in crashes. Data that is
used in a task must be copied before the task is started."* The QGIS
source tree has its own historical fix for exactly this pattern
(accessing a layer from a feature iterator that may run on a
background thread), switching to `QgsVectorLayerFeatureSource` --
which is what this now follows too.

This is why it worked fine in essentially all of this project's own
testing to date: the memory provider tolerates being touched
cross-thread far better than a real database connection does. A
PostgreSQL connection (via libpq) has real thread affinity -- using
it from a thread other than the one that created it is exactly the
kind of thing that produces a hang rather than a clean crash.

**The fix**: `recalculate()` now builds a `QgsVectorLayerFeatureSource`
for both the subject and selection layers -- plus everything else
`_compute_matches()` needs (CRS objects, the same-layer check, the
coordinate transform context) -- on the *main* thread, before
dispatching to the background task. `_compute_matches()` now takes
those sources, never the raw layers, and never touches `QgsProject`
either (also flagged as unsafe from a background thread; the
transform context is captured up front instead of read again inside
the task).

**Testing note, stated plainly rather than overclaimed**: I could not
get my own test environment to actually reproduce a hang, even
reverting to the old, documented-as-unsafe pattern against a real
PostgreSQL layer (see `tests/test_postgis_thread_safety.py`, which
runs the computation through a real `QgsTask` against a real
PostGIS-backed layer with a bounded timeout -- both the old and new
code passed it). That likely comes down to environment differences
from a real QGIS Desktop session (a tiny two-row test table, a fresh
local connection, possibly a different libpq/threading setup in this
sandbox) rather than the bug being imaginary -- QGIS's own
documentation is unambiguous that the old pattern is unsafe regardless
of whether it happens to work in a given environment. If applying this
doesn't resolve the freeze you're seeing, that would be useful
information: whether it happens immediately on selecting a layer or
only when a recalculation actually runs, whether it's a permanent hang
or eventually clears, and roughly how large the real table is, would
all help narrow down whether something else is also contributing (a
large result set being written back on the main thread in
`_write_output()` is the next thing I'd look at, since main-thread
writes for a very large match count could cause a real, if temporary,
UI freeze independent of the threading bug above).

## What changed the round before this one -- floating window, embedded splitter toggle, layer-rename reactivity

- **Floating window, not a QGIS dock widget.** `QueryPanel` is now a
  plain `QWidget` with the `Qt.Window` flag, parented to
  `iface.mainWindow()`, shown/hidden directly rather than through
  `iface.addDockWidget()`. The window's own `[x]` button hides it
  rather than destroying it (same as toggling it off from the
  toolbar), so it can always be reopened from the same action.
- **The right side's toggle button now lives in the splitter handle
  itself**, matching QGIS's own "Select by Location" dialog (a
  reference screenshot made this unambiguous) -- not a separate row
  above the splitter, which was a meaningfully different visual
  result even though both technically "worked". A custom
  `QSplitterHandle` subclass holds the button; clicking it and
  dragging the handle all the way over both collapse/expand through
  the same `QSplitter.setSizes()` mechanism and the same remembered
  last-width, rather than the button using a different show/hide
  mechanism than dragging does.
- **A horizontal separator** sits between the selection-layer dropdown
  and the result-name field (a plain `QFrame` with `HLine` shape --
  confirmed that's what was meant, not a vertical divider).
- **The management table now reacts to layers being renamed directly
  in QGIS's own Layers panel** -- previously the table only refreshed
  on query create/remove/recalculate, so a rename elsewhere left a
  stale name showing until some unrelated event happened to refresh
  it. Each query now listens to `nameChanged` on its subject,
  selection, and (once it exists) output layer.

### A real crash, and the debugging path to actually fixing it

This one is worth walking through honestly rather than just stating
the fix, because two earlier attempts looked plausible and were
wrong.

**Symptom**: after `unload()`, some later `QgsProject` operation
elsewhere (`project.clear()`, specifically -- and only reproduced
after a `project.write()` had happened first) aborted the whole
process. Not a Python exception -- an actual process abort, so no
`try/except` anywhere could have caught it.

**First attempt** (wrong): disconnecting the layer combos' internal
`layerChanged` relay during teardown. Looked plausible, didn't fix it
-- confirmed by testing it in isolation and having the exact same
crash still happen.

**Second attempt** (also wrong): `QgsMapLayerComboBox.setProject(None)`,
to fully detach the combo from the project. Also didn't fix it, also
confirmed directly rather than assumed.

**Actual root cause**, found by bisecting the failing test line by
line down to the exact statement, then tracing panel object identity
across the whole sequence with print-based diagnostics: `unload()`
was calling `close()` then `deleteLater()` on the panel. That
combination tore the panel's child widgets (the layer combo boxes)
down *separately from, and before,* the panel itself -- confirmed
directly by checking `isHidden()`/liveness on both the panel and a
child combo after teardown and finding the child already dead while
the parent was still alive, which is backwards from normal Qt
parent-child destruction order. Whatever was left in that
inconsistent state is what the later `project.clear()` crashed
against.

**The fix**: `unload()` now calls `hide()` and drops the reference,
never `close()`/`deleteLater()` at all. Cleanup happens through the
normal parent-child ownership chain instead (the panel is parented to
`iface.mainWindow()`, so it's genuinely cleaned up when QGIS itself
closes, not leaked) -- see `tests/test_unload_crash_regression.py`,
which reproduces the exact sequence that used to abort the process.
One acknowledged tradeoff: repeatedly enabling/disabling the plugin
within a single QGIS session leaves each previous (hidden, otherwise
inert) panel instance alive until QGIS itself closes, rather than
each one being destroyed immediately -- a minor memory cost, not a
functional one, and a much safer choice than the alternative that was
just disproven.

Separately, and found by the same bisection: `layersWillBeRemoved`
firing from something entirely unrelated to this plugin's own
lifecycle (again, `project.clear()`) after `unload()` had already run
was hitting a `None self.panel` and raising `AttributeError`. Fixed
with an explicit `self._unloaded` guard flag, checked at the top of
every handler that could otherwise fire post-unload -- more robust
than relying on signal-disconnect timing alone, which is exactly what
turned out to be unreliable in the crash above.

## What changed the round before this one -- UI split into two panes

A genuine redesign, not a fix: the panel is now a `QSplitter` with two
sides.

- **Left (always visible): define and create.** Subject layer,
  predicates (reordered into the requested 2-column layout:
  Intersects/Touches, Contains/Overlaps, Disjoint/Within,
  Equals/Crosses), selection layer, result name (now stacked under
  its label rather than beside it), one "Выполнить" button, one
  status line. Always a blank draft -- there's no way to load an
  existing query's state into it anymore.
- **Right (toggleable, resizable): manage what already exists.** The
  table, "Удалить", the two update-frequency controls (auto-update,
  periodic refresh), and one addition beyond the original spec: an
  "Обновить" button for manually refreshing the selected query on
  demand -- without it, a query with both auto-update and periodic
  refresh turned off would have no way to ever refresh again short of
  toggling auto-update on and back off. All four act on whichever
  table row is currently selected.
- **A small "‹"/"›" button** above the splitter toggles the right
  side's visibility; the splitter itself is freely resizable by
  dragging.

The bigger change is *behavioral*, not just visual: **query
definitions are no longer editable after creation** -- no renaming, no
changing layers, no toggling predicates once a query exists. Delete
and recreate instead. This simplified a real amount of code, not just
UI: the previous round's "is this subject already loaded as an
existing query, if so populate every field with its state" logic is
gone, along with the self-reference guard that logic needed (a
query's selection layer could previously be redirected, after
creation, to point at its own output). With no way to redirect an
existing query's selection layer at all anymore, and a brand new
query's output not existing yet at the moment it's being defined, that
scenario can no longer occur -- the guard was removed rather than kept
as now-unreachable code.

One rule enforced at creation time as a consequence: a subject layer
can only back one query at a time. Trying to create a second query
against a subject that already has one is refused with a message
pointing at deleting the existing one first, consistent with "delete
and recreate" being the only way to change a query's definition.

Also: predicate labels (`Within`, `Overlaps`, `Crosses`) and the
panel's layer-picker wording were already aligned to a direct copy of
QGIS's own "Извлечь по расположению" dialog text in the previous
round; this round's layout changes (reordering, restacking the result
name field) follow the same source.

## What changed the round before that

Five fixes, all from real usage feedback:

1. **Management table's output-name cell no longer sticks at "…"**.
   Root cause: the table was refreshed right after *starting* a
   recalculation, but `recalculate()` is asynchronous -- the output
   layer doesn't exist (or reflect new data) until the background
   task's completion callback fires, which could be well after that
   premature refresh. Now every recalculation, current or background,
   funnels through one completion handler that refreshes the table
   only once real data is actually ready.
2. **Reopening a project now actually reattaches to its queries.**
   This was a real gap, not a minor bug: `initGui()` runs once when
   the *plugin* loads, which in real QGIS usage happens *before* you
   open your actual project file -- so restoration only ever saw
   whatever project was open at that moment (typically an empty one).
   Now also wired to `QgsProject.readProject`, which fires every time
   a project is subsequently opened in the same running QGIS session,
   confirmed directly to fire with the new project's layers (and
   their custom properties) already fully available.
3. **Four distinct buttons replace the single relabeled one.** The
   old single button (label swapping between "Создать"/Create and
   "Пересчитать сейчас"/Recalculate depending on state) had two real
   traps: no way to create a *new* query once an existing subject
   layer's query was loaded (Create wasn't offered at all in that
   state), and no explicit way back out of an accidentally-loaded
   existing query before an edit got applied to it by mistake. Now:
   "Новый запрос" (New query) explicitly clears to a blank draft,
   "Создать" is *disabled* (not hidden) rather than replaced when the
   current draft's subject already has a query, and "Пересчитать
   сейчас"/"Удалить" are only enabled when an existing query is
   actually loaded.
4. **A query's selection layer can no longer be set to its own output
   layer** -- proactively excluded from the selection combo's choices
   (`QgsMapLayerComboBox.setExceptedLayerList`), with a plugin-level
   check as a backstop. Chaining a *different* query's output into
   this one is unaffected.
5. **A fresh draft suggests an incrementing name** ("Новый слой 1",
   "Новый слой 2", ...) instead of always defaulting to the generic
   "query_result".

Plus a real bug independent of any of the above: **unchecking every
predicate checkbox had no visible effect at all** -- `set_predicates([])`
was silently substituting a default predicate instead of actually
recording "none selected", so `recalculate()`'s existing "select at
least one predicate" check never had anything to catch. QGIS's own
Extract by Location refuses to run under the same condition; this
plugin now refuses too, checked before a query is even registered (so
an incomplete query is never left sitting in the table in a
permanently-broken state).

Also, predicate labels and the panel's layer-picker wording now match
a direct copy of QGIS's own "Извлечь по расположению" dialog text
(provided directly, not approximated) -- three labels changed
(`Within`, `Overlaps`, `Crosses`) and the panel's layer pickers were
reordered to follow the same subject -> predicate -> selection
reading order as the native tool.

### On the two checkboxes from the native dialog

- **"Только выделенные объекты" (Only selected features)**: not
  implemented. It's a genuinely reasonable feature for this plugin's
  architecture -- restricting the subject layer's contribution to
  whatever's currently selected would mean also listening for
  `layer.selectionChanged` as an additional reactive trigger -- but
  wasn't requested confidently enough yet to build speculatively. Ask
  if you find you need it.
- **"Открыть выходной файл после завершения алгоритма" (Open output
  file after completion)**: doesn't apply to this plugin's model. A
  one-shot processing algorithm produces a file you might then choose
  to open; this plugin's output is *always* already added to the
  project the moment a query is created -- there's no separate "open"
  step to make optional.

## What changed the round before this one

Three real product requests, not just polish:

1. **Nothing is created just by picking layers or enabling the
   plugin.** Previously, auto-selecting layers in the panel (or even
   just having the plugin enabled in a project that already had
   layers) could silently create an output layer and group. Now
   picking layers only edits a draft; an explicit click of the
   panel's primary button ("Создать") is what actually creates a
   query -- a real output layer, added to the project, and armed to
   auto-update.
2. **A query can be removed two equivalent ways**: the panel's
   "Удалить" (Remove) button, or simply deleting its output layer
   from QGIS's own Layers panel -- both tear the query down the same
   way (stop its watcher, drop it from the registry). Deleting a
   query's subject or selection layer instead (not its output) also
   tears it down, since it can no longer function, but leaves its
   last-computed output layer in place rather than also deleting it.
3. **A management table** at the top of the panel lists every
   currently-live query (output name, subject, selection, status);
   clicking a row loads that query below for viewing or editing.
   Previously the only way to "find" an existing query was to already
   know which layer was its subject and pick it in the dropdown.

Plus: the whole UI (labels, buttons, status messages, the plugin's
own name in the plugin manager) is now in Russian. Internal predicate
keys and custom-property names stay in English regardless -- only the
presentation layer changed, so this doesn't affect compatibility with
projects/queries created by earlier versions.

## Files

| File | Purpose |
|---|---|
| `metadata.txt` | Plugin metadata QGIS reads to list it in the plugin manager (Russian name/description) |
| `__init__.py` | `classFactory()` entry point QGIS calls on load |
| `plugin.py` | Wires everything together: the query registry, create/remove, reactive cleanup |
| `query_panel.py` | Dock widget: query table, layer pickers, predicate checkboxes, controls -- Russian labels |
| `spatial_query_engine.py` | The actual query logic + GeoPackage-backed output-layer management |
| `reactive_watcher.py` | Connects to the right signals to detect "something changed", per query |
| `tests/` | Scripts that run the above against a real headless PyQGIS |

## Architecture, in one pass

- **Draft vs. created**: the panel's controls (both layer pickers,
  predicates, output name) always represent a *draft*. Nothing is
  registered or computed until the primary button is clicked. If the
  currently-picked subject layer already has a query, that button
  reads "Пересчитать сейчас" (Recalculate now) instead of "Создать"
  and the Remove button is enabled; for a brand-new subject it's the
  reverse. `plugin.py`'s `_on_subject_changed` is what decides which
  state you're in and updates the panel accordingly.
- **Registry**: `plugin.py` keeps one independent engine+watcher pair
  per *created* subject layer (`self._queries`), not one shared pair
  reconfigured on every panel change -- so switching which query the
  panel shows never stops another one from continuing to update in
  the background. Every registered query is restored from the
  project's tagged output layers on load, so a query created in a
  previous session resumes updating the moment the project reopens,
  with zero panel interaction.
- **Predicates**: all 8 that `native:extractbylocation` offers
  (Intersects, Within, Contains, Overlaps, Touches, Equals, Crosses,
  Disjoint), implemented as direct `QgsGeometry` method calls rather
  than delegating to that processing algorithm's integer-indexed
  `PREDICATE` parameter, specifically to avoid any risk of a wrong
  index-to-predicate mapping. Multiple checked predicates combine
  with OR. Internal keys stay English; `query_panel.py`'s
  `PREDICATE_LABELS_RU` maps them to Russian for display only.
- **Computation**: subject features are extracted unmodified --
  original geometry, original attributes, no clipping. A selection-
  layer spatial index plus a subject-layer bounding-box prefilter
  keep this fast for the 7 predicates where "the match must be
  spatially near something" holds; `Disjoint` is structurally
  different (a match is typically *far* from everything) and gets its
  own path.
- **Filters ("the layer is the result of a query")**: a subset string
  is respected automatically by every `getFeatures()` call here, for
  free. The only thing that needed building was *reacting* to the
  filter itself changing (`subsetStringChanged`).
- **Persistence**: output layers are GeoPackage-backed (one `.gpkg`
  file per project, one table per subject layer), not QGIS "memory"
  layers -- memory layers never write their feature data into the
  project file, only their structure. Writes go through a real layer
  edit session (`startEditing()`/`addFeatures()`/`deleteFeatures()`/
  `commitChanges()`), not straight to the data provider, which is
  also what makes QGIS's "Show Feature Count" legend display refresh
  correctly (it only listens for the commit signals that path emits).
- **Reattachment**: each output layer is tagged with a
  `QgsMapLayer` custom property (subject/selection layer ids,
  predicates, output name) at creation time. Before creating a new
  layer, the engine checks for a matching tagged one first -- this is
  what lets a reopened project rediscover and reattach to its own
  previously-created outputs instead of duplicating them, and what
  lets `plugin.py` reconstruct a query's full definition (not just
  its existence) on load.
- **Background execution**: `recalculate()` runs its matching step on
  a `QgsTask`, keeping only the output-layer write on the main
  thread. A `recalculate()` call that arrives while one is already
  running doesn't start a second, overlapping task; it's remembered
  and re-run once the in-flight one finishes.

## Verification

`tests/` installs a real headless PyQGIS (3.34, via
`apt-get install python3-qgis`) and runs the actual plugin modules.
Beyond the predicate/attribute/persistence correctness already
covered by earlier rounds, this round's tests specifically cover:

- Enabling the plugin (or picking layers) with existing project
  layers creates nothing until the button is explicitly clicked
- The button's label and Remove's enabled state track draft-vs-
  created correctly as you switch between subjects
- Removing via the panel button vs. deleting the output layer
  directly both tear the query down equivalently
- Deleting a query's subject layer tears it down but leaves its
  output layer alone
- The management table's row count and content track reality, and
  clicking a row loads that query
- A query created through the real button flow still persists and
  restores correctly across an actual project save/reload

One real crash surfaced and got fixed while writing these: cleanup
was originally wired to `QgsProject.layersRemoved`, which fires
*after* a layer's underlying C++ object is already destroyed --
calling `.id()` on it, or disconnecting a watcher's signal
connections from it, produced an uncatchable segfault, not a Python
exception. Switched to `layersWillBeRemoved`, confirmed directly to
fire while the layer is still fully valid, and the crash is gone.

This round added `tests/test_predicate_validation.py` (the
no-predicates-selected fix, both at the engine level and through the
real panel). `test_two_pane_ui.py` supersedes the previous round's
`test_create_remove_workflow.py` (deleted -- it tested the single
relabeled button and editable-query-state APIs this round removed)
and covers the split panel, create-only left side, manage-only right
side, the duplicate-subject refusal, and the added Обновить button, on
top of everything the file it replaced already covered: no
auto-creation, reactive cleanup on external layer deletion, and self-reference prevention.

## Setting up PyCharm against QGIS's Python 3.9 (Windows)

QGIS on Windows bundles its own Python -- PyCharm has to point at
that exact interpreter, not a separately-installed one.

1. Find your QGIS install folder and look inside its `bin` folder for
   `python-qgis.bat` or `python-qgis-ltr.bat`. Open it in a text
   editor -- it shows exactly which `PATH`/`PYTHONHOME`/`PYTHONPATH`
   values QGIS itself uses.
2. Write a launcher batch file reusing those same lines, then
   starting PyCharm:

   ```bat
   @echo off
   SET QGIS_ROOT=C:\Program Files\QGIS 3.32.2
   call "%QGIS_ROOT%\bin\o4w_env.bat"
   call "%QGIS_ROOT%\bin\qt5_env.bat"
   call "%QGIS_ROOT%\bin\py3_env.bat"
   set PATH=%QGIS_ROOT%\apps\qgis-ltr\bin;%PATH%
   set PYTHONPATH=%QGIS_ROOT%\apps\qgis-ltr\python;%PYTHONPATH%
   start "" "C:\Program Files\JetBrains\PyCharm Community Edition\bin\pycharm64.exe"
   ```

3. In PyCharm: File > Settings > Project > Python Interpreter > Add >
   System Interpreter, pointing at `python.exe` inside your QGIS
   install's Python folder (often `apps\Python39`).
4. Add the QGIS `python` folder to the interpreter's paths so
   PyCharm's indexer sees `import qgis`.
5. Always launch PyCharm via your batch file so the environment
   variables are set first.

Install **Plugin Reloader** for a fast edit/reload loop instead of
restarting QGIS each time.

## Installing the plugin for development

Copy or symlink this `dynamic_spatial_query` folder into your QGIS
profile's `python/plugins` folder (Settings > User Profiles > Open
Active Profile Folder > `python/plugins`), enable it under
Plugins > Manage and Install Plugins > Installed.

## How live-updating works

`reactive_watcher.py` watches both layers of a created query
(deduplicated if they're the same layer) for: committed edits
(feature add/remove/geometry/attribute changes), filter/subset-string
changes, and cross-session PostGIS edits via `setListening(True)` +
the provider's `notify` signal (requires a one-time SQL trigger per
source table -- see below). All funnel into one debounced
`sourceDataChanged` signal (400ms). `set_periodic_refresh(enabled,
seconds)` supplements this with a plain unconditional timer, off by
default.

PostGIS NOTIFY trigger, one-time per source table:

```sql
CREATE OR REPLACE FUNCTION public.notify_qgis() RETURNS trigger AS $$
BEGIN
  NOTIFY qgis;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER my_table_notify_qgis
AFTER INSERT OR UPDATE OR DELETE ON my_schema.my_table
FOR EACH STATEMENT EXECUTE FUNCTION public.notify_qgis();
```

Separately, `plugin.py` listens to `QgsProject.layersWillBeRemoved`
at a higher level to detect one of a query's own layers (subject,
selection, or output) being deleted from the project, and tears that
specific query down -- see "Architecture" above.

## Known simplifications / where to extend

- **One live query per subject layer**: two different queries
  sharing the same subject layer but different selection layers
  isn't supported -- picking a subject that already has a query loads
  that existing query rather than letting you define a second one
  against it.
- **Auto-update/periodic-refresh toggles aren't persisted**: only the
  query definition itself (subject, selection, predicates, output
  name) survives a restart; each query's own toggle state resets to
  its default.
- **No viewport scoping**: every recalculation considers the whole of
  both layers, not just what's visible on screen.
- **`native:extractbylocation` as an alternative**: see the
  Architecture section above for why this engine calls `QgsGeometry`
  methods directly instead.
- **Multi-user output**: the output GeoPackage is a local file. Swap
  the construction in `_get_or_create_layer()` for a PostGIS-backed
  one if you want the result itself published to other users.
- **Translation approach**: UI strings are hardcoded in Russian
  directly (in `query_panel.py` and `plugin.py`), not built on QGIS's
  `.ts`/`.qm` translation-file system -- simpler for a single target
  language, but means adding a second language later would mean
  building that infrastructure rather than just adding a translation
  file.

## Troubleshooting

- `ImportError: No module named 'qgis'`: PyCharm's interpreter isn't
  the one bundled with QGIS -- revisit the PyCharm setup section.
- Plugin doesn't appear in the plugin manager: check the QGIS Python
  Console (View > Panels > Python Console) for a traceback.
- A query doesn't update: confirm "Автообновление при изменениях" is
  checked for that specific query (it's per-query, not global), and
  for PostGIS layers, confirm the `NOTIFY` trigger exists on the
  table you edited.
- "Disjoint" returning unexpected results: it's evaluated against the
  *whole* selection layer ("not matching anything in it"), not
  per-selection-feature like the other 7 predicates.
