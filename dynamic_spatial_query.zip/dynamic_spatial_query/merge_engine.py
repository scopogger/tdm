"""
Live «Слияние» (merge): every object of one or more layers of the same
geometry type merged into ONE object, attributes dropped -- what
GeoMedia's merge did for the tester, and what QGIS gives with
«Объединить векторные слои» (Merge vector layers) followed by
«Слияние по признаку» (Dissolve) with no field selected.

Why this exists next to «Объединение»: the tester measures how much of
a pipeline lies inside protected areas. Their example, as a test case
in tests/test_merge_mode.py: a round lake 10 m across with a round
island 5 m across in the middle, and a pipe through both. «Объединение»
keeps them as separate objects -- the island, and the lake with an
island-shaped hole -- so cutting the pipe gives 5 m per object (2.5 +
2.5 in the ring, 5 in the island) although it crosses 10 m of
protected area. Merged into one object, the same cut gives 10 m
directly, and overlapping zones can never be counted twice.

The geometry work mirrors QGIS's own Dissolve
(src/analysis/processing/qgsalgorithmdissolve.cpp, "dissolve all"):
QgsGeometry.unaryUnion() over all geometries, in blocks of 10,000 so
memory stays bounded; lines are then joined end to end with
mergeLines(); and if GEOS fails on a block, the slower one-by-one
fallback QGIS uses. Two differences: input objects with invalid
geometry are skipped (as in the tester's procedure, and reported in
the status line), and an input with no objects gives an empty output
layer rather than one feature with no geometry.

The result is reprojected to the first layer's CRS. Threading follows
the same rule as the other engines: input layers are only read through
QgsVectorLayerFeatureSource objects built on the main thread.
"""

import json

from qgis.core import (
    QgsFeature,
    QgsFeatureRequest,
    QgsFeedback,
    QgsFields,
    QgsGeometry,
    QgsProject,
    QgsVectorLayerFeatureSource,
    QgsWkbTypes,
)

from .spatial_query_engine import QUERY_TYPE_DISSOLVE, LiveOutputEngine
from .union_engine import CANCELED, SAME_GEOMETRY_TYPE_MESSAGE, is_line_geometry, same_geometry_type

# Same block size as QGIS's Dissolve.
MAX_QUEUE_LENGTH = 10000


def dissolve_parts(parts, feedback):
    """QGIS Dissolve's collector, step for step."""
    result = QgsGeometry.unaryUnion(parts)
    if is_line_geometry(result):
        result = result.mergeLines()
    if result.lastError() and len(parts) > 2:
        # GEOS can fail on some inputs; QGIS then retries one geometry
        # at a time (https://github.com/qgis/QGIS/issues/28411).
        result = QgsGeometry()
        for part in parts:
            if feedback.isCanceled():
                return result
            result = QgsGeometry.unaryUnion([result, part])
            if is_line_geometry(result):
                result = result.mergeLines()
    if result.lastError() and result.isEmpty():
        raise RuntimeError(f"Не удалось слить объекты: {result.lastError()}")
    return result


def compute_dissolve(sources, target_crs, transform_context, feedback):
    """
    Runs on a background thread. `sources` are QgsVectorLayerFeatureSource
    objects built on the main thread. Returns
    ((geometry_or_None, merged_count, skipped_invalid), None),
    (None, CANCELED) or (None, message).
    """
    try:
        queue = []
        merged = 0
        skipped_invalid = 0
        for source in sources:
            request = QgsFeatureRequest()
            request.setNoAttributes()
            request.setDestinationCrs(target_crs, transform_context)
            for feature in source.getFeatures(request):
                if feedback.isCanceled():
                    return None, CANCELED
                geometry = feature.geometry()
                if geometry is None or geometry.isNull() or geometry.isEmpty():
                    continue
                if not geometry.isGeosValid():
                    skipped_invalid += 1
                    continue
                merged += 1
                queue.append(QgsGeometry(geometry))
                if len(queue) > MAX_QUEUE_LENGTH:
                    queue = [dissolve_parts(queue, feedback)]
        if feedback.isCanceled():
            return None, CANCELED
        geometry = dissolve_parts(queue, feedback) if queue else None
        if feedback.isCanceled():
            return None, CANCELED
        return (geometry, merged, skipped_invalid), None
    except Exception as exc:  # noqa: BLE001 -- reported to the user, never crashes QGIS
        return None, str(exc)


class DissolveQueryEngine(LiveOutputEngine):
    QUERY_TYPE = QUERY_TYPE_DISSOLVE
    TASK_DESCRIPTION = "Dynamic merge"

    def __init__(self, iface):
        super().__init__(iface)
        self.input_layers = []
        self.last_skipped_invalid = 0
        self.last_merged_count = 0
        self._feedback = None

    def set_input_layers(self, layers):
        self.input_layers = [layer for layer in layers if layer is not None]

    def watched_layers(self):
        return list(self.input_layers)

    def _validation_error(self):
        if not self.input_layers:
            return "Выберите хотя бы один слой для слияния."
        if not same_geometry_type(self.input_layers):
            return SAME_GEOMETRY_TYPE_MESSAGE
        return None

    def _interrupt_in_flight(self):
        if self._feedback is not None:
            self._feedback.cancel()

    def _prepare(self):
        sources = [QgsVectorLayerFeatureSource(layer) for layer in self.input_layers]
        first = self.input_layers[0]
        target_crs = first.crs()
        output_wkb_type = QgsWkbTypes.multiType(first.wkbType())
        transform_context = QgsProject.instance().transformContext()
        feedback = QgsFeedback()
        self._feedback = feedback

        def run(_task):
            return compute_dissolve(sources, target_crs, transform_context, feedback)

        def apply(payload):
            geometry, merged, skipped_invalid = payload
            self._write_output(geometry, output_wkb_type, target_crs)
            self.last_merged_count = merged
            self.last_skipped_invalid = skipped_invalid
            return merged

        return run, apply

    def _extra_properties(self):
        return {"input_layer_ids": json.dumps([layer.id() for layer in self.input_layers])}

    def _write_output(self, geometry, wkb_type, crs):
        project = QgsProject.instance()
        layer = self._output_layer
        if layer is None:
            layer = self._find_existing_output_layer(project)
            if layer is not None:
                self.attach_existing_output_layer(layer)
        if layer is None:
            # No attribute columns at all -- only the GeoPackage's own fid.
            layer = self._create_output_table(project, QgsFields(), wkb_type, crs)
        self._sync_properties_to_layer(layer)

        features = []
        if geometry is not None and not geometry.isEmpty():
            merged = QgsGeometry(geometry)
            merged.convertToMultiType()
            feature = QgsFeature(layer.fields())
            feature.setGeometry(merged)
            features.append(feature)
        self._replace_features(layer, features)
